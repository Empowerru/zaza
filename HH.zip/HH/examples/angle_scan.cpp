#include <complex>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <vector>

#include "hh/helmholtz_1d.hpp"

namespace {

std::vector<double> linspace(double a, double b, int n) {
  std::vector<double> x(static_cast<std::size_t>(n));
  for (int i = 0; i < n; ++i) {
    x[static_cast<std::size_t>(i)] = a + (b - a) * static_cast<double>(i) / static_cast<double>(n - 1);
  }
  return x;
}

double sum_vec(const std::vector<double>& x) { return std::accumulate(x.begin(), x.end(), 0.0); }

}  // namespace

int main() {
  constexpr int n = 220;
  constexpr double z_max = 2.2;
  constexpr double L = 1.2;

  std::vector<double> z_edges = linspace(0.0, z_max, n + 1);
  std::vector<double> eps_re(static_cast<std::size_t>(n), 0.0);
  std::vector<double> eps_im(static_cast<std::size_t>(n), 0.0);

  for (int j = 0; j < n; ++j) {
    const double zc = 0.5 * (z_edges[static_cast<std::size_t>(j)] + z_edges[static_cast<std::size_t>(j + 1)]);
    if (zc < L) {
      const double xi = zc / L;
      // A smooth dielectric profile for a robust angle scan demo.
      const std::complex<double> eps_a{1.0, 0.0};
      const std::complex<double> eps_b{2.2, 0.08};
      const std::complex<double> eps = eps_a + xi * (eps_b - eps_a);
      eps_re[static_cast<std::size_t>(j)] = eps.real();
      eps_im[static_cast<std::size_t>(j)] = eps.imag();
    } else {
      eps_re[static_cast<std::size_t>(j)] = 3.56;
      eps_im[static_cast<std::size_t>(j)] = 0.2;
    }
  }

  hh::SolveOptions base;
  base.wavelength = 1.0;
  base.incident_power = 1.0;
  base.epsilon_left_real = 1.0;
  base.epsilon_right_real = 3.56;
  base.use_custom_right_epsilon = true;
  base.apply_basko_rescaling = true;

  std::filesystem::create_directories("out");
  std::ofstream out("out/angle_scan.csv");
  if (!out) {
    std::cerr << "Failed to open out/angle_scan.csv\n";
    return 1;
  }

  out << "angle_deg,A_s,A_p,R_s,R_p,T_s,T_p\n";
  out << std::setprecision(16);

  for (int angle = 0; angle <= 80; angle += 2) {
    hh::SolveOptions s_opt = base;
    s_opt.polarization = hh::Polarization::S;
    s_opt.incidence_angle_deg = static_cast<double>(angle);

    hh::SolveOptions p_opt = base;
    p_opt.polarization = hh::Polarization::P;
    p_opt.incidence_angle_deg = static_cast<double>(angle);

    const hh::Result s = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, s_opt);
    const hh::Result p = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, p_opt);

    out << angle << "," << sum_vec(s.absorption_fraction_rescaled) << ","
        << sum_vec(p.absorption_fraction_rescaled) << "," << s.reflected_fraction << ","
        << p.reflected_fraction << "," << s.transmitted_fraction_rescaled << ","
        << p.transmitted_fraction_rescaled << "\n";
  }

  std::cout << "Wrote angle scan to out/angle_scan.csv\n";
  return 0;
}
