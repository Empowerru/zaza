#include <cmath>
#include <complex>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <vector>

#include "hh/helmholtz_1d.hpp"

namespace {

constexpr double kPi = 3.141592653589793238462643383279502884;

std::vector<double> linspace(double a, double b, int n) {
  std::vector<double> x(static_cast<std::size_t>(n));
  if (n <= 1) {
    x[0] = a;
    return x;
  }
  for (int i = 0; i < n; ++i) {
    x[static_cast<std::size_t>(i)] = a + (b - a) * static_cast<double>(i) / static_cast<double>(n - 1);
  }
  return x;
}

}  // namespace

int main() {
  constexpr double wavelength = 1.0;
  constexpr int n = 220;
  constexpr double z_max = 3.0;
  constexpr double L = 1.0;

  std::vector<double> z_edges = linspace(0.0, z_max, n + 1);
  std::vector<double> eps_re(static_cast<std::size_t>(n), 0.0);
  std::vector<double> eps_im(static_cast<std::size_t>(n), 0.0);

  for (int j = 0; j < n; ++j) {
    const double zc = 0.5 * (z_edges[static_cast<std::size_t>(j)] + z_edges[static_cast<std::size_t>(j + 1)]);
    if (zc < 2.0 * L) {
      const double xi = zc / (2.0 * L);
      const std::complex<double> eps21{-1.0, 0.1};
      const std::complex<double> eps = std::complex<double>(1.0, 0.0) + xi * (eps21 - std::complex<double>(1.0, 0.0));
      eps_re[static_cast<std::size_t>(j)] = eps.real();
      eps_im[static_cast<std::size_t>(j)] = eps.imag();
    } else {
      eps_re[static_cast<std::size_t>(j)] = -54.56;
      eps_im[static_cast<std::size_t>(j)] = 67.2;
    }
  }

  hh::SolveOptions opt;
  opt.polarization = hh::Polarization::S;
  opt.incidence_angle_deg = 30.0;
  opt.wavelength = wavelength;
  opt.incident_power = 1.0;
  opt.epsilon_left_real = 1.0;
  opt.epsilon_right_real = -54.56;
  opt.use_custom_right_epsilon = true;
  opt.apply_basko_rescaling = true;

  const hh::Result s = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);

  opt.polarization = hh::Polarization::P;
  const hh::Result p = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);

  const auto sum_abs = [](const std::vector<double>& x) { return std::accumulate(x.begin(), x.end(), 0.0); };

  std::cout << std::setprecision(12);
  std::cout << "1D Helmholtz demo profile (Basko-like linear ramp)\n";
  std::cout << "k0 = " << (2.0 * kPi / wavelength) << ", angle = " << opt.incidence_angle_deg << " deg\n\n";

  std::cout << "S-polarization:\n";
  std::cout << "  R = " << s.reflected_fraction << "\n";
  std::cout << "  T = " << s.transmitted_fraction_rescaled << "\n";
  std::cout << "  A = " << sum_abs(s.absorption_fraction_rescaled) << "\n";

  std::cout << "P-polarization:\n";
  std::cout << "  R = " << p.reflected_fraction << "\n";
  std::cout << "  T = " << p.transmitted_fraction_rescaled << "\n";
  std::cout << "  A = " << sum_abs(p.absorption_fraction_rescaled) << "\n\n";

  std::cout << "First 8 heat_source_line values (S):\n";
  for (int i = 0; i < 8 && i < static_cast<int>(s.heat_source_line.size()); ++i) {
    std::cout << "  q[" << i << "] = " << s.heat_source_line[static_cast<std::size_t>(i)] << "\n";
  }

  return 0;
}
