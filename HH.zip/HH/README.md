# HH: Standalone 1D Helmholtz Heat-Source Module

This folder is a self-contained mini-project that extracts only the WO/Helmholtz part.

API goal:
- input: `eps_real[j]`, `eps_imag[j]`, `z_edges[j]` (`N+1` edges for `N` cells), angle, polarization
- output: per-cell deposited power and heat source

Main header:
- `include/hh/helmholtz_1d.hpp`

Main solver:
- `src/helmholtz_1d.cpp`

## Build

From project root (compatible with your CMake 3.11):

```bash
mkdir -p HH/build
cd HH/build
cmake ..
cmake --build . -- -j6
```

Run tests:

```bash
cd HH/build
ctest --output-on-failure
```

Run examples:

```bash
cd HH/build
./hh_example_basic
./hh_example_angle_scan
```

The angle-scan example writes:
- `HH/build/out/angle_scan.csv` (if run from `HH/build`)

## Minimal Usage (C++)

```cpp
#include <vector>
#include "hh/helmholtz_1d.hpp"

std::vector<double> z_edges = {0.0, 0.1, 0.2, 0.3}; // N+1
std::vector<double> eps_re  = {1.0, 0.3, -0.5};     // N
std::vector<double> eps_im  = {0.0, 0.05, 0.1};     // N

hh::SolveOptions opt;
opt.polarization = hh::Polarization::P;  // or S
opt.incidence_angle_deg = 35.0;
opt.wavelength = 1.0;
opt.incident_power = 1.0;
opt.epsilon_left_real = 1.0;
opt.epsilon_right_real = -10.0;
opt.use_custom_right_epsilon = true;

hh::Result res = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);

// res.deposited_power_cell[j]
// res.heat_source_line[j] = deposited_power_cell[j] / cell_length
```

## Using It In Another CMake Project

If your other project can include this folder:

```cmake
add_subdirectory(path/to/HH)
target_link_libraries(your_target PRIVATE hh::helmholtz_1d)
```

Then include:

```cpp
#include "hh/helmholtz_1d.hpp"
```

## Fast No-CMake Build (single file app)

```bash
c++ -std=c++17 -IHH/include your_app.cpp HH/src/helmholtz_1d.cpp -o your_app
```

## Notes

- Supports both `S` and `P` polarization (`hh::Polarization`).
- Supports oblique incidence via `incidence_angle_deg`.
- Uses Basko-style rescaling by default (`apply_basko_rescaling=true`).
- Returns both raw and rescaled absorption fractions, plus absolute deposited power for your chosen `incident_power`.

Numerical tip:
- For `P` polarization, if your profile passes very close to `epsilon = 0` with tiny imaginary part, terms with `1/epsilon` can become very stiff. Start with a finite `eps_imag` and refine gradually.
