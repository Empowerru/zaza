#include <cmath>
#include <complex>
#include <cstdlib>
#include <exception>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>

#include "hh/helmholtz_1d.hpp"

namespace {

void require(bool cond, const char* msg) {
  if (!cond) {
    throw std::runtime_error(msg);
  }
}

bool near(double a, double b, double tol) { return std::abs(a - b) <= tol; }

std::vector<double> linspace(double a, double b, int n) {
  std::vector<double> x(static_cast<std::size_t>(n));
  for (int i = 0; i < n; ++i) {
    x[static_cast<std::size_t>(i)] = a + (b - a) * static_cast<double>(i) / static_cast<double>(n - 1);
  }
  return x;
}

double sum_vec(const std::vector<double>& x) { return std::accumulate(x.begin(), x.end(), 0.0); }

void test_input_validation() {
  bool threw = false;
  try {
    const std::vector<double> z_edges = {0.0, 1.0, 2.0};
    const std::vector<double> eps_re = {1.0, 0.5};
    const std::vector<double> eps_im = {0.0};
    (void)hh::solve_helmholtz_1d(z_edges, eps_re, eps_im);
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  require(threw, "validation should reject mismatched vector sizes");
}

void test_lossless_energy_conservation() {
  constexpr int n = 200;
  const std::vector<double> z_edges = linspace(0.0, 4.0, n + 1);
  const std::vector<double> eps_re(static_cast<std::size_t>(n), 1.0);
  const std::vector<double> eps_im(static_cast<std::size_t>(n), 0.0);

  hh::SolveOptions opt;
  opt.polarization = hh::Polarization::S;
  opt.incidence_angle_deg = 37.0;
  opt.epsilon_left_real = 1.0;
  opt.epsilon_right_real = 1.0;
  opt.use_custom_right_epsilon = true;
  opt.apply_basko_rescaling = true;

  const hh::Result s = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);
  const double a = sum_vec(s.absorption_fraction_rescaled);
  require(std::abs(a) < 1.0e-12, "lossless profile should have zero absorption");
  require(std::abs(s.reflected_fraction) < 1.0e-12, "uniform lossless profile should not reflect");
  require(near(s.transmitted_fraction_rescaled, 1.0, 1.0e-12), "uniform lossless profile should transmit all");

  opt.polarization = hh::Polarization::P;
  const hh::Result p = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);
  const double e = p.reflected_fraction + p.transmitted_fraction_rescaled +
                   sum_vec(p.absorption_fraction_rescaled);
  require(near(e, 1.0, 1.0e-12), "p-pol lossless energy should be conserved");
}

void test_absorbing_profile_deposition() {
  constexpr int n = 180;
  const std::vector<double> z_edges = linspace(0.0, 3.0, n + 1);
  std::vector<double> eps_re(static_cast<std::size_t>(n), 0.0);
  std::vector<double> eps_im(static_cast<std::size_t>(n), 0.0);
  for (int j = 0; j < n; ++j) {
    const double zc = 0.5 * (z_edges[static_cast<std::size_t>(j)] + z_edges[static_cast<std::size_t>(j + 1)]);
    eps_re[static_cast<std::size_t>(j)] = 1.0 - 1.6 * std::min(zc, 1.0);
    eps_im[static_cast<std::size_t>(j)] = 0.03 + 0.02 * std::exp(-2.0 * std::max(0.0, zc - 1.0));
  }

  hh::SolveOptions opt;
  opt.polarization = hh::Polarization::S;
  opt.incidence_angle_deg = 20.0;
  opt.incident_power = 5.0;
  opt.epsilon_left_real = 1.0;
  opt.epsilon_right_real = -10.0;
  opt.use_custom_right_epsilon = true;
  opt.apply_basko_rescaling = true;

  const hh::Result res = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, opt);
  const double a = sum_vec(res.absorption_fraction_rescaled);
  require(a > 0.0, "absorbing profile must deposit positive energy");

  const double dep_sum = sum_vec(res.deposited_power_cell);
  require(near(dep_sum, opt.incident_power * a, 1.0e-11),
          "deposited_power_cell must be incident_power * absorption_fraction");

  for (double q : res.heat_source_line) {
    require(std::isfinite(q), "heat_source_line must be finite");
  }
}

void test_polarization_and_angle_effect() {
  constexpr int n = 220;
  const std::vector<double> z_edges = linspace(0.0, 3.2, n + 1);
  std::vector<double> eps_re(static_cast<std::size_t>(n), 0.0);
  std::vector<double> eps_im(static_cast<std::size_t>(n), 0.0);
  for (int j = 0; j < n; ++j) {
    const double zc = 0.5 * (z_edges[static_cast<std::size_t>(j)] + z_edges[static_cast<std::size_t>(j + 1)]);
    if (zc < 2.0) {
      const double xi = zc / 2.0;
      const std::complex<double> eps = std::complex<double>(1.0, 0.0) +
                                       xi * (std::complex<double>(-1.0, 0.05) - std::complex<double>(1.0, 0.0));
      eps_re[static_cast<std::size_t>(j)] = eps.real();
      eps_im[static_cast<std::size_t>(j)] = eps.imag();
    } else {
      eps_re[static_cast<std::size_t>(j)] = -54.56;
      eps_im[static_cast<std::size_t>(j)] = 67.2;
    }
  }

  hh::SolveOptions s_opt;
  s_opt.polarization = hh::Polarization::S;
  s_opt.incidence_angle_deg = 55.0;
  s_opt.epsilon_left_real = 1.0;
  s_opt.epsilon_right_real = -54.56;
  s_opt.use_custom_right_epsilon = true;

  hh::SolveOptions p_opt = s_opt;
  p_opt.polarization = hh::Polarization::P;

  const hh::Result s = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, s_opt);
  const hh::Result p = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, p_opt);

  const double a_s = sum_vec(s.absorption_fraction_rescaled);
  const double a_p = sum_vec(p.absorption_fraction_rescaled);
  require(std::abs(a_s - a_p) > 1.0e-4, "oblique s/p absorption should differ");

  s_opt.incidence_angle_deg = 5.0;
  const hh::Result s_low = hh::solve_helmholtz_1d(z_edges, eps_re, eps_im, s_opt);
  const double a_low = sum_vec(s_low.absorption_fraction_rescaled);
  require(std::abs(a_low - a_s) > 1.0e-4, "angle change should alter absorption");
}

}  // namespace

int main() {
  try {
    test_input_validation();
    test_lossless_energy_conservation();
    test_absorbing_profile_deposition();
    test_polarization_and_angle_effect();
    std::cout << "HH tests passed\n";
    return EXIT_SUCCESS;
  } catch (const std::exception& ex) {
    std::cerr << "HH test failure: " << ex.what() << "\n";
    return EXIT_FAILURE;
  }
}
