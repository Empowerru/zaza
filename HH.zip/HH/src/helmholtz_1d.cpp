#include "hh/helmholtz_1d.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

namespace hh {
namespace {

constexpr double kPi = 3.141592653589793238462643383279502884;

struct CMat2 {
  std::complex<double> m00{1.0, 0.0};
  std::complex<double> m01{0.0, 0.0};
  std::complex<double> m10{0.0, 0.0};
  std::complex<double> m11{1.0, 0.0};
};

struct CVec2 {
  std::complex<double> v0{0.0, 0.0};
  std::complex<double> v1{0.0, 0.0};
};

CMat2 mul(const CMat2& a, const CMat2& b) {
  CMat2 c;
  c.m00 = a.m00 * b.m00 + a.m01 * b.m10;
  c.m01 = a.m00 * b.m01 + a.m01 * b.m11;
  c.m10 = a.m10 * b.m00 + a.m11 * b.m10;
  c.m11 = a.m10 * b.m01 + a.m11 * b.m11;
  return c;
}

CVec2 mul(const CMat2& a, const CVec2& x) {
  return {a.m00 * x.v0 + a.m01 * x.v1, a.m10 * x.v0 + a.m11 * x.v1};
}

double clamp(double x, double lo, double hi) { return std::min(std::max(x, lo), hi); }

std::complex<double> kappa_branch(std::complex<double> x) {
  std::complex<double> k = std::sqrt(x);
  // Basko Eq. (10): branch Im(kappa) >= 0 for decaying evanescent field.
  if (k.imag() < 0.0) {
    k = -k;
  }
  return k;
}

double sum_vec(const std::vector<double>& x) {
  return std::accumulate(x.begin(), x.end(), 0.0);
}

void validate_input(const std::vector<double>& z_edges, const std::vector<double>& eps_real,
                    const std::vector<double>& eps_imag, const SolveOptions& opt) {
  if (z_edges.size() < 2) {
    throw std::invalid_argument("z_edges must have at least two points");
  }
  if (eps_real.size() + 1 != z_edges.size() || eps_imag.size() + 1 != z_edges.size()) {
    throw std::invalid_argument("eps_real/eps_imag size must be z_edges.size()-1");
  }
  for (std::size_t i = 1; i < z_edges.size(); ++i) {
    if (!(z_edges[i] > z_edges[i - 1])) {
      throw std::invalid_argument("z_edges must be strictly increasing");
    }
  }
  if (!(opt.wavelength > 0.0)) {
    throw std::invalid_argument("wavelength must be > 0");
  }
  if (!(opt.epsilon_left_real > 0.0)) {
    throw std::invalid_argument("epsilon_left_real must be > 0");
  }
  if (!(opt.incident_power >= 0.0)) {
    throw std::invalid_argument("incident_power must be >= 0");
  }
}

}  // namespace

Result solve_helmholtz_1d(const std::vector<double>& z_edges, const std::vector<double>& eps_real,
                          const std::vector<double>& eps_imag, const SolveOptions& opt) {
  validate_input(z_edges, eps_real, eps_imag, opt);

  const int n = static_cast<int>(eps_real.size());
  if (n == 0) {
    Result out;
    out.reflected_fraction = 0.0;
    out.transmitted_fraction = 1.0;
    out.transmitted_fraction_rescaled = 1.0;
    return out;
  }

  const double k0 = 2.0 * kPi / opt.wavelength;

  const double theta = opt.incidence_angle_deg * kPi / 180.0;
  const double cos_theta = clamp(std::abs(std::cos(theta)), 0.0, 1.0);
  const double sin2_theta = 1.0 - cos_theta * cos_theta;

  const double eps0 = std::max(opt.epsilon_left_real, opt.epsilon_floor);
  double eps_inf = opt.use_custom_right_epsilon ? opt.epsilon_right_real : eps_real.back();
  if (std::abs(eps_inf) < opt.epsilon_floor) {
    eps_inf = (eps_inf >= 0.0 ? 1.0 : -1.0) * opt.epsilon_floor;
  }

  std::vector<std::complex<double>> eps(static_cast<std::size_t>(n + 2));
  eps[0] = {eps0, 0.0};
  for (int j = 1; j <= n; ++j) {
    eps[static_cast<std::size_t>(j)] =
        std::complex<double>(eps_real[static_cast<std::size_t>(j - 1)],
                             eps_imag[static_cast<std::size_t>(j - 1)]);
  }
  eps[static_cast<std::size_t>(n + 1)] = {eps_inf, 0.0};

  std::vector<double> dz_bar(static_cast<std::size_t>(n + 1), 0.0);
  std::vector<double> dz(static_cast<std::size_t>(n + 1), 0.0);
  for (int j = 1; j <= n; ++j) {
    const double dj = z_edges[static_cast<std::size_t>(j)] - z_edges[static_cast<std::size_t>(j - 1)];
    dz[static_cast<std::size_t>(j)] = dj;
    dz_bar[static_cast<std::size_t>(j)] = k0 * dj;
  }

  std::vector<std::complex<double>> kappa(static_cast<std::size_t>(n + 2));
  for (int j = 0; j <= n + 1; ++j) {
    kappa[static_cast<std::size_t>(j)] =
        kappa_branch(eps[static_cast<std::size_t>(j)] - std::complex<double>(eps0 * sin2_theta, 0.0));
  }
  if (std::abs(kappa[0]) < opt.linear_tol) {
    kappa[0] = {opt.linear_tol, 0.0};
  }

  std::vector<std::complex<double>> gamma(static_cast<std::size_t>(n + 1));
  std::vector<std::complex<double>> beta(static_cast<std::size_t>(n + 2));
  std::vector<double> sigma(static_cast<std::size_t>(n + 1), 0.0);
  std::vector<CMat2> g_mat(static_cast<std::size_t>(n + 1));

  CMat2 h_hat{};
  double sigma_sum = 0.0;
  std::complex<double> gamma_product{1.0, 0.0};

  for (int j = 0; j <= n; ++j) {
    const std::size_t ju = static_cast<std::size_t>(j);
    const std::complex<double> kj = kappa[ju];
    const std::complex<double> kj1 = kappa[ju + 1];

    if (opt.polarization == Polarization::S) {
      // Basko Eq. (17), s-polarization.
      gamma[ju] = kj / kj1;
    } else {
      // Basko Eq. (17), p-polarization.
      gamma[ju] = (kj * eps[ju + 1]) / (kj1 * eps[ju]);
    }

    // Basko Eq. (16).
    const std::complex<double> delta = std::complex<double>(0.0, 1.0) * kj * dz_bar[ju];
    const std::complex<double> exp_p = std::exp(delta);
    const std::complex<double> exp_m = std::exp(-delta);

    // Basko Eq. (15).
    CMat2 g{};
    g.m00 = 0.5 * (1.0 + gamma[ju]) * exp_p;
    g.m01 = 0.5 * (1.0 - gamma[ju]) * exp_m;
    g.m10 = 0.5 * (1.0 - gamma[ju]) * exp_p;
    g.m11 = 0.5 * (1.0 + gamma[ju]) * exp_m;
    g_mat[ju] = g;

    // Appendix A Eqs. (A.1)-(A.3) scaling for numerical robustness.
    sigma[ju] = std::max(0.0, kappa[ju].imag() * dz_bar[ju]);
    const double f = std::exp(-sigma[ju]);
    CMat2 g_hat{};
    g_hat.m00 = f * g.m00;
    g_hat.m01 = f * g.m01;
    g_hat.m10 = f * g.m10;
    g_hat.m11 = f * g.m11;

    h_hat = mul(g_hat, h_hat);
    sigma_sum += sigma[ju];
    gamma_product *= gamma[ju];
  }

  if (std::abs(h_hat.m11) < opt.linear_tol) {
    throw std::runtime_error("Helmholtz solve failed: near-singular transfer matrix");
  }

  // Appendix A Eq. (A.4).
  const std::complex<double> r = -h_hat.m10 / h_hat.m11;
  const std::complex<double> p = -std::exp(-sigma_sum) * gamma_product / h_hat.m11;

  std::vector<CVec2> b(static_cast<std::size_t>(n + 2));
  std::vector<double> scale(static_cast<std::size_t>(n + 2), 0.0);
  b[0] = {{1.0, 0.0}, r};

  for (int j = 0; j <= n; ++j) {
    const std::size_t ju = static_cast<std::size_t>(j);
    const CVec2 raw = mul(g_mat[ju], b[ju]);
    const double max_a = std::max({std::abs(raw.v0), std::abs(raw.v1), 1.0});
    const double s = std::log(max_a);
    const double inv = std::exp(-s);
    b[ju + 1].v0 = raw.v0 * inv;
    b[ju + 1].v1 = raw.v1 * inv;
    scale[ju + 1] = scale[ju] + s;
  }

  for (int j = 1; j <= n + 1; ++j) {
    const std::size_t ju = static_cast<std::size_t>(j);
    if (opt.polarization == Polarization::S) {
      // Basko Eq. (28), s-polarization.
      beta[ju] = kappa[ju] / kappa[0];
    } else {
      // Basko Eq. (28), p-polarization.
      beta[ju] = (kappa[ju] * eps0) / (kappa[0] * eps[ju]);
    }
  }

  Result out;
  // Basko Eqs. (23)-(24).
  out.reflected_fraction = std::norm(r);
  out.transmitted_fraction = std::max(0.0, beta[static_cast<std::size_t>(n + 1)].real() * std::norm(p));

  out.absorption_fraction_raw.assign(static_cast<std::size_t>(n), 0.0);
  std::vector<double> fa_sec(static_cast<std::size_t>(n), 0.0);
  std::vector<double> fa_osc(static_cast<std::size_t>(n), 0.0);

  for (int j = 1; j <= n; ++j) {
    const std::size_t ju = static_cast<std::size_t>(j);
    const double growth = std::exp(std::min(2.0 * scale[ju], 600.0));
    const double two_sigma = 2.0 * sigma[ju];

    // Basko Eq. (26): secular contribution.
    const double sec_a = std::norm(b[ju].v0) * (1.0 - std::exp(-two_sigma));
    const double sec_b = std::norm(b[ju].v1) * (std::exp(two_sigma) - 1.0);
    const double f_sec = beta[ju].real() * growth * (sec_a + sec_b);

    // Basko Eq. (27): oscillatory interference contribution.
    const std::complex<double> phase =
        std::exp(std::complex<double>(0.0, 2.0 * kappa[ju].real() * dz_bar[ju])) -
        std::complex<double>(1.0, 0.0);
    const std::complex<double> inter = b[ju].v0 * std::conj(b[ju].v1) * phase;
    const double f_osc = 2.0 * beta[ju].imag() * growth * inter.imag();

    fa_sec[ju - 1] = f_sec;
    fa_osc[ju - 1] = f_osc;
    out.absorption_fraction_raw[ju - 1] = f_sec + f_osc;
  }

  out.absorption_fraction_rescaled = out.absorption_fraction_raw;
  out.transmitted_fraction_rescaled = out.transmitted_fraction;

  if (opt.apply_basko_rescaling) {
    out.absorption_fraction_rescaled.assign(static_cast<std::size_t>(n), 0.0);
    const double fa_osc_sum = sum_vec(fa_osc);

    if (fa_osc_sum <= 0.0) {
      // Basko Sec. 2.4, Eqs. (36)-(38): cutoff of secular tail.
      double remaining = std::max(0.0, 1.0 - out.reflected_fraction);
      for (int j = 0; j < n; ++j) {
        const double sec = std::max(0.0, fa_sec[static_cast<std::size_t>(j)]);
        const double take = std::min(sec, remaining);
        out.absorption_fraction_rescaled[static_cast<std::size_t>(j)] = take;
        remaining -= take;
        if (remaining <= 0.0) {
          break;
        }
      }
      out.transmitted_fraction_rescaled =
          std::max(0.0, 1.0 - out.reflected_fraction - sum_vec(out.absorption_fraction_rescaled));
    } else {
      // Basko Sec. 2.4, Eqs. (39)-(41): positive-part oscillatory renormalization.
      std::vector<double> fhat(static_cast<std::size_t>(n), 0.0);
      double pos_sum = 0.0;
      for (int j = 0; j < n; ++j) {
        fhat[static_cast<std::size_t>(j)] = std::max(0.0, fa_osc[static_cast<std::size_t>(j)]);
        pos_sum += fhat[static_cast<std::size_t>(j)];
      }
      const double alpha_osc = (pos_sum > opt.linear_tol) ? clamp(fa_osc_sum / pos_sum, 0.0, 1.0) : 0.0;
      for (int j = 0; j < n; ++j) {
        out.absorption_fraction_rescaled[static_cast<std::size_t>(j)] =
            fa_sec[static_cast<std::size_t>(j)] + alpha_osc * fhat[static_cast<std::size_t>(j)];
      }
      out.transmitted_fraction_rescaled = out.transmitted_fraction;
    }
  }

  const double total =
      out.reflected_fraction + out.transmitted_fraction_rescaled + sum_vec(out.absorption_fraction_rescaled);
  const double delta = 1.0 - total;
  if (std::abs(delta) < 1.0e-10) {
    out.transmitted_fraction_rescaled = std::max(0.0, out.transmitted_fraction_rescaled + delta);
  }

  out.deposited_power_cell.resize(static_cast<std::size_t>(n), 0.0);
  out.heat_source_line.resize(static_cast<std::size_t>(n), 0.0);
  for (int j = 0; j < n; ++j) {
    const double dep = opt.incident_power * out.absorption_fraction_rescaled[static_cast<std::size_t>(j)];
    out.deposited_power_cell[static_cast<std::size_t>(j)] = dep;
    const double dj = dz[static_cast<std::size_t>(j + 1)];
    out.heat_source_line[static_cast<std::size_t>(j)] = (dj > 0.0) ? (dep / dj) : 0.0;
  }

  return out;
}

}  // namespace hh
