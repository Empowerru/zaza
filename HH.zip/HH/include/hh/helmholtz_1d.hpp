#pragma once

#include <vector>

namespace hh {

enum class Polarization { S, P };

struct SolveOptions {
  Polarization polarization = Polarization::S;

  // Incidence angle in degrees. 0 means normal incidence.
  double incidence_angle_deg = 0.0;

  // Wavelength in the same length units as z_edges.
  double wavelength = 1.0;

  // Incoming power used to scale deposited_power_cell.
  double incident_power = 1.0;

  // Boundary dielectric values required by the 1D Helmholtz model.
  // epsilon_left_real must be positive.
  double epsilon_left_real = 1.0;

  // If not finite, epsilon_right_real is taken from eps_real.back().
  double epsilon_right_real = 0.0;
  bool use_custom_right_epsilon = false;

  // Apply Basko Sec. 2.4 rescaling of WO absorption profile.
  bool apply_basko_rescaling = true;

  // Numerical floors.
  double epsilon_floor = 1.0e-12;
  double linear_tol = 1.0e-14;
};

struct Result {
  // Fractions relative to incident power flux.
  double reflected_fraction = 0.0;
  double transmitted_fraction = 0.0;
  double transmitted_fraction_rescaled = 0.0;

  // Per-cell absorption fractions.
  std::vector<double> absorption_fraction_raw;
  std::vector<double> absorption_fraction_rescaled;

  // Absolute deposited power per cell: incident_power * absorption_fraction_rescaled[j].
  std::vector<double> deposited_power_cell;

  // Heat source along 1D coordinate, per unit length in each cell.
  // heat_source_line[j] = deposited_power_cell[j] / (z_edges[j+1] - z_edges[j]).
  std::vector<double> heat_source_line;
};

// Solve 1D Helmholtz WO deposition on piecewise-constant epsilon profile.
//
// Input arrays:
// - z_edges: size N+1, strictly increasing.
// - eps_real, eps_imag: size N (one value per cell).
//
// Returns reflected/transmitted fractions and cell heat source.
Result solve_helmholtz_1d(const std::vector<double>& z_edges, const std::vector<double>& eps_real,
                          const std::vector<double>& eps_imag,
                          const SolveOptions& options = SolveOptions{});

}  // namespace hh
