# 1D Radiation Transport Testbench

This folder contains a standalone test driver for your solver function:

```cpp
void get_radiation_transport(
    const int Ncells,
    const std::vector<double>& record,
    const int radGroups,
    const std::vector<double>& omegas,
    const std::vector<double>& kapP,
    const std::vector<double>& emiss,
    std::vector<double>& Quad,
    std::vector<double>& WL,
    std::vector<double>& WR
);
```

The driver reads inputs from text files, runs your solver, writes outputs, and prints diagnostics.

## Input files

Default input directory: `testbench/input`

- `record.txt`: `Ncells+1` cell boundaries (cm), strictly increasing
- `omegas.txt`: `radGroups+1` group boundaries (eV), strictly increasing
- `kapP.txt`: `Ncells * radGroups` values in cell-major layout:
  `idx = i * radGroups + k`, units `1/cm`
- `emiss.txt`: `Ncells * radGroups` values in same layout, units `TW/(cm^3 sr eV)`

You can use spaces/newlines freely. `#` starts a comment.

## Output files

Default output directory: `testbench/output`

- `Quad.txt`: heating per cell `[kW/cm^3]`
- `WL.txt`: left outgoing spectral flux per group `[W/(cm^2 eV)]`
- `WR.txt`: right outgoing spectral flux per group `[W/(cm^2 eV)]`

## Linux compile

From repo root, compile the testbench with your solver file:

```bash
g++ -std=c++17 -O3 -Wall -Wextra -pedantic \
  testbench/radtrans_testbench.cpp rad_trans_oned.cpp \
  -o testbench/run_rt
```

Or use the provided Makefile:

```bash
cd testbench
make SOLVER=../rad_trans_oned.cpp
```

If your compiler is old (e.g. GCC 7/8), use:

```bash
g++ -std=c++17 -O3 -Wall -Wextra -pedantic \
  testbench/radtrans_testbench.cpp rad_trans_oned.cpp \
  -o testbench/run_rt -lstdc++fs
```

## Run

Use default paths:

```bash
./testbench/run_rt
```

If built via Makefile:

```bash
cd testbench
./run_rt
```

Or custom paths:

```bash
./testbench/run_rt /path/to/input_dir /path/to/output_dir
```

## Data layout reminder

For `Ncells=3`, `radGroups=2`, flattened order in `kapP.txt` and `emiss.txt` is:

```text
cell0_g0 cell0_g1
cell1_g0 cell1_g1
cell2_g0 cell2_g1
```
