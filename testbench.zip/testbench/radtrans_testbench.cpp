#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

void get_radiation_transport(
    const int Ncells,
    const std::vector<double>& record,
    const int radGroups,
    const std::vector<double>& omegas,
    const std::vector<double>& kapP,
    const std::vector<double>& emiss,
    std::vector<double>& Quad,
    std::vector<double>& WL,
    std::vector<double>& WR
);

namespace {

bool file_exists(const std::string& path) {
    std::ifstream f(path);
    return static_cast<bool>(f);
}

std::vector<double> read_doubles(const std::string& path) {
    std::ifstream in(path);
    if (!in) {
        throw std::runtime_error("Cannot open input file: " + path);
    }

    std::vector<double> values;
    std::string line;
    std::size_t line_no = 0;
    while (std::getline(in, line)) {
        ++line_no;
        const std::size_t hash_pos = line.find('#');
        if (hash_pos != std::string::npos) {
            line.erase(hash_pos);
        }

        std::istringstream iss(line);
        std::string token;
        while (iss >> token) {
            try {
                std::size_t pos = 0;
                const double v = std::stod(token, &pos);
                if (pos != token.size()) {
                    throw std::runtime_error("Invalid numeric token");
                }
                values.push_back(v);
            } catch (const std::exception&) {
                throw std::runtime_error(
                    "Parse error in " + path + " at line " + std::to_string(line_no) +
                    ": token='" + token + "'");
            }
        }
    }

    return values;
}

void write_vector(const std::string& path, const std::vector<double>& v, const std::string& header) {
    std::ofstream out(path);
    if (!out) {
        throw std::runtime_error("Cannot open output file: " + path);
    }
    out << std::setprecision(17);
    if (!header.empty()) {
        out << "# " << header << "\n";
        out << "# index value\n";
    }
    for (std::size_t i = 0; i < v.size(); ++i) {
        out << i << " " << v[i] << "\n";
    }
}

double integrate_spectral_flux(const std::vector<double>& spec, const std::vector<double>& omegas) {
    double total = 0.0;
    for (std::size_t k = 0; k < spec.size(); ++k) {
        total += spec[k] * (omegas[k + 1] - omegas[k]);
    }
    return total;
}

}  // namespace

int main(int argc, char** argv) {
    try {
        std::string input_dir;
        std::string output_dir;
        if (argc > 1) {
            input_dir = argv[1];
        } else if (file_exists("testbench/input/record.txt")) {
            input_dir = "testbench/input";
        } else {
            input_dir = "input";
        }
        if (argc > 2) {
            output_dir = argv[2];
        } else if (input_dir == "input") {
            output_dir = "output";
        } else {
            output_dir = "testbench/output";
        }

        const std::vector<double> record = read_doubles(input_dir + "/record.txt");
        const std::vector<double> omegas = read_doubles(input_dir + "/omegas.txt");
        const std::vector<double> kapP = read_doubles(input_dir + "/kapP.txt");
        const std::vector<double> emiss = read_doubles(input_dir + "/emiss.txt");

        if (record.size() < 2) {
            throw std::runtime_error("record.txt must contain at least 2 boundaries.");
        }
        if (omegas.size() < 2) {
            throw std::runtime_error("omegas.txt must contain at least 2 boundaries.");
        }

        const int Ncells = static_cast<int>(record.size() - 1);
        const int radGroups = static_cast<int>(omegas.size() - 1);
        const std::size_t expected = static_cast<std::size_t>(Ncells) * static_cast<std::size_t>(radGroups);

        if (kapP.size() != expected) {
            throw std::runtime_error(
                "kapP.txt count mismatch: got " + std::to_string(kapP.size()) +
                ", expected " + std::to_string(expected) +
                " (= Ncells * radGroups).");
        }
        if (emiss.size() != expected) {
            throw std::runtime_error(
                "emiss.txt count mismatch: got " + std::to_string(emiss.size()) +
                ", expected " + std::to_string(expected) +
                " (= Ncells * radGroups).");
        }

        for (int i = 0; i < Ncells; ++i) {
            if (record[static_cast<std::size_t>(i + 1)] <= record[static_cast<std::size_t>(i)]) {
                throw std::runtime_error("record must be strictly increasing.");
            }
        }
        for (int k = 0; k < radGroups; ++k) {
            if (omegas[static_cast<std::size_t>(k + 1)] <= omegas[static_cast<std::size_t>(k)]) {
                throw std::runtime_error("omegas must be strictly increasing.");
            }
        }

        std::vector<double> Quad(static_cast<std::size_t>(Ncells), 0.0);
        std::vector<double> WL(static_cast<std::size_t>(radGroups), 0.0);
        std::vector<double> WR(static_cast<std::size_t>(radGroups), 0.0);

        get_radiation_transport(Ncells, record, radGroups, omegas, kapP, emiss, Quad, WL, WR);

        write_vector(output_dir + "/Quad.txt", Quad, "Cell heating Quad [kW/cm^3]");
        write_vector(output_dir + "/WL.txt", WL, "Left outgoing spectral flux WL [W/(cm^2 eV)]");
        write_vector(output_dir + "/WR.txt", WR, "Right outgoing spectral flux WR [W/(cm^2 eV)]");

        double q_min = std::numeric_limits<double>::infinity();
        double q_max = -std::numeric_limits<double>::infinity();
        double q_net_wcm2 = 0.0;
        for (int i = 0; i < Ncells; ++i) {
            const double q = Quad[static_cast<std::size_t>(i)];
            q_min = std::min(q_min, q);
            q_max = std::max(q_max, q);
            const double dz = record[static_cast<std::size_t>(i + 1)] - record[static_cast<std::size_t>(i)];
            q_net_wcm2 += q * dz * 1.0e3;  // kW/cm^3 * cm -> W/cm^2
        }

        const double wl_int = integrate_spectral_flux(WL, omegas);  // W/cm^2
        const double wr_int = integrate_spectral_flux(WR, omegas);  // W/cm^2

        std::cout << std::setprecision(10);
        std::cout << "Run complete.\n";
        std::cout << "  Ncells      = " << Ncells << "\n";
        std::cout << "  radGroups   = " << radGroups << "\n";
        std::cout << "  Quad min/max [kW/cm^3] = " << q_min << " / " << q_max << "\n";
        std::cout << "  Integral(Quad dz) [W/cm^2] = " << q_net_wcm2 << "\n";
        std::cout << "  Integral(WL dω) [W/cm^2]   = " << wl_int << "\n";
        std::cout << "  Integral(WR dω) [W/cm^2]   = " << wr_int << "\n";
        std::cout << "Output files:\n";
        std::cout << "  " << output_dir << "/Quad.txt\n";
        std::cout << "  " << output_dir << "/WL.txt\n";
        std::cout << "  " << output_dir << "/WR.txt\n";
    } catch (const std::exception& e) {
        std::cerr << "ERROR: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
