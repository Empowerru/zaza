# dima_laser_standalone

Minimal standalone testbench for `dima_laser` (normal incidence, s-pol).

## Files

- `dima_laser.cpp`, `dima_laser.hpp`: solver
- `main.cpp`: CLI testbench
- `sample_input.csv`: example input file
- `Makefile`: one-command build

## Input format

Text file with 4 columns:

`xl, xr, eps_real, eps_im`

- `xl`, `xr` in **nm**
- `eps_real`, `eps_im` dimensionless
- separators can be comma/space/tab/semicolon
- header line is allowed
- lines starting with `#` are ignored

## Build on Linux

```bash
cd dima_laser_standalone
make
```

If `make` is unavailable:

```bash
g++ -O3 -std=c++17 -Wall -Wextra -pedantic main.cpp dima_laser.cpp -o dima_laser_tb
```

## Run

### 1) Internal manual case from code

```bash
./dima_laser_tb
```

### 2) Read from file

```bash
./dima_laser_tb --input sample_input.csv --lambda-um 10.6
```

### 3) Also print per-cell q[m]

```bash
./dima_laser_tb --input sample_input.csv --lambda-um 10.6 --print-q
```

The program prints:

- `R`
- `T`
- `Q = sum q[m]`
- conservation check `R + T + Q`
