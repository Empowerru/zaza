#pragma once

#include <complex>
#include <vector>

// Normal-incidence, s-polarization-only stabilized TMM.
//
// Inputs:
// - xl, xr: cell left/right boundaries [nm]
// - eps: complex permittivity per cell, same size as xl/xr
// - lambda: wavelength [um]
//
// Outputs:
// - R: reflectivity flux coefficient
// - T: transmission flux coefficient
// - labs[m]: absorbed fraction in cell m
//
// Intended conservation: R + T + sum(labs) ~= 1
void dima_laser(const std::vector<double>& xl, const std::vector<double>& xr,
                const std::vector<std::complex<double>>& eps, const double lambda, double& R, double& T,
                std::vector<double>& labs);
