#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import inspect
import json
import os
import shutil
import sqlite3
import stat
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

tk = None
ttk = None


TERMINAL_FAIL_STATUSES = {
    "failed",
    "timeout",
    "stuck",
    "parse_error",
    "injection_error",
    "launch_error",
}


def ensure_tk() -> None:
    global tk, ttk
    if tk is not None and ttk is not None:
        return
    try:
        import tkinter as _tk
        from tkinter import ttk as _ttk
    except Exception as exc:
        raise RuntimeError(
            "Tkinter is not available in this Python build. "
            "On Windows, install Python from python.org with Tk support."
        ) from exc
    tk = _tk
    ttk = _ttk


@dataclass(slots=True)
class RemoteSource:
    name: str
    remote_login: str
    remote_password: str
    remote_port: int
    remote_db_dir: str
    remote_project_root: str | None = None
    remote_injector_py: str | None = None
    remote_models_py: str | None = None
    remote_blackbox_config_json: str | None = None


@dataclass(slots=True)
class SyncStatus:
    last_attempt: str | None = None
    last_success: str | None = None
    files_seen: int = 0
    files_copied: int = 0
    message: str = "idle"
    last_error: str | None = None


class RemoteDBMirror:
    def __init__(
        self,
        *,
        source_name: str,
        remote_login: str,
        remote_password: str,
        remote_port: int,
        remote_db_dir: str,
        local_dir: Path,
        sync_interval_sec: float,
    ) -> None:
        if "@" not in remote_login:
            raise ValueError(f"source '{source_name}': remote_login must have format user@host")
        self.source_name = source_name
        self.username, self.host = remote_login.split("@", 1)
        self.password = remote_password
        self.port = int(remote_port)
        self.remote_db_dir = remote_db_dir.rstrip("/").rstrip("\\")
        self.local_dir = local_dir
        self.sync_interval_sec = max(5.0, float(sync_interval_sec))
        self.local_dir.mkdir(parents=True, exist_ok=True)

        self._status = SyncStatus(message="starting")
        self._status_lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name=f"remote-db-sync-{source_name}", daemon=True)
        self._last_remote_meta: dict[str, tuple[int, int]] = {}

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5.0)

    def get_status(self) -> SyncStatus:
        with self._status_lock:
            return SyncStatus(
                last_attempt=self._status.last_attempt,
                last_success=self._status.last_success,
                files_seen=self._status.files_seen,
                files_copied=self._status.files_copied,
                message=self._status.message,
                last_error=self._status.last_error,
            )

    def _set_status(self, **kwargs: Any) -> None:
        with self._status_lock:
            for key, value in kwargs.items():
                setattr(self._status, key, value)

    def _loop(self) -> None:
        while not self._stop.is_set():
            now = datetime.now().isoformat(timespec="seconds")
            self._set_status(last_attempt=now, message="syncing", last_error=None)
            try:
                files_seen, files_copied = self._sync_once()
                self._set_status(
                    last_success=datetime.now().isoformat(timespec="seconds"),
                    files_seen=files_seen,
                    files_copied=files_copied,
                    message="ok",
                    last_error=None,
                )
            except Exception as exc:
                self._set_status(message="error", last_error=str(exc))

            self._stop.wait(self.sync_interval_sec)

    def _sync_once(self) -> tuple[int, int]:
        try:
            import paramiko
        except Exception as exc:
            raise RuntimeError(
                "Missing dependency: paramiko. Install with: python -m pip install -r requirements.txt"
            ) from exc

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=self.host,
            port=self.port,
            username=self.username,
            password=self.password if self.password else None,
            look_for_keys=not bool(self.password),
            allow_agent=not bool(self.password),
            timeout=20.0,
            banner_timeout=20.0,
            auth_timeout=20.0,
        )
        files_copied = 0
        remote_names: set[str] = set()
        try:
            sftp = client.open_sftp()
            try:
                entries = sftp.listdir_attr(self.remote_db_dir)
                regular_files = [e for e in entries if stat.S_ISREG(e.st_mode)]
                for entry in regular_files:
                    name = str(entry.filename)
                    remote_names.add(name)
                    remote_path = f"{self.remote_db_dir}/{name}"
                    local_path = self.local_dir / name
                    size = int(entry.st_size)
                    mtime = int(entry.st_mtime)
                    prev = self._last_remote_meta.get(name)
                    if prev == (size, mtime) and local_path.exists():
                        continue

                    part_path = self.local_dir / f"{name}.part"
                    sftp.get(remote_path, str(part_path))
                    os.replace(part_path, local_path)
                    files_copied += 1
                    self._last_remote_meta[name] = (size, mtime)
            finally:
                sftp.close()
        finally:
            client.close()

        for stale in self.local_dir.glob("*.part"):
            stale.unlink(missing_ok=True)

        for local_file in self.local_dir.iterdir():
            if not local_file.is_file():
                continue
            if local_file.name.endswith(".part"):
                continue
            if local_file.name not in remote_names:
                local_file.unlink(missing_ok=True)
                self._last_remote_meta.pop(local_file.name, None)

        for name in list(self._last_remote_meta.keys()):
            if name not in remote_names:
                self._last_remote_meta.pop(name, None)

        return len(remote_names), files_copied


def compute_best_curve(values: list[float], goal: str) -> list[float]:
    best: list[float] = []
    current: float | None = None
    for value in values:
        if current is None:
            current = value
        else:
            if goal == "minimize":
                current = min(current, value)
            else:
                current = max(current, value)
        best.append(current)
    return best


def downsample_xy(xs: list[float], ys: list[float], max_points: int) -> tuple[list[float], list[float]]:
    n = min(len(xs), len(ys))
    if n <= max_points or max_points <= 0:
        return xs[:n], ys[:n]
    step = n / float(max_points)
    out_x: list[float] = []
    out_y: list[float] = []
    i = 0.0
    while int(i) < n:
        idx = int(i)
        out_x.append(xs[idx])
        out_y.append(ys[idx])
        i += step
    if out_x[-1] != xs[n - 1]:
        out_x.append(xs[n - 1])
        out_y.append(ys[n - 1])
    return out_x, out_y


def compute_bounds(values: list[float]) -> tuple[float, float]:
    if not values:
        return 0.0, 1.0
    y_min = min(values)
    y_max = max(values)
    if y_min == y_max:
        pad = 1.0 if y_min == 0.0 else abs(y_min) * 0.1
        return y_min - pad, y_max + pad
    pad = 0.08 * (y_max - y_min)
    return y_min - pad, y_max + pad


def success_rate(total: int, success: int) -> float:
    return (100.0 * success / total) if total > 0 else 0.0


def list_local_databases(local_dir: Path) -> list[tuple[str, Path]]:
    if not local_dir.exists():
        return []
    items: list[tuple[str, Path]] = []
    for p in local_dir.rglob("*"):
        if not p.is_file():
            continue
        if p.name.endswith(".part"):
            continue
        rel = p.relative_to(local_dir).as_posix()
        items.append((rel, p))
    items.sort(key=lambda row: row[0].lower())
    return items


def _table_has_column(conn: sqlite3.Connection, table_name: str, column_name: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    for row in rows:
        if len(row) >= 2 and str(row[1]) == column_name:
            return True
    return False


def load_db_snapshot(db_path: Path, goal: str, max_points: int) -> dict[str, Any]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        has_goal = _table_has_column(conn, "trials", "goal")
        goal_clause = " AND goal = ? " if has_goal else " "
        goal_params: list[Any] = [goal] if has_goal else []

        if has_goal:
            counts_rows = conn.execute(
                "SELECT status, COUNT(*) AS cnt FROM trials WHERE goal = ? GROUP BY status",
                (goal,),
            ).fetchall()
        else:
            counts_rows = conn.execute("SELECT status, COUNT(*) AS cnt FROM trials GROUP BY status").fetchall()

        counts = {str(r["status"]): int(r["cnt"]) for r in counts_rows}
        total = int(sum(counts.values()))
        success = int(counts.get("success", 0))
        failed = int(sum(v for k, v in counts.items() if k in TERMINAL_FAIL_STATUSES))
        finished = success + failed

        order = "ASC" if goal == "minimize" else "DESC"
        best_row = conn.execute(
            f"""
            SELECT trial_id, target_value
            FROM trials
            WHERE status='success' AND target_value IS NOT NULL {goal_clause}
            ORDER BY target_value {order}
            LIMIT 1
            """,
            tuple(goal_params),
        ).fetchone()

        stats_row = conn.execute(
            f"""
            SELECT
                MIN(target_value) AS min_target,
                MAX(target_value) AS max_target,
                AVG(target_value) AS avg_target
            FROM trials
            WHERE status='success' AND target_value IS NOT NULL {goal_clause}
            """,
            tuple(goal_params),
        ).fetchone()

        series_rows = conn.execute(
            f"""
            SELECT trial_id, target_value
            FROM trials
            WHERE status='success' AND target_value IS NOT NULL {goal_clause}
            ORDER BY trial_id DESC
            LIMIT ?
            """,
            tuple(goal_params + [max_points]),
        ).fetchall()
        series_rows = list(reversed(series_rows))
        ys = [float(r["target_value"]) for r in series_rows]
        xs = list(range(1, len(ys) + 1))
        best_curve = compute_best_curve(ys, goal)

        if has_goal:
            last_row = conn.execute(
                """
                SELECT trial_id, status, target_value, runtime_sec, failure_reason
                FROM trials
                WHERE goal = ?
                ORDER BY trial_id DESC
                LIMIT 1
                """,
                (goal,),
            ).fetchone()
        else:
            last_row = conn.execute(
                """
                SELECT trial_id, status, target_value, runtime_sec, failure_reason
                FROM trials
                ORDER BY trial_id DESC
                LIMIT 1
                """
            ).fetchone()

        return {
            "counts": counts,
            "total": total,
            "success": success,
            "failed": failed,
            "finished": finished,
            "success_rate": success_rate(finished, success),
            "best_trial_id": int(best_row["trial_id"]) if best_row is not None else None,
            "best_target": float(best_row["target_value"]) if best_row is not None else None,
            "min_target": float(stats_row["min_target"]) if stats_row is not None and stats_row["min_target"] is not None else None,
            "max_target": float(stats_row["max_target"]) if stats_row is not None and stats_row["max_target"] is not None else None,
            "avg_target": float(stats_row["avg_target"]) if stats_row is not None and stats_row["avg_target"] is not None else None,
            "series_x": xs,
            "series_y": ys,
            "best_curve": best_curve,
            "last_trial": (
                {
                    "trial_id": int(last_row["trial_id"]),
                    "status": str(last_row["status"]),
                    "target_value": float(last_row["target_value"]) if last_row["target_value"] is not None else None,
                    "runtime_sec": float(last_row["runtime_sec"]) if last_row["runtime_sec"] is not None else None,
                    "failure_reason": str(last_row["failure_reason"]) if last_row["failure_reason"] is not None else None,
                }
                if last_row is not None
                else None
            ),
        }
    finally:
        conn.close()


def export_best_params(db_path: Path, goal: str) -> tuple[Path, int | None]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        has_goal = _table_has_column(conn, "trials", "goal")
        order = "ASC" if goal == "minimize" else "DESC"
        if has_goal:
            row = conn.execute(
                f"""
                SELECT trial_id, params_json
                FROM trials
                WHERE goal = ? AND status='success' AND target_value IS NOT NULL
                ORDER BY target_value {order}
                LIMIT 1
                """,
                (goal,),
            ).fetchone()
        else:
            row = conn.execute(
                f"""
                SELECT trial_id, params_json
                FROM trials
                WHERE status='success' AND target_value IS NOT NULL
                ORDER BY target_value {order}
                LIMIT 1
                """
            ).fetchone()
        if row is None:
            raise RuntimeError("No successful trials in selected DB")
        params_json = row["params_json"]
        if params_json is None:
            raise RuntimeError("Best trial has empty params_json")
        params = json.loads(str(params_json))
        out_dir = db_path.parent / "_best_params_exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = out_dir / f"{db_path.stem}_best_params_{stamp}.json"
        out_path.write_text(json.dumps(params, indent=2, sort_keys=True), encoding="utf-8")
        trial_id = int(row["trial_id"]) if row["trial_id"] is not None else None
        return out_path, trial_id
    finally:
        conn.close()


def load_top_params(db_path: Path, goal: str, n: int = 5) -> list[dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        has_goal = _table_has_column(conn, "trials", "goal")
        order = "ASC" if goal == "minimize" else "DESC"
        if has_goal:
            rows = conn.execute(
                f"""
                SELECT trial_id, target_value, params_json
                FROM trials
                WHERE goal = ? AND status='success' AND target_value IS NOT NULL
                ORDER BY target_value {order}
                LIMIT ?
                """,
                (goal, n),
            ).fetchall()
        else:
            rows = conn.execute(
                f"""
                SELECT trial_id, target_value, params_json
                FROM trials
                WHERE status='success' AND target_value IS NOT NULL
                ORDER BY target_value {order}
                LIMIT ?
                """,
                (n,),
            ).fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            pj = row["params_json"]
            if pj is None:
                continue
            out.append(
                {
                    "trial_id": int(row["trial_id"]),
                    "target_value": float(row["target_value"]),
                    "params": json.loads(str(pj)),
                }
            )
        return out
    finally:
        conn.close()


def _join_remote(root: str, rel: str) -> str:
    root = root.rstrip("/").rstrip("\\")
    rel = rel.lstrip("/").lstrip("\\")
    return f"{root}/{rel}"


def _download_remote_file(source: RemoteSource, remote_path: str, local_path: Path) -> None:
    try:
        import paramiko
    except Exception as exc:
        raise RuntimeError(
            "Missing dependency: paramiko. Install with: python -m pip install -r requirements.txt"
        ) from exc

    local_path.parent.mkdir(parents=True, exist_ok=True)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=source.remote_login.split("@", 1)[1],
        port=source.remote_port,
        username=source.remote_login.split("@", 1)[0],
        password=source.remote_password if source.remote_password else None,
        look_for_keys=not bool(source.remote_password),
        allow_agent=not bool(source.remote_password),
        timeout=20.0,
        banner_timeout=20.0,
        auth_timeout=20.0,
    )
    try:
        sftp = client.open_sftp()
        try:
            tmp = local_path.with_suffix(local_path.suffix + ".part")
            sftp.get(remote_path, str(tmp))
            os.replace(tmp, local_path)
        finally:
            sftp.close()
    finally:
        client.close()


def _resolve_remote_support_paths(source: RemoteSource) -> tuple[str, str, str]:
    if source.remote_injector_py and source.remote_models_py and source.remote_blackbox_config_json:
        return source.remote_injector_py, source.remote_models_py, source.remote_blackbox_config_json
    if source.remote_project_root:
        root = source.remote_project_root
        injector = _join_remote(root, "optimizer/adapters/mock_laser_injector.py")
        models = _join_remote(root, "optimizer/models.py")
        bb = _join_remote(root, "config/blackbox_config.json")
        return injector, models, bb
    raise RuntimeError(
        f"Source '{source.name}' missing injector config. "
        "Set remote_project_root or explicit remote_injector_py/remote_models_py/remote_blackbox_config_json."
    )


def _load_remote_injector_runtime(source: RemoteSource, cache_root: Path):
    injector_remote, models_remote, bb_remote = _resolve_remote_support_paths(source)

    runtime_root = cache_root / source.name
    optimizer_pkg = runtime_root / "optimizer"
    adapters_pkg = optimizer_pkg / "adapters"
    optimizer_pkg.mkdir(parents=True, exist_ok=True)
    adapters_pkg.mkdir(parents=True, exist_ok=True)
    (optimizer_pkg / "__init__.py").write_text("", encoding="utf-8")
    (adapters_pkg / "__init__.py").write_text("", encoding="utf-8")

    injector_local = adapters_pkg / "mock_laser_injector.py"
    models_local = optimizer_pkg / "models.py"
    bb_local = runtime_root / "blackbox_config.json"

    _download_remote_file(source, injector_remote, injector_local)
    _download_remote_file(source, models_remote, models_local)
    _download_remote_file(source, bb_remote, bb_local)

    for key in list(sys.modules.keys()):
        if key == "optimizer" or key.startswith("optimizer."):
            del sys.modules[key]

    sys.path.insert(0, str(runtime_root))
    try:
        injector_mod = importlib.import_module("optimizer.adapters.mock_laser_injector")
        models_mod = importlib.import_module("optimizer.models")
    finally:
        if sys.path and sys.path[0] == str(runtime_root):
            sys.path.pop(0)

    bb_data = json.loads(bb_local.read_text(encoding="utf-8"))
    blackbox_cfg = models_mod.BlackboxConfig.from_dict(bb_data)
    return injector_mod, blackbox_cfg


def _call_injector(injector_mod, trial_dir: Path, params: dict[str, Any], blackbox_cfg) -> None:
    candidates = [
        "inject_mock_laser_trial_inputs",
        "inject_parameters",
        "inject_trial_inputs",
    ]
    fn = None
    for name in candidates:
        maybe = getattr(injector_mod, name, None)
        if callable(maybe):
            fn = maybe
            break
    if fn is None:
        raise RuntimeError(
            "No supported injector function found. Expected one of: "
            + ", ".join(candidates)
        )
    sig = inspect.signature(fn)
    n_params = len(sig.parameters)
    if n_params >= 3:
        fn(trial_dir, params, blackbox_cfg)
        return
    if n_params == 2:
        fn(trial_dir, params)
        return
    raise RuntimeError(f"Unsupported injector function signature for {fn.__name__}")


def parse_sources(config: dict[str, Any]) -> list[RemoteSource]:
    raw_sources = config.get("sources")
    sources: list[RemoteSource] = []
    if isinstance(raw_sources, list) and raw_sources:
        seen_names: set[str] = set()
        for i, item in enumerate(raw_sources, start=1):
            if not isinstance(item, dict):
                raise ValueError(f"sources[{i-1}] must be an object")
            name = str(item.get("name", f"source_{i}")).strip() or f"source_{i}"
            if name in seen_names:
                raise ValueError(f"duplicate source name: {name}")
            seen_names.add(name)

            login = str(item.get("remote_login", "")).strip()
            password = str(item.get("remote_password", ""))
            port = int(item.get("remote_port", 22))
            remote_db_dir = str(item.get("remote_db_dir", "")).strip()
            if not login:
                raise ValueError(f"sources[{i-1}].remote_login is required")
            if not remote_db_dir:
                raise ValueError(f"sources[{i-1}].remote_db_dir is required")
            sources.append(
                RemoteSource(
                    name=name,
                    remote_login=login,
                    remote_password=password,
                    remote_port=port,
                    remote_db_dir=remote_db_dir,
                    remote_project_root=(
                        str(item.get("remote_project_root")).strip()
                        if item.get("remote_project_root") is not None
                        else None
                    ),
                    remote_injector_py=(
                        str(item.get("remote_injector_py")).strip()
                        if item.get("remote_injector_py") is not None
                        else None
                    ),
                    remote_models_py=(
                        str(item.get("remote_models_py")).strip()
                        if item.get("remote_models_py") is not None
                        else None
                    ),
                    remote_blackbox_config_json=(
                        str(item.get("remote_blackbox_config_json")).strip()
                        if item.get("remote_blackbox_config_json") is not None
                        else None
                    ),
                )
            )
        return sources

    # Backward-compatible single source config.
    login = str(config.get("remote_login", "")).strip()
    password = str(config.get("remote_password", ""))
    remote_db_dir = str(config.get("remote_db_dir", "")).strip()
    if not login or not remote_db_dir:
        raise ValueError(
            "Provide either 'sources' list or legacy keys: remote_login, remote_password, remote_db_dir"
        )
    return [
        RemoteSource(
            name="default",
            remote_login=login,
            remote_password=password,
            remote_port=int(config.get("remote_port", 22)),
            remote_db_dir=remote_db_dir,
            remote_project_root=(
                str(config.get("remote_project_root")).strip()
                if config.get("remote_project_root") is not None
                else None
            ),
            remote_injector_py=(
                str(config.get("remote_injector_py")).strip()
                if config.get("remote_injector_py") is not None
                else None
            ),
            remote_models_py=(
                str(config.get("remote_models_py")).strip()
                if config.get("remote_models_py") is not None
                else None
            ),
            remote_blackbox_config_json=(
                str(config.get("remote_blackbox_config_json")).strip()
                if config.get("remote_blackbox_config_json") is not None
                else None
            ),
        )
    ]


class RemotePlotsApp:
    def __init__(self, config_path: Path, config: dict[str, Any]) -> None:
        self.base_dir = config_path.parent
        self.goal = str(config.get("goal", "minimize"))
        self.max_points = max(100, int(config.get("max_points", 2000)))
        self.refresh_sec = max(0.5, float(config.get("refresh_sec", 2.0)))
        self.local_dir = (self.base_dir / str(config.get("local_mirror_dir", "mirrored_dbs"))).resolve()
        self.local_dir.mkdir(parents=True, exist_ok=True)
        self.db_map: dict[str, Path] = {}
        self.source_by_name: dict[str, RemoteSource] = {}
        self.injector_cache_dir = (self.base_dir / "_remote_injector_cache").resolve()
        self.injector_cache_dir.mkdir(parents=True, exist_ok=True)

        sources = parse_sources(config)
        self.source_by_name = {s.name: s for s in sources}
        self.mirrors: list[RemoteDBMirror] = []
        for source in sources:
            source_local = self.local_dir / source.name
            mirror = RemoteDBMirror(
                source_name=source.name,
                remote_login=source.remote_login,
                remote_password=source.remote_password,
                remote_port=source.remote_port,
                remote_db_dir=source.remote_db_dir,
                local_dir=source_local,
                sync_interval_sec=float(config.get("sync_interval_sec", 30)),
            )
            mirror.start()
            self.mirrors.append(mirror)

        self.root = tk.Tk()
        self.root.title("Remote DB Live Plots")
        self.root.geometry("1400x920")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.db_var = tk.StringVar(value="")
        self.refresh_var = tk.StringVar(value=f"{self.refresh_sec:.1f}")
        self.title_var = tk.StringVar(value="Loading...")
        self.meta_var = tk.StringVar(value="")
        self.sync_var = tk.StringVar(value="sync: starting")
        self.last_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value=f"local cache: {self.local_dir}")

        self._build_ui()

    def _build_ui(self) -> None:
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill=tk.X)
        ttk.Label(top, textvariable=self.title_var, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(top, textvariable=self.meta_var, font=("Consolas", 10)).pack(anchor="w", pady=(4, 0))
        ttk.Label(top, textvariable=self.sync_var, font=("Consolas", 10)).pack(anchor="w", pady=(2, 0))
        ttk.Label(top, textvariable=self.last_var, font=("Consolas", 10)).pack(anchor="w", pady=(2, 0))

        controls = ttk.LabelFrame(self.root, text="Controls", padding=8)
        controls.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Label(controls, text="Refresh sec").grid(row=0, column=0, sticky="w", padx=(0, 4), pady=2)
        ttk.Entry(controls, textvariable=self.refresh_var, width=8).grid(row=0, column=1, sticky="w", padx=(0, 10), pady=2)
        ttk.Label(controls, text="Database").grid(row=0, column=2, sticky="w", padx=(0, 4), pady=2)
        self.db_combo = ttk.Combobox(controls, textvariable=self.db_var, values=[], width=48, state="readonly")
        self.db_combo.grid(row=0, column=3, sticky="w", padx=(0, 10), pady=2)
        self.db_combo.bind("<<ComboboxSelected>>", lambda _: self._refresh_once())
        ttk.Button(controls, text="Reload DB list", command=self._reload_db_list).grid(row=0, column=4, sticky="w", padx=(0, 10), pady=2)
        ttk.Button(controls, text="Export best params", command=self._export_best_params).grid(
            row=0, column=5, sticky="w", padx=(0, 10), pady=2
        )
        ttk.Button(controls, text="Top5 Input Folders", command=self._export_top5_input_folders).grid(
            row=0, column=6, sticky="w", padx=(0, 10), pady=2
        )

        self.canvas = tk.Canvas(self.root, background="#ffffff", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=8)

        bottom = ttk.Frame(self.root, padding=8)
        bottom.pack(fill=tk.X)
        ttk.Label(bottom, textvariable=self.status_var, font=("Consolas", 10)).pack(anchor="w")

    def run(self) -> None:
        self._reload_db_list()
        self._refresh_once()
        self.root.mainloop()

    def _on_close(self) -> None:
        for mirror in self.mirrors:
            mirror.stop()
        self.root.destroy()

    def _reload_db_list(self) -> None:
        db_files = list_local_databases(self.local_dir)
        self.db_map = {name: path for name, path in db_files}
        names = list(self.db_map.keys())
        self.db_combo["values"] = names
        current = self.db_var.get().strip()
        if current not in names:
            self.db_var.set(names[0] if names else "")

    def _refresh_once(self) -> None:
        try:
            self.refresh_sec = max(0.5, float(self.refresh_var.get().strip()))
        except ValueError:
            self.refresh_sec = 2.0
            self.refresh_var.set("2.0")

        self._reload_db_list()
        parts: list[str] = []
        for mirror in self.mirrors:
            s = mirror.get_status()
            part = (
                f"{mirror.source_name}:{s.message} seen={s.files_seen} copied={s.files_copied} "
                f"last={s.last_success}"
            )
            if s.last_error:
                part += f" err={s.last_error}"
            parts.append(part)
        sync_text = " | ".join(parts) if parts else "sync=idle"
        self.sync_var.set(sync_text)

        db_name = self.db_var.get().strip()
        if not db_name:
            self.title_var.set("No mirrored DB files yet")
            self.meta_var.set("")
            self.last_var.set("")
            self.canvas.delete("all")
            self.status_var.set(f"Waiting for sync. local cache: {self.local_dir}")
            self.root.after(int(self.refresh_sec * 1000), self._refresh_once)
            return

        db_path = self.db_map.get(db_name)
        if db_path is None:
            self.title_var.set("Selected DB no longer exists in mirror")
            self.meta_var.set("")
            self.last_var.set("")
            self.canvas.delete("all")
            self.status_var.set("Select a different database")
            self.root.after(int(self.refresh_sec * 1000), self._refresh_once)
            return
        try:
            snapshot = load_db_snapshot(db_path, self.goal, self.max_points)
            self._render_snapshot(db_name, snapshot)
            self.status_var.set(f"Loaded: {db_path}")
        except Exception as exc:
            self.title_var.set(f"DB read error: {exc}")
            self.meta_var.set("")
            self.last_var.set("")
            self.canvas.delete("all")
            self.status_var.set(f"Could not read {db_path}")

        self.root.after(int(self.refresh_sec * 1000), self._refresh_once)

    def _export_best_params(self) -> None:
        db_name = self.db_var.get().strip()
        if not db_name:
            self.status_var.set("No DB selected")
            return
        db_path = self.db_map.get(db_name)
        if db_path is None:
            self.status_var.set("Selected DB not found in local mirror")
            return
        try:
            out_path, trial_id = export_best_params(db_path, self.goal)
            self.status_var.set(
                f"Exported best params from trial_id={trial_id} to {out_path}"
            )
        except Exception as exc:
            self.status_var.set(f"Export failed: {exc}")

    def _export_top5_input_folders(self) -> None:
        db_name = self.db_var.get().strip()
        if not db_name:
            self.status_var.set("No DB selected")
            return
        db_path = self.db_map.get(db_name)
        if db_path is None:
            self.status_var.set("Selected DB not found in local mirror")
            return

        source_name = db_name.split("/", 1)[0] if "/" in db_name else "default"
        source = self.source_by_name.get(source_name)
        if source is None:
            self.status_var.set(f"Unknown source for selected DB: {source_name}")
            return

        try:
            top = load_top_params(db_path, self.goal, n=5)
            if not top:
                self.status_var.set("No successful trials to export")
                return

            injector_mod, blackbox_cfg = _load_remote_injector_runtime(source, self.injector_cache_dir)

            campaign_dir = self.base_dir / source_name
            if campaign_dir.exists():
                shutil.rmtree(campaign_dir, ignore_errors=True)
            campaign_dir.mkdir(parents=True, exist_ok=True)

            created: list[str] = []
            for i, row in enumerate(top, start=1):
                trial_id = row["trial_id"]
                target_value = row["target_value"]
                params = row["params"]
                trial_dir = campaign_dir / f"best_{i:02d}_trial_{trial_id}"
                trial_dir.mkdir(parents=True, exist_ok=True)
                _call_injector(injector_mod, trial_dir, params, blackbox_cfg)
                created.append(f"{trial_dir.name}(target={target_value:.6g})")

            self.status_var.set(
                f"Created {len(created)} input folders in {campaign_dir}: " + ", ".join(created)
            )
        except Exception as exc:
            self.status_var.set(f"Top5 export failed: {exc}")

    def _render_snapshot(self, db_name: str, snapshot: dict[str, Any]) -> None:
        counts = snapshot["counts"]
        total = snapshot["total"]
        success = snapshot["success"]
        failed = snapshot["failed"]
        self.title_var.set(
            f"DB={db_name} | goal={self.goal} | total={total} success={success} "
            f"fail={failed} success_rate={snapshot['success_rate']:.1f}%"
        )
        self.meta_var.set(
            " | ".join(
                [
                    f"best_target={snapshot['best_target']}",
                    f"best_trial_id={snapshot['best_trial_id']}",
                    f"min={snapshot['min_target']}",
                    f"max={snapshot['max_target']}",
                    f"avg={snapshot['avg_target']}",
                    f"queued={counts.get('queued', 0)}",
                    f"running={counts.get('running', 0)}",
                    f"timeout={counts.get('timeout', 0)}",
                    f"stuck={counts.get('stuck', 0)}",
                ]
            )
        )
        last = snapshot["last_trial"]
        if last is None:
            self.last_var.set("last_trial: none")
        else:
            self.last_var.set(
                f"last_trial: id={last['trial_id']} status={last['status']} "
                f"target={last['target_value']} runtime={last['runtime_sec']} reason={last['failure_reason']}"
            )
        self._draw_plot(snapshot["series_x"], snapshot["series_y"], snapshot["best_curve"])

    def _draw_plot(self, xs: list[int], ys: list[float], best_ys: list[float]) -> None:
        self.canvas.delete("all")
        width = max(800, self.canvas.winfo_width())
        height = max(420, self.canvas.winfo_height())

        left = 70
        right = width - 20
        top = 20
        bottom = height - 50

        self.canvas.create_rectangle(left, top, right, bottom, outline="#d0d0d0")
        self.canvas.create_text(left, 10, text="Target over successful trials", anchor="w", fill="#111")

        if not xs or not ys:
            self.canvas.create_text(
                width // 2,
                height // 2,
                text="No successful trials yet",
                fill="#666",
                font=("Segoe UI", 14),
            )
            return

        x_vals = [float(x) for x in xs]
        y_vals = [float(y) for y in ys]
        y_best = [float(y) for y in best_ys]

        x_vals, y_vals = downsample_xy(x_vals, y_vals, max_points=max(100, width - left - 10))
        x_best, y_best = downsample_xy([float(x) for x in xs], y_best, max_points=max(100, width - left - 10))

        y_min, y_max = compute_bounds(y_vals + y_best)
        x_max = max(float(max(x_vals)), float(max(x_best)), 2.0)

        for i in range(6):
            y = top + i * (bottom - top) / 5.0
            val = y_max - i * (y_max - y_min) / 5.0
            self.canvas.create_line(left, y, right, y, fill="#f3f3f3")
            self.canvas.create_text(left - 8, y, text=f"{val:.4g}", anchor="e", fill="#333", font=("Consolas", 9))

        def map_xy(x_val: float, y_val: float) -> tuple[float, float]:
            px = left + (x_val - 1.0) / max(1e-12, (x_max - 1.0)) * (right - left)
            py = bottom - (y_val - y_min) / max(1e-12, (y_max - y_min)) * (bottom - top)
            return px, py

        raw_points: list[float] = []
        best_points: list[float] = []
        for xv, yv in zip(x_vals, y_vals):
            px, py = map_xy(xv, yv)
            raw_points.extend([px, py])
        for xv, yv in zip(x_best, y_best):
            px, py = map_xy(xv, yv)
            best_points.extend([px, py])

        if len(raw_points) >= 4:
            self.canvas.create_line(raw_points, fill="#1f77b4", width=2)
        if len(best_points) >= 4:
            self.canvas.create_line(best_points, fill="#2ca02c", width=2)

        lx, ly = map_xy(x_vals[-1], y_vals[-1])
        self.canvas.create_oval(lx - 3, ly - 3, lx + 3, ly + 3, fill="#1f77b4", outline="")

        lbx, lby = map_xy(x_best[-1], y_best[-1])
        self.canvas.create_oval(lbx - 4, lby - 4, lbx + 4, lby + 4, fill="#2ca02c", outline="")

        self.canvas.create_text(left, bottom + 18, text="x: successful trial index", anchor="w", fill="#333")
        self.canvas.create_text(right - 280, top + 14, text="blue=target, green=best-so-far", anchor="w", fill="#333")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Remote SQLite mirror + live plots")
    parser.add_argument("--config", default="config.json", help="Path to JSON config")
    return parser.parse_args()


def load_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")
    raw = config_path.read_text(encoding="utf-8")
    cfg = json.loads(raw)
    _ = parse_sources(cfg)
    return cfg


def main() -> None:
    args = parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = (Path(__file__).resolve().parent / config_path).resolve()
    config = load_config(config_path)
    ensure_tk()
    app = RemotePlotsApp(config_path=config_path, config=config)
    app.run()


if __name__ == "__main__":
    main()
