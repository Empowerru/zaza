#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from optimizer.db import TrialDB
from optimizer.diagnostics import compute_best_curve, compute_bounds, downsample_xy, success_rate, trials_per_hour


class LiveDashboard:
    TERMINAL_FAIL_STATUSES = {
        "failed",
        "timeout",
        "stuck",
        "parse_error",
        "injection_error",
        "launch_error",
    }

    def __init__(self, db_path: Path, goal: str, refresh_sec: float, history_points: int) -> None:
        try:
            import tkinter as tk  # type: ignore
            from tkinter import ttk  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "Tkinter is not available in this Python build. "
                "On Windows, install standard Python from python.org with Tk support."
            ) from exc

        self.tk = tk
        self.ttk = ttk

        self.base_dir = Path(__file__).resolve().parent
        self.base_project_config_path = self.base_dir / "config" / "project_config.json"
        self.base_blackbox_config_path = self.base_dir / "config" / "blackbox_config.json"
        self.base_search_space_path = self.base_dir / "config" / "search_space.json"
        self.runtime_project_config_path = self.base_dir / "config" / "_dashboard_runtime_project_config.json"

        self.db_path = db_path
        self.goal = goal
        self.refresh_sec = max(0.5, refresh_sec)
        self.history_points = max(50, history_points)

        self.optimizer_proc: subprocess.Popen[str] | None = None
        self.optimizer_log_fp = None
        self.stop_requested_ts: float | None = None

        self.root = self.tk.Tk()
        self.root.title("Optimizer Live Dashboard")
        self.root.geometry("1400x920")

        self._build_state_vars()
        self._build_ui()

    def _build_state_vars(self) -> None:
        project_cfg = self._load_project_cfg()
        search_cfg = dict(project_cfg.get("search_method_settings", {}))

        self.db_var = self.tk.StringVar(value=str(self.db_path))
        self.workers_var = self.tk.StringVar(value="0")
        self.max_trials_var = self.tk.StringVar(value="")
        self.goal_var = self.tk.StringVar(value=self.goal)
        self.search_method_var = self.tk.StringVar(value=str(project_cfg.get("search_method", "tpe")))
        self.resume_var = self.tk.BooleanVar(value=bool(project_cfg.get("resume", True)))
        self.new_research_var = self.tk.BooleanVar(value=False)

        self.template_dir_var = self.tk.StringVar(value=str(project_cfg.get("template_dir", "runs/template")))
        self.cleanup_policy_var = self.tk.StringVar(value=str(project_cfg.get("cleanup_policy", "always_delete")))

        self.exploration_var = self.tk.StringVar(value=str(project_cfg.get("exploration_fraction", 0.3)))
        self.warmup_var = self.tk.StringVar(value=str(project_cfg.get("warmup_success_trials", 20)))
        self.elite_var = self.tk.StringVar(value=str(project_cfg.get("elite_pool_size", 10)))
        self.seed_var = self.tk.StringVar(value=str(project_cfg.get("random_seed", 12345)))

        self.gamma_var = self.tk.StringVar(value=str(search_cfg.get("gamma", 0.2)))
        self.min_good_var = self.tk.StringVar(value=str(search_cfg.get("min_good", 8)))
        self.candidates_var = self.tk.StringVar(value=str(search_cfg.get("candidates_per_step", 64)))
        self.pool_limit_var = self.tk.StringVar(value=str(search_cfg.get("success_pool_limit", 50000)))
        self.optuna_startup_var = self.tk.StringVar(value=str(search_cfg.get("optuna_n_startup_trials", 30)))
        self.optuna_candidates_var = self.tk.StringVar(value=str(search_cfg.get("optuna_n_ei_candidates", 64)))
        self.optuna_multivariate_var = self.tk.StringVar(value="true" if bool(search_cfg.get("optuna_multivariate", True)) else "false")
        self.optuna_group_var = self.tk.StringVar(value="true" if bool(search_cfg.get("optuna_group", False)) else "false")
        self.optuna_liar_var = self.tk.StringVar(value="true" if bool(search_cfg.get("optuna_constant_liar", True)) else "false")

        self.refresh_var = self.tk.StringVar(value=f"{self.refresh_sec:.1f}")
        self.history_var = self.tk.StringVar(value=str(self.history_points))

        self.title_var = self.tk.StringVar(value="Loading...")
        self.meta_var = self.tk.StringVar(value="")
        self.last_var = self.tk.StringVar(value="")
        self.status_var = self.tk.StringVar(value="Idle")

    def _build_ui(self) -> None:
        top = self.ttk.Frame(self.root, padding=8)
        top.pack(fill=self.tk.X)

        self.ttk.Label(top, textvariable=self.title_var, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.ttk.Label(top, textvariable=self.meta_var, font=("Consolas", 10)).pack(anchor="w", pady=(4, 0))
        self.ttk.Label(top, textvariable=self.last_var, font=("Consolas", 10)).pack(anchor="w", pady=(2, 0))

        controls = self.ttk.LabelFrame(self.root, text="Run Controls", padding=8)
        controls.pack(fill=self.tk.X, padx=8, pady=(0, 8))

        row = 0
        self._add_entry(controls, row, 0, "DB", self.db_var, width=52)
        self._add_entry(controls, row, 2, "Template", self.template_dir_var, width=26)
        self._add_combo(controls, row, 4, "Cleanup", self.cleanup_policy_var, ["always_delete", "delete_success_keep_failure", "keep_all", "keep_best_n"], width=24)

        row = 1
        self._add_entry(controls, row, 0, "Workers (0=all)", self.workers_var, width=12)
        self._add_entry(controls, row, 2, "Max trials (blank=inf)", self.max_trials_var, width=16)
        self._add_combo(controls, row, 4, "Goal", self.goal_var, ["minimize", "maximize"], width=12)
        method_combo = self._add_combo(
            controls,
            row,
            6,
            "Method",
            self.search_method_var,
            ["optuna_tpe", "tpe", "async_evolution"],
            width=18,
        )
        method_combo.bind("<<ComboboxSelected>>", lambda _: self._on_method_changed())

        row = 2
        self._add_entry(controls, row, 6, "Seed", self.seed_var, width=12)
        self._add_entry(controls, row, 0, "Refresh sec", self.refresh_var, width=10)
        self._add_entry(controls, row, 2, "History points", self.history_var, width=12)
        self.ttk.Checkbutton(controls, text="Resume DB", variable=self.resume_var).grid(row=2, column=4, sticky="w", padx=(8, 6))
        self.ttk.Checkbutton(controls, text="Start new research DB", variable=self.new_research_var).grid(row=2, column=5, sticky="w", padx=(8, 6))

        self.ttk.Button(controls, text="Start", command=self._start_optimizer).grid(row=2, column=8, padx=(12, 6), sticky="e")
        self.ttk.Button(controls, text="Auto Best", command=self._start_auto_optimizer).grid(row=2, column=9, padx=(0, 6), sticky="w")
        self.ttk.Button(controls, text="Stop", command=self._stop_optimizer).grid(row=2, column=10, padx=(0, 6), sticky="w")

        method_settings = self.ttk.LabelFrame(self.root, text="Method Hyperparameters", padding=8)
        method_settings.pack(fill=self.tk.X, padx=8, pady=(0, 8))

        self.tpe_settings_frame = self.ttk.Frame(method_settings)
        self._add_entry(self.tpe_settings_frame, 0, 0, "Exploration", self.exploration_var, width=10)
        self._add_entry(self.tpe_settings_frame, 0, 2, "Warmup", self.warmup_var, width=10)
        self._add_entry(self.tpe_settings_frame, 0, 4, "TPE gamma", self.gamma_var, width=10)
        self._add_entry(self.tpe_settings_frame, 0, 6, "TPE min_good", self.min_good_var, width=10)
        self._add_entry(self.tpe_settings_frame, 1, 0, "TPE candidates", self.candidates_var, width=10)
        self._add_entry(self.tpe_settings_frame, 1, 2, "Success pool", self.pool_limit_var, width=12)

        self.evolution_settings_frame = self.ttk.Frame(method_settings)
        self._add_entry(self.evolution_settings_frame, 0, 0, "Exploration", self.exploration_var, width=10)
        self._add_entry(self.evolution_settings_frame, 0, 2, "Warmup", self.warmup_var, width=10)
        self._add_entry(self.evolution_settings_frame, 0, 4, "Elite", self.elite_var, width=10)

        self.optuna_settings_frame = self.ttk.Frame(method_settings)
        self._add_entry(self.optuna_settings_frame, 0, 0, "Startup trials", self.optuna_startup_var, width=10)
        self._add_entry(self.optuna_settings_frame, 0, 2, "EI candidates", self.optuna_candidates_var, width=10)
        self._add_entry(self.optuna_settings_frame, 0, 4, "Success pool", self.pool_limit_var, width=12)
        self._add_combo(self.optuna_settings_frame, 1, 0, "Multivariate", self.optuna_multivariate_var, ["true", "false"], width=10)
        self._add_combo(self.optuna_settings_frame, 1, 2, "Group", self.optuna_group_var, ["false", "true"], width=10)
        self._add_combo(self.optuna_settings_frame, 1, 4, "Constant liar", self.optuna_liar_var, ["true", "false"], width=10)

        self._on_method_changed()

        self.canvas = self.tk.Canvas(self.root, background="#ffffff", highlightthickness=0)
        self.canvas.pack(fill=self.tk.BOTH, expand=True, padx=8)

        bottom = self.ttk.Frame(self.root, padding=8)
        bottom.pack(fill=self.tk.X)
        self.ttk.Label(bottom, textvariable=self.status_var, font=("Consolas", 10)).pack(anchor="w")

    def _add_entry(self, parent, row: int, col: int, label: str, var, width: int = 14) -> None:
        self.ttk.Label(parent, text=label).grid(row=row, column=col, sticky="w", padx=(0, 4), pady=2)
        self.ttk.Entry(parent, textvariable=var, width=width).grid(row=row, column=col + 1, sticky="w", padx=(0, 10), pady=2)

    def _add_combo(self, parent, row: int, col: int, label: str, var, values: list[str], width: int = 14):
        self.ttk.Label(parent, text=label).grid(row=row, column=col, sticky="w", padx=(0, 4), pady=2)
        combo = self.ttk.Combobox(parent, textvariable=var, values=values, width=width, state="readonly")
        combo.grid(row=row, column=col + 1, sticky="w", padx=(0, 10), pady=2)
        return combo

    def _on_method_changed(self) -> None:
        method = (self.search_method_var.get().strip() or "tpe").lower()
        for frame in [self.tpe_settings_frame, self.evolution_settings_frame, self.optuna_settings_frame]:
            frame.pack_forget()
        if method in {"optuna_tpe", "optuna", "bayes_optuna"}:
            self.optuna_settings_frame.pack(fill=self.tk.X)
            return
        if method in {"async_evolution", "evolution", "random_mutation"}:
            self.evolution_settings_frame.pack(fill=self.tk.X)
            return
        self.tpe_settings_frame.pack(fill=self.tk.X)

    def _load_project_cfg(self) -> dict[str, Any]:
        if not self.base_project_config_path.exists():
            return {}
        return json.loads(self.base_project_config_path.read_text(encoding="utf-8"))

    def start(self) -> None:
        self._refresh()
        self.root.mainloop()

    def _start_optimizer(self) -> None:
        if self.optimizer_proc is not None and self.optimizer_proc.poll() is None:
            self.status_var.set("Optimizer already running")
            return

        try:
            refresh = float(self.refresh_var.get().strip())
            history = int(self.history_var.get().strip())
            workers = int(self.workers_var.get().strip())
            max_trials_raw = self.max_trials_var.get().strip()
            max_trials = int(max_trials_raw) if max_trials_raw else None
            seed = int(self.seed_var.get().strip())
        except ValueError as exc:
            self.status_var.set(f"Invalid controls value: {exc}")
            return

        self.refresh_sec = max(0.5, refresh)
        self.history_points = max(50, history)

        cfg = self._load_project_cfg()
        cfg["db_path"] = self.db_var.get().strip() or "data/trials.sqlite"
        cfg["template_dir"] = self.template_dir_var.get().strip() or "runs/template"
        cfg["cleanup_policy"] = self.cleanup_policy_var.get().strip() or "always_delete"
        cfg["goal"] = self.goal_var.get().strip() or "minimize"
        method = self.search_method_var.get().strip() or "tpe"
        cfg["search_method"] = method
        cfg["random_seed"] = seed

        if method in {"optuna_tpe", "optuna", "bayes_optuna"}:
            try:
                import optuna  # noqa: F401
            except Exception:
                self.status_var.set(
                    "Optuna is not installed for this Python. Run: python -m pip install -r requirements.txt"
                )
                return

        settings = dict(cfg.get("search_method_settings", {}))
        def parse_bool(text: str) -> bool:
            return text.strip().lower() in {"1", "true", "yes", "y", "on"}

        try:
            if method in {"tpe", "async_tpe"}:
                cfg["exploration_fraction"] = float(self.exploration_var.get().strip())
                cfg["warmup_success_trials"] = int(self.warmup_var.get().strip())
                settings["gamma"] = float(self.gamma_var.get().strip())
                settings["min_good"] = int(self.min_good_var.get().strip())
                settings["candidates_per_step"] = int(self.candidates_var.get().strip())
                settings["success_pool_limit"] = int(self.pool_limit_var.get().strip())
            elif method in {"async_evolution", "evolution", "random_mutation"}:
                cfg["exploration_fraction"] = float(self.exploration_var.get().strip())
                cfg["warmup_success_trials"] = int(self.warmup_var.get().strip())
                cfg["elite_pool_size"] = int(self.elite_var.get().strip())
            elif method in {"optuna_tpe", "optuna", "bayes_optuna"}:
                settings["optuna_n_startup_trials"] = int(self.optuna_startup_var.get().strip())
                settings["optuna_n_ei_candidates"] = int(self.optuna_candidates_var.get().strip())
                settings["optuna_multivariate"] = parse_bool(self.optuna_multivariate_var.get())
                settings["optuna_group"] = parse_bool(self.optuna_group_var.get())
                settings["optuna_constant_liar"] = parse_bool(self.optuna_liar_var.get())
                settings["success_pool_limit"] = int(self.pool_limit_var.get().strip())
            else:
                self.status_var.set(f"Unsupported search method in dashboard: {method}")
                return
        except ValueError as exc:
            self.status_var.set(f"Invalid method hyperparameter: {exc}")
            return

        cfg["search_method_settings"] = settings

        resume = bool(self.resume_var.get())
        if self.new_research_var.get():
            cfg["db_path"] = self._new_db_path(cfg["db_path"])
            resume = False
            self.db_var.set(cfg["db_path"])
        cfg["resume"] = resume

        self.runtime_project_config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

        cmd = [
            sys.executable,
            str(self.base_dir / "run_optimizer.py"),
            "--project-config",
            str(self.runtime_project_config_path),
            "--blackbox-config",
            str(self.base_blackbox_config_path),
            "--search-space",
            str(self.base_search_space_path),
            "--workers",
            str(workers),
            "--goal",
            cfg["goal"],
            "--search-method",
            cfg["search_method"],
        ]
        if max_trials is not None:
            cmd += ["--max-trials", str(max_trials)]
        cmd.append("--resume" if resume else "--no-resume")

        log_path = self.base_dir / "logs" / "dashboard_runner.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.optimizer_log_fp = log_path.open("a", encoding="utf-8")
        self.optimizer_log_fp.write(f"\n[{datetime.now().isoformat()}] START cmd={' '.join(cmd)}\n")
        self.optimizer_log_fp.flush()

        self.optimizer_proc = subprocess.Popen(
            cmd,
            cwd=str(self.base_dir),
            stdout=self.optimizer_log_fp,
            stderr=self.optimizer_log_fp,
            text=True,
        )
        self.stop_requested_ts = None

        self.db_path = self.base_dir / cfg["db_path"] if not Path(cfg["db_path"]).is_absolute() else Path(cfg["db_path"])
        self.status_var.set(f"Started optimizer pid={self.optimizer_proc.pid} resume={resume} db={self.db_path}")

    def _start_auto_optimizer(self) -> None:
        if self.optimizer_proc is not None and self.optimizer_proc.poll() is None:
            self.status_var.set("Optimizer already running")
            return

        try:
            refresh = float(self.refresh_var.get().strip())
            history = int(self.history_var.get().strip())
            workers = int(self.workers_var.get().strip())
            max_trials_raw = self.max_trials_var.get().strip()
            max_total_trials = int(max_trials_raw) if max_trials_raw else None
            seed = int(self.seed_var.get().strip())
        except ValueError as exc:
            self.status_var.set(f"Invalid controls value: {exc}")
            return

        self.refresh_sec = max(0.5, refresh)
        self.history_points = max(50, history)

        cfg = self._load_project_cfg()
        cfg["db_path"] = self.db_var.get().strip() or "data/trials.sqlite"
        cfg["template_dir"] = self.template_dir_var.get().strip() or "runs/template"
        cfg["cleanup_policy"] = self.cleanup_policy_var.get().strip() or "always_delete"
        cfg["goal"] = self.goal_var.get().strip() or "minimize"
        cfg["random_seed"] = seed

        resume = bool(self.resume_var.get())
        if self.new_research_var.get():
            cfg["db_path"] = self._new_db_path(cfg["db_path"])
            resume = False
            self.db_var.set(cfg["db_path"])
        cfg["resume"] = resume

        self.runtime_project_config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

        cmd = [
            sys.executable,
            str(self.base_dir / "run_auto_optimize.py"),
            "--project-config",
            str(self.runtime_project_config_path),
            "--blackbox-config",
            str(self.base_blackbox_config_path),
            "--search-space",
            str(self.base_search_space_path),
            "--workers",
            str(workers),
            "--goal",
            cfg["goal"],
            "--seed",
            str(seed),
        ]
        if max_total_trials is not None:
            cmd += ["--max-total-trials", str(max_total_trials)]
        cmd.append("--resume" if resume else "--no-resume")

        log_path = self.base_dir / "logs" / "dashboard_runner.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.optimizer_log_fp = log_path.open("a", encoding="utf-8")
        self.optimizer_log_fp.write(f"\n[{datetime.now().isoformat()}] START auto cmd={' '.join(cmd)}\n")
        self.optimizer_log_fp.flush()

        self.optimizer_proc = subprocess.Popen(
            cmd,
            cwd=str(self.base_dir),
            stdout=self.optimizer_log_fp,
            stderr=self.optimizer_log_fp,
            text=True,
        )
        self.stop_requested_ts = None

        self.db_path = self.base_dir / cfg["db_path"] if not Path(cfg["db_path"]).is_absolute() else Path(cfg["db_path"])
        self.status_var.set(
            f"Started AUTO optimizer pid={self.optimizer_proc.pid} resume={resume} db={self.db_path}"
        )

    def _stop_optimizer(self) -> None:
        if self.optimizer_proc is None or self.optimizer_proc.poll() is not None:
            self.status_var.set("Optimizer is not running")
            return
        self.optimizer_proc.terminate()
        self.stop_requested_ts = time.monotonic()
        self.status_var.set(f"Stopping optimizer pid={self.optimizer_proc.pid}...")

    def _refresh(self) -> None:
        self._refresh_process_state()
        snapshot = self._load_snapshot()
        if snapshot.get("error"):
            self.title_var.set(f"DB read error: {snapshot['error']}")
            self.meta_var.set("")
            self.last_var.set("")
            self.status_var.set(f"{self.status_var.get()} | Waiting for next refresh")
            self.canvas.delete("all")
        else:
            self._render(snapshot)
        self.root.after(int(self.refresh_sec * 1000), self._refresh)

    def _refresh_process_state(self) -> None:
        if self.optimizer_proc is None:
            return
        rc = self.optimizer_proc.poll()
        if rc is None:
            if self.stop_requested_ts is not None and time.monotonic() - self.stop_requested_ts > 10.0:
                self.optimizer_proc.kill()
                self.status_var.set("Optimizer did not stop in time; killed")
            return

        pid = self.optimizer_proc.pid
        self.optimizer_proc = None
        self.stop_requested_ts = None
        if self.optimizer_log_fp is not None:
            self.optimizer_log_fp.write(f"[{datetime.now().isoformat()}] EXIT code={rc}\n")
            self.optimizer_log_fp.flush()
            self.optimizer_log_fp.close()
            self.optimizer_log_fp = None
        self.status_var.set(f"Optimizer finished pid={pid} exit_code={rc}")

    def _new_db_path(self, db_path_raw: str) -> str:
        raw = db_path_raw.strip() or "data/trials.sqlite"
        p = Path(raw)
        if not p.is_absolute():
            p = self.base_dir / p
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        new_name = f"{p.stem}_{stamp}{p.suffix or '.sqlite'}"
        new_path = p.with_name(new_name)
        return str(new_path)

    def _load_snapshot(self) -> dict[str, Any]:
        db_path = self.db_path
        if not db_path.exists():
            return {"error": f"DB not found: {db_path}"}
        goal = self.goal_var.get().strip() or self.goal
        try:
            db = TrialDB(db_path)
            db.initialize(reset=False)
            counts = db.count_by_status(goal)
            total = db.count_launched(goal)
            success = counts.get("success", 0)
            failed = sum(int(v) for k, v in counts.items() if k in self.TERMINAL_FAIL_STATUSES)
            finished = success + failed
            best = db.get_best_trial(goal)
            stats = db.get_success_target_stats(goal)
            series_rows = db.get_success_series(limit=self.history_points, goal=goal)
            last_trial = db.get_last_trial(goal)
            db.close()
        except sqlite3.Error as exc:
            return {"error": str(exc)}

        series_x = list(range(1, len(series_rows) + 1))
        series_y = [float(row["target_value"]) for row in series_rows]
        best_curve = compute_best_curve(series_y, goal)

        first_finished = series_rows[0]["finished_at"] if series_rows else None
        last_finished = series_rows[-1]["finished_at"] if series_rows else None

        return {
            "counts": counts,
            "total": total,
            "success": success,
            "failed": failed,
            "finished": finished,
            "success_rate": success_rate(finished, success),
            "best_trial_id": int(best["trial_id"]) if best is not None else None,
            "best_target": float(best["target_value"]) if best is not None else None,
            "stats": stats,
            "series_x": series_x,
            "series_y": series_y,
            "best_curve": best_curve,
            "last_trial": last_trial,
            "tph": trials_per_hour(len(series_rows), first_finished, last_finished),
        }

    def _render(self, snapshot: dict[str, Any]) -> None:
        counts = snapshot["counts"]
        total = snapshot["total"]
        success = snapshot["success"]
        failed = snapshot["failed"]

        self.title_var.set(
            f"Goal={self.goal_var.get()} | total={total} success={success} fail={failed} "
            f"success_rate={snapshot['success_rate']:.1f}%"
        )

        self.meta_var.set(
            " | ".join(
                [
                    f"best_target={snapshot['best_target']}",
                    f"best_trial_id={snapshot['best_trial_id']}",
                    f"min={snapshot['stats']['min_target']}",
                    f"max={snapshot['stats']['max_target']}",
                    f"avg={snapshot['stats']['avg_target']}",
                    f"tph={snapshot['tph']:.2f}",
                    f"queued={counts.get('queued', 0)}",
                    f"running={counts.get('running', 0)}",
                    f"timeout={counts.get('timeout', 0)}",
                    f"stuck={counts.get('stuck', 0)}",
                ]
            )
        )

        last_trial = snapshot["last_trial"]
        if last_trial is None:
            self.last_var.set("last_trial: none")
        else:
            self.last_var.set(
                f"last_trial: id={last_trial['trial_id']} status={last_trial['status']} "
                f"target={last_trial['target_value']} runtime={last_trial['runtime_sec']} reason={last_trial['failure_reason']}"
            )

        self._draw_plot(snapshot["series_x"], snapshot["series_y"], snapshot["best_curve"])

    def _draw_plot(self, xs: list[int], ys: list[float], best_ys: list[float]) -> None:
        self.canvas.delete("all")
        width = max(800, self.canvas.winfo_width())
        height = max(420, self.canvas.winfo_height())

        left = 70
        right = width - 20
        top = 20
        bottom = height - 50

        self.canvas.create_rectangle(left, top, right, bottom, outline="#d0d0d0")
        self.canvas.create_text(left, 10, text="Target over successful trials", anchor="w", fill="#111")

        if not xs or not ys:
            self.canvas.create_text(
                width // 2,
                height // 2,
                text="No successful trials yet",
                fill="#666",
                font=("Segoe UI", 14),
            )
            return

        x_vals = [float(x) for x in xs]
        y_vals = [float(y) for y in ys]
        y_best_vals = [float(y) for y in best_ys]

        x_vals, y_vals = downsample_xy(x_vals, y_vals, max_points=max(100, width - left - 10))
        x_best, y_best_vals = downsample_xy([float(x) for x in xs], y_best_vals, max_points=max(100, width - left - 10))

        y_min, y_max = compute_bounds(y_vals + y_best_vals)
        x_max = max(float(max(x_vals)), float(max(x_best)), 2.0)

        for i in range(6):
            y = top + i * (bottom - top) / 5.0
            val = y_max - i * (y_max - y_min) / 5.0
            self.canvas.create_line(left, y, right, y, fill="#f3f3f3")
            self.canvas.create_text(left - 8, y, text=f"{val:.4g}", anchor="e", fill="#333", font=("Consolas", 9))

        def map_xy(x_value: float, y_value: float) -> tuple[float, float]:
            px = left + (x_value - 1.0) / max(1e-12, (x_max - 1.0)) * (right - left)
            py = bottom - (y_value - y_min) / max(1e-12, (y_max - y_min)) * (bottom - top)
            return px, py

        raw_points: list[float] = []
        best_points: list[float] = []

        for xv, yv in zip(x_vals, y_vals):
            px, py = map_xy(xv, yv)
            raw_points.extend([px, py])
        for xv, yv in zip(x_best, y_best_vals):
            px, py = map_xy(xv, yv)
            best_points.extend([px, py])

        if len(raw_points) >= 4:
            self.canvas.create_line(raw_points, fill="#1f77b4", width=2)
        if len(best_points) >= 4:
            self.canvas.create_line(best_points, fill="#2ca02c", width=2)

        lx, ly = map_xy(x_vals[-1], y_vals[-1])
        self.canvas.create_oval(lx - 3, ly - 3, lx + 3, ly + 3, fill="#1f77b4", outline="")

        lbx, lby = map_xy(x_best[-1], y_best_vals[-1])
        self.canvas.create_oval(lbx - 4, lby - 4, lbx + 4, lby + 4, fill="#2ca02c", outline="")

        self.canvas.create_text(left, bottom + 18, text="x: successful trial index", anchor="w", fill="#333")
        self.canvas.create_text(right - 280, top + 14, text="blue=target, green=best-so-far", anchor="w", fill="#333")


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Live optimizer dashboard with run controls (Windows-friendly)")
    parser.add_argument("--db", default=str(root / "data" / "trials.sqlite"))
    parser.add_argument("--goal", choices=["minimize", "maximize"], default="minimize")
    parser.add_argument("--refresh-sec", type=float, default=2.0)
    parser.add_argument("--history-points", type=int, default=1500)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    try:
        dash = LiveDashboard(
            db_path=Path(args.db),
            goal=args.goal,
            refresh_sec=args.refresh_sec,
            history_points=args.history_points,
        )
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
    dash.start()


if __name__ == "__main__":
    if sys.platform.startswith("win"):
        try:
            import ctypes

            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    main()
