#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from optimizer.db import TrialDB


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze optimizer SQLite DB")
    parser.add_argument("--db", default="data/trials.sqlite")
    parser.add_argument("--goal", choices=["maximize", "minimize"], default="minimize")
    parser.add_argument("--top", type=int, default=10)
    parser.add_argument("--recent", type=int, default=10)
    parser.add_argument("--export-best", type=str, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    db = TrialDB(args.db)
    db.initialize(reset=False)

    print("Top trials:")
    for row in db.top_trials(args.goal, n=args.top):
        print(
            f"trial_id={row['trial_id']} target={row['target_value']} "
            f"status={row['status']} runtime={row['runtime_sec']}"
        )

    print("\nFailure stats:")
    for row in db.failure_stats():
        print(f"status={row['status']} reason={row['reason']} count={row['cnt']}")

    print("\nRecent trials:")
    for row in db.recent_trials(n=args.recent):
        print(
            f"trial_id={row['trial_id']} status={row['status']} "
            f"target={row['target_value']} reason={row['failure_reason']}"
        )

    best_params = db.export_best_params(args.goal)
    if best_params is None:
        print("\nNo successful trials yet.")
    else:
        print("\nBest params:")
        print(json.dumps(best_params, indent=2, sort_keys=True))
        if args.export_best:
            out = Path(args.export_best)
            out.write_text(json.dumps(best_params, indent=2, sort_keys=True), encoding="utf-8")
            print(f"Exported best params to {out}")

    db.close()


if __name__ == "__main__":
    main()
