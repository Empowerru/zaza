from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Callable

from .models import ProcessRunResult
from .progress_monitor import ProgressTracker


def _terminate_process(proc: subprocess.Popen[bytes], grace_sec: float = 5.0) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=grace_sec)
        return
    except subprocess.TimeoutExpired:
        pass
    proc.kill()
    try:
        proc.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        pass


def run_subprocess(
    *,
    command: list[str],
    cwd: Path,
    env: dict[str, str],
    stdout_path: Path,
    stderr_path: Path,
    timeout_sec: float,
    poll_interval_sec: float,
    stuck_timeout_sec: float,
    progress_reader: Callable[[], float | int | None] | None,
) -> ProcessRunResult:
    start = time.monotonic()
    tracker = ProgressTracker(last_change_ts=start)

    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with stdout_path.open("wb") as f_out, stderr_path.open("wb") as f_err:
            proc = subprocess.Popen(
                command,
                cwd=str(cwd),
                env={**os.environ, **env},
                stdout=f_out,
                stderr=f_err,
            )
            pid = proc.pid
            while True:
                now = time.monotonic()
                if progress_reader is not None:
                    try:
                        tracker.observe(progress_reader(), now)
                    except Exception:
                        pass

                return_code = proc.poll()
                if return_code is not None:
                    return ProcessRunResult(
                        status="finished",
                        return_code=return_code,
                        runtime_sec=now - start,
                        progress_last=tracker.last_value,
                        failure_reason=None,
                        stdout_path=str(stdout_path),
                        stderr_path=str(stderr_path),
                        pid=pid,
                    )

                if timeout_sec > 0 and (now - start) > timeout_sec:
                    _terminate_process(proc)
                    return ProcessRunResult(
                        status="timeout",
                        return_code=proc.poll(),
                        runtime_sec=time.monotonic() - start,
                        progress_last=tracker.last_value,
                        failure_reason=f"Exceeded timeout {timeout_sec}s",
                        stdout_path=str(stdout_path),
                        stderr_path=str(stderr_path),
                        pid=pid,
                    )

                if (
                    stuck_timeout_sec > 0
                    and tracker.is_stuck(now, stuck_timeout_sec)
                ):
                    _terminate_process(proc)
                    return ProcessRunResult(
                        status="stuck",
                        return_code=proc.poll(),
                        runtime_sec=time.monotonic() - start,
                        progress_last=tracker.last_value,
                        failure_reason=f"Progress stuck for > {stuck_timeout_sec}s",
                        stdout_path=str(stdout_path),
                        stderr_path=str(stderr_path),
                        pid=pid,
                    )

                time.sleep(max(0.05, poll_interval_sec))
    except Exception as exc:
        return ProcessRunResult(
            status="launch_error",
            return_code=None,
            runtime_sec=time.monotonic() - start,
            progress_last=tracker.last_value,
            failure_reason=str(exc),
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            pid=None,
        )
