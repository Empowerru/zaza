from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .models import ArtifactInfo, WorkerOutcome
from .utils import ensure_dir, now_utc_iso


class TrialDB:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        ensure_dir(self.db_path.parent)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

    def close(self) -> None:
        self.conn.close()

    def initialize(self, reset: bool = False) -> None:
        if reset:
            self.conn.close()
            if self.db_path.exists():
                self.db_path.unlink()
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS trials (
                trial_id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT,
                status TEXT NOT NULL,
                goal TEXT NOT NULL,
                target_value REAL,
                raw_result_json TEXT,
                params_json TEXT NOT NULL,
                params_hash TEXT NOT NULL,
                worker_id INTEGER,
                sandbox_path TEXT,
                runtime_sec REAL,
                progress_last REAL,
                stdout_path TEXT,
                stderr_path TEXT,
                failure_reason TEXT,
                retry_of_trial_id INTEGER,
                hostname TEXT,
                pid INTEGER,
                blackbox_return_code INTEGER
            );

            CREATE TABLE IF NOT EXISTS artifacts (
                artifact_id INTEGER PRIMARY KEY AUTOINCREMENT,
                trial_id INTEGER NOT NULL,
                kind TEXT NOT NULL,
                path TEXT NOT NULL,
                note TEXT,
                FOREIGN KEY (trial_id) REFERENCES trials(trial_id)
            );

            CREATE TABLE IF NOT EXISTS best_history (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                trial_id INTEGER NOT NULL,
                target_value REAL NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (trial_id) REFERENCES trials(trial_id)
            );

            CREATE INDEX IF NOT EXISTS idx_trials_status ON trials(status);
            CREATE INDEX IF NOT EXISTS idx_trials_params_hash ON trials(params_hash);
            CREATE INDEX IF NOT EXISTS idx_trials_target ON trials(target_value);
            CREATE INDEX IF NOT EXISTS idx_trials_finished_at ON trials(finished_at);
            """
        )
        self.conn.commit()

    def insert_trial(
        self,
        *,
        goal: str,
        candidate: dict[str, Any],
        params_hash: str,
        status: str = "queued",
        retry_of_trial_id: int | None = None,
        failure_reason: str | None = None,
    ) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO trials (
                created_at, status, goal, params_json, params_hash, retry_of_trial_id, failure_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                now_utc_iso(),
                status,
                goal,
                json.dumps(candidate, sort_keys=True),
                params_hash,
                retry_of_trial_id,
                failure_reason,
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def mark_running(self, trial_id: int, worker_id: int) -> None:
        self.conn.execute(
            """
            UPDATE trials
            SET status = 'running', started_at = ?, worker_id = ?
            WHERE trial_id = ?
            """,
            (now_utc_iso(), worker_id, trial_id),
        )
        self.conn.commit()

    def finish_trial(self, outcome: WorkerOutcome) -> None:
        self.conn.execute(
            """
            UPDATE trials
            SET
                finished_at = ?,
                status = ?,
                target_value = ?,
                raw_result_json = ?,
                runtime_sec = ?,
                progress_last = ?,
                stdout_path = ?,
                stderr_path = ?,
                failure_reason = ?,
                sandbox_path = ?,
                hostname = ?,
                pid = ?,
                blackbox_return_code = ?
            WHERE trial_id = ?
            """,
            (
                now_utc_iso(),
                outcome.status,
                outcome.target_value,
                json.dumps(outcome.raw_result, sort_keys=True),
                outcome.runtime_sec,
                outcome.progress_last,
                outcome.stdout_path,
                outcome.stderr_path,
                outcome.failure_reason,
                outcome.sandbox_path,
                outcome.hostname,
                outcome.pid,
                outcome.blackbox_return_code,
                outcome.trial_id,
            ),
        )
        if outcome.artifacts:
            self.insert_artifacts(outcome.trial_id, outcome.artifacts)
        self.conn.commit()

    def insert_artifacts(self, trial_id: int, artifacts: list[ArtifactInfo]) -> None:
        self.conn.executemany(
            "INSERT INTO artifacts (trial_id, kind, path, note) VALUES (?, ?, ?, ?)",
            [(trial_id, a.kind, a.path, a.note) for a in artifacts],
        )

    def maybe_record_best(self, trial_id: int, goal: str, target_value: float) -> bool:
        best = self.get_best_trial(goal)
        improved = False
        if best is None:
            improved = True
        else:
            current_best = float(best["target_value"])
            improved = target_value < current_best if goal == "minimize" else target_value > current_best
        if improved:
            self.conn.execute(
                "INSERT INTO best_history (trial_id, target_value, created_at) VALUES (?, ?, ?)",
                (trial_id, target_value, now_utc_iso()),
            )
            self.conn.commit()
        return improved

    def get_existing_hashes(self) -> set[str]:
        rows = self.conn.execute("SELECT DISTINCT params_hash FROM trials").fetchall()
        return {str(r[0]) for r in rows if r[0]}

    def get_success_trials(self, goal: str, limit: int = 100) -> list[dict[str, Any]]:
        order = "ASC" if goal == "minimize" else "DESC"
        rows = self.conn.execute(
            f"""
            SELECT trial_id, target_value, params_json
            FROM trials
            WHERE goal = ? AND status='success' AND target_value IS NOT NULL
            ORDER BY target_value {order}
            LIMIT ?
            """,
            (goal, limit),
        ).fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            out.append(
                {
                    "trial_id": int(row["trial_id"]),
                    "target_value": float(row["target_value"]),
                    "params": json.loads(str(row["params_json"])),
                }
            )
        return out

    def get_best_trial(self, goal: str) -> sqlite3.Row | None:
        order = "ASC" if goal == "minimize" else "DESC"
        return self.conn.execute(
            f"""
            SELECT *
            FROM trials
            WHERE goal = ? AND status='success' AND target_value IS NOT NULL
            ORDER BY target_value {order}
            LIMIT 1
            """,
            (goal,),
        ).fetchone()

    def get_best_trial_ids(self, goal: str, n: int) -> list[int]:
        order = "ASC" if goal == "minimize" else "DESC"
        rows = self.conn.execute(
            f"""
            SELECT trial_id
            FROM trials
            WHERE goal = ? AND status='success' AND target_value IS NOT NULL
            ORDER BY target_value {order}
            LIMIT ?
            """,
            (goal, n),
        ).fetchall()
        return [int(r[0]) for r in rows]

    def get_success_target_stats(self, goal: str | None = None) -> dict[str, float | int | None]:
        if goal is None:
            row = self.conn.execute(
                """
                SELECT
                    COUNT(*) AS cnt,
                    MIN(target_value) AS min_target,
                    MAX(target_value) AS max_target,
                    AVG(target_value) AS avg_target
                FROM trials
                WHERE status='success' AND target_value IS NOT NULL
                """
            ).fetchone()
        else:
            row = self.conn.execute(
                """
                SELECT
                    COUNT(*) AS cnt,
                    MIN(target_value) AS min_target,
                    MAX(target_value) AS max_target,
                    AVG(target_value) AS avg_target
                FROM trials
                WHERE goal = ? AND status='success' AND target_value IS NOT NULL
                """,
                (goal,),
            ).fetchone()
        if row is None:
            return {"count": 0, "min_target": None, "max_target": None, "avg_target": None}
        return {
            "count": int(row["cnt"] or 0),
            "min_target": float(row["min_target"]) if row["min_target"] is not None else None,
            "max_target": float(row["max_target"]) if row["max_target"] is not None else None,
            "avg_target": float(row["avg_target"]) if row["avg_target"] is not None else None,
        }

    def get_success_series(self, limit: int = 2000, goal: str | None = None) -> list[dict[str, Any]]:
        if limit <= 0:
            limit = 2000
        if goal is None:
            rows = self.conn.execute(
                """
                SELECT trial_id, target_value, finished_at
                FROM trials
                WHERE status='success' AND target_value IS NOT NULL
                ORDER BY trial_id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """
                SELECT trial_id, target_value, finished_at
                FROM trials
                WHERE goal = ? AND status='success' AND target_value IS NOT NULL
                ORDER BY trial_id DESC
                LIMIT ?
                """,
                (goal, limit),
            ).fetchall()
        out: list[dict[str, Any]] = []
        for row in reversed(rows):
            out.append(
                {
                    "trial_id": int(row["trial_id"]),
                    "target_value": float(row["target_value"]),
                    "finished_at": str(row["finished_at"]) if row["finished_at"] is not None else None,
                }
            )
        return out

    def get_last_trial(self, goal: str | None = None) -> dict[str, Any] | None:
        if goal is None:
            row = self.conn.execute(
                """
                SELECT trial_id, status, target_value, runtime_sec, finished_at, failure_reason
                FROM trials
                ORDER BY trial_id DESC
                LIMIT 1
                """
            ).fetchone()
        else:
            row = self.conn.execute(
                """
                SELECT trial_id, status, target_value, runtime_sec, finished_at, failure_reason
                FROM trials
                WHERE goal = ?
                ORDER BY trial_id DESC
                LIMIT 1
                """,
                (goal,),
            ).fetchone()
        if row is None:
            return None
        return {
            "trial_id": int(row["trial_id"]),
            "status": str(row["status"]),
            "target_value": float(row["target_value"]) if row["target_value"] is not None else None,
            "runtime_sec": float(row["runtime_sec"]) if row["runtime_sec"] is not None else None,
            "finished_at": str(row["finished_at"]) if row["finished_at"] is not None else None,
            "failure_reason": str(row["failure_reason"]) if row["failure_reason"] is not None else None,
        }

    def count_by_status(self, goal: str | None = None) -> dict[str, int]:
        if goal is None:
            rows = self.conn.execute(
                "SELECT status, COUNT(*) AS cnt FROM trials GROUP BY status"
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT status, COUNT(*) AS cnt FROM trials WHERE goal = ? GROUP BY status",
                (goal,),
            ).fetchall()
        return {str(r["status"]): int(r["cnt"]) for r in rows}

    def count_launched(self, goal: str | None = None) -> int:
        if goal is None:
            row = self.conn.execute("SELECT COUNT(*) FROM trials").fetchone()
        else:
            row = self.conn.execute("SELECT COUNT(*) FROM trials WHERE goal = ?", (goal,)).fetchone()
        return int(row[0]) if row else 0

    def top_trials(self, goal: str, n: int = 10) -> list[sqlite3.Row]:
        order = "ASC" if goal == "minimize" else "DESC"
        return self.conn.execute(
            f"""
            SELECT trial_id, status, target_value, params_json, runtime_sec, finished_at
            FROM trials
            WHERE goal = ? AND status='success'
            ORDER BY target_value {order}
            LIMIT ?
            """,
            (goal, n),
        ).fetchall()

    def recent_trials(self, n: int = 10) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT trial_id, status, target_value, failure_reason, finished_at
            FROM trials
            ORDER BY trial_id DESC
            LIMIT ?
            """,
            (n,),
        ).fetchall()

    def failure_stats(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT status, COALESCE(failure_reason, '') AS reason, COUNT(*) AS cnt
            FROM trials
            WHERE status != 'success'
            GROUP BY status, reason
            ORDER BY cnt DESC
            """
        ).fetchall()

    def get_retry_counts(self) -> dict[str, int]:
        rows = self.conn.execute(
            "SELECT params_hash, COUNT(*) AS cnt FROM trials GROUP BY params_hash"
        ).fetchall()
        return {str(r["params_hash"]): int(r["cnt"]) for r in rows}

    def export_best_params(self, goal: str) -> dict[str, Any] | None:
        row = self.get_best_trial(goal)
        if row is None:
            return None
        return json.loads(str(row["params_json"]))
