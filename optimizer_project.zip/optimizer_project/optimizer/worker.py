from __future__ import annotations

import socket
from pathlib import Path
from typing import Any

from .adapters import get_adapter
from .config import load_blackbox_config, load_project_config
from .models import ArtifactInfo, WorkerOutcome, WorkerRequest
from .sandbox import create_sandbox
from .subprocess_runner import run_subprocess
from .utils import ensure_dir


def run_trial(
    request: WorkerRequest,
    *,
    project_config_path: str,
    blackbox_config_path: str,
) -> WorkerOutcome:
    project_cfg = load_project_config(project_config_path)
    blackbox_cfg = load_blackbox_config(blackbox_config_path)
    adapter = get_adapter(blackbox_cfg.adapter_name)
    adapter.validate_config(blackbox_cfg)

    hostname = socket.gethostname()
    template_dir = Path(project_cfg.template_dir)
    work_root = ensure_dir(Path(project_cfg.work_root))
    log_dir = ensure_dir(Path(project_cfg.log_dir))

    sandbox_dir = Path(".")
    runtime_sec = 0.0
    progress_last: float | int | None = None
    blackbox_rc: int | None = None
    pid: int | None = None

    stdout_path = log_dir / f"trial_{request.trial_id}.stdout.log"
    stderr_path = log_dir / f"trial_{request.trial_id}.stderr.log"

    status = "failed"
    failure_reason: str | None = None
    raw_result: dict[str, Any] = {}
    target_value: float | None = None
    artifacts: list[ArtifactInfo] = []

    try:
        sandbox_dir = create_sandbox(template_dir=template_dir, work_root=work_root, trial_id=request.trial_id)
    except Exception as exc:
        return WorkerOutcome(
            trial_id=request.trial_id,
            worker_id=request.worker_id,
            status="launch_error",
            goal=request.goal,
            target_value=None,
            raw_result={},
            params=request.candidate,
            params_hash=request.params_hash,
            runtime_sec=0.0,
            progress_last=None,
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            failure_reason=f"sandbox_create_error: {exc}",
            sandbox_path="",
            hostname=hostname,
            pid=None,
            blackbox_return_code=None,
            artifacts=[],
        )

    try:
        try:
            adapter.inject_parameters(sandbox_dir, request.candidate, blackbox_cfg)
        except Exception as exc:
            status = "injection_error"
            failure_reason = str(exc)
            return _finalize(
                request,
                status,
                failure_reason,
                target_value,
                raw_result,
                runtime_sec,
                progress_last,
                stdout_path,
                stderr_path,
                sandbox_dir,
                hostname,
                pid,
                blackbox_rc,
                artifacts,
            )

        command = adapter.build_command(sandbox_dir, blackbox_cfg)
        exec_cwd = sandbox_dir / blackbox_cfg.working_directory_relpath

        run_result = run_subprocess(
            command=command,
            cwd=exec_cwd,
            env=blackbox_cfg.env,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
            timeout_sec=project_cfg.timeout_sec,
            poll_interval_sec=project_cfg.poll_interval_sec,
            stuck_timeout_sec=project_cfg.stuck_timeout_sec,
            progress_reader=(
                (lambda: adapter.read_progress(sandbox_dir, blackbox_cfg))
                if blackbox_cfg.progress_file_relpath
                else None
            ),
        )

        runtime_sec = run_result.runtime_sec
        progress_last = run_result.progress_last
        blackbox_rc = run_result.return_code
        pid = run_result.pid

        if run_result.status in {"timeout", "stuck", "launch_error"}:
            status = run_result.status
            failure_reason = run_result.failure_reason
            return _finalize(
                request,
                status,
                failure_reason,
                target_value,
                raw_result,
                runtime_sec,
                progress_last,
                stdout_path,
                stderr_path,
                sandbox_dir,
                hostname,
                pid,
                blackbox_rc,
                artifacts,
            )

        if not adapter.detect_success(sandbox_dir, run_result, blackbox_cfg):
            status = "failed"
            failure_reason = f"blackbox_failed_rc={run_result.return_code}"
            if (
                run_result.return_code in blackbox_cfg.success_exit_codes
                and blackbox_cfg.result_file_relpath
                and not (sandbox_dir / blackbox_cfg.result_file_relpath).exists()
            ):
                failure_reason = (
                    f"missing_result_file: {sandbox_dir / blackbox_cfg.result_file_relpath}"
                )
            return _finalize(
                request,
                status,
                failure_reason,
                target_value,
                raw_result,
                runtime_sec,
                progress_last,
                stdout_path,
                stderr_path,
                sandbox_dir,
                hostname,
                pid,
                blackbox_rc,
                artifacts,
            )

        try:
            raw_result = adapter.parse_result(sandbox_dir, blackbox_cfg)
            target_value = adapter.compute_target(raw_result, blackbox_cfg)
            status = "success"
        except Exception as exc:
            status = "parse_error"
            failure_reason = str(exc)

        try:
            artifacts_data = adapter.collect_artifacts(sandbox_dir, blackbox_cfg)
            artifacts = [
                ArtifactInfo(kind=item.get("kind", "file"), path=item["path"], note=item.get("note", ""))
                for item in artifacts_data
                if "path" in item
            ]
        except Exception:
            artifacts = []

        return _finalize(
            request,
            status,
            failure_reason,
            target_value,
            raw_result,
            runtime_sec,
            progress_last,
            stdout_path,
            stderr_path,
            sandbox_dir,
            hostname,
            pid,
            blackbox_rc,
            artifacts,
        )
    finally:
        # Sandbox cleanup is intentionally done in orchestrator after DB write.
        pass


def _finalize(
    request: WorkerRequest,
    status: str,
    failure_reason: str | None,
    target_value: float | None,
    raw_result: dict[str, Any],
    runtime_sec: float,
    progress_last: float | int | None,
    stdout_path: Path,
    stderr_path: Path,
    sandbox_dir: Path,
    hostname: str,
    pid: int | None,
    blackbox_rc: int | None,
    artifacts: list[ArtifactInfo],
) -> WorkerOutcome:
    return WorkerOutcome(
        trial_id=request.trial_id,
        worker_id=request.worker_id,
        status=status,  # type: ignore[arg-type]
        goal=request.goal,
        target_value=target_value,
        raw_result=raw_result,
        params=request.candidate,
        params_hash=request.params_hash,
        runtime_sec=runtime_sec,
        progress_last=progress_last,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        failure_reason=failure_reason,
        sandbox_path=str(sandbox_dir),
        hostname=hostname,
        pid=pid,
        blackbox_return_code=blackbox_rc,
        artifacts=artifacts,
    )
