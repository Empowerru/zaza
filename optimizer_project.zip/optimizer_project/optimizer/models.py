from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Status = Literal[
    "queued",
    "running",
    "success",
    "failed",
    "timeout",
    "stuck",
    "parse_error",
    "injection_error",
    "launch_error",
]


@dataclass(slots=True)
class ParameterSpec:
    name: str
    type: str
    lower: float | int | None = None
    upper: float | int | None = None
    choices: list[Any] | None = None
    log_scale: bool = False
    step: float | int | None = None
    default: Any = None
    mutation_scale: float | None = None
    group: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "ParameterSpec":
        return ParameterSpec(
            name=data["name"],
            type=data["type"],
            lower=data.get("lower"),
            upper=data.get("upper"),
            choices=data.get("choices"),
            log_scale=bool(data.get("log_scale", False)),
            step=data.get("step"),
            default=data.get("default"),
            mutation_scale=data.get("mutation_scale"),
            group=data.get("group"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "type": self.type,
            "lower": self.lower,
            "upper": self.upper,
            "choices": self.choices,
            "log_scale": self.log_scale,
            "step": self.step,
            "default": self.default,
            "mutation_scale": self.mutation_scale,
            "group": self.group,
        }


@dataclass(slots=True)
class ProjectConfig:
    db_path: str
    template_dir: str
    work_root: str
    log_dir: str
    poll_interval_sec: float = 2.0
    timeout_sec: float = 3600.0
    stuck_timeout_sec: float = 600.0
    cleanup_policy: str = "delete_success_keep_failure"
    keep_best_n: int = 25
    resume: bool = True
    use_all_logical_cores: bool = True
    default_workers: int = 0
    goal: str = "minimize"
    max_trials: int | None = None
    random_seed: int = 12345
    hash_float_precision: int = 10
    search_method: str = "tpe"
    search_method_settings: dict[str, Any] = field(default_factory=dict)
    exploration_fraction: float = 0.30
    warmup_success_trials: int = 20
    elite_pool_size: int = 10
    summary_interval_sec: float = 30.0
    diagnostics: dict[str, Any] = field(default_factory=dict)
    retry_policy: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "ProjectConfig":
        return ProjectConfig(
            db_path=data["db_path"],
            template_dir=data["template_dir"],
            work_root=data["work_root"],
            log_dir=data["log_dir"],
            poll_interval_sec=float(data.get("poll_interval_sec", 2.0)),
            timeout_sec=float(data.get("timeout_sec", 3600.0)),
            stuck_timeout_sec=float(data.get("stuck_timeout_sec", 600.0)),
            cleanup_policy=data.get("cleanup_policy", "delete_success_keep_failure"),
            keep_best_n=int(data.get("keep_best_n", 25)),
            resume=bool(data.get("resume", True)),
            use_all_logical_cores=bool(data.get("use_all_logical_cores", True)),
            default_workers=int(data.get("default_workers", 0)),
            goal=data.get("goal", "minimize"),
            max_trials=data.get("max_trials"),
            random_seed=int(data.get("random_seed", 12345)),
            hash_float_precision=int(data.get("hash_float_precision", 10)),
            search_method=data.get("search_method", "tpe"),
            search_method_settings=dict(data.get("search_method_settings", {})),
            exploration_fraction=float(data.get("exploration_fraction", 0.30)),
            warmup_success_trials=int(data.get("warmup_success_trials", 20)),
            elite_pool_size=int(data.get("elite_pool_size", 10)),
            summary_interval_sec=float(data.get("summary_interval_sec", 30.0)),
            diagnostics=dict(data.get("diagnostics", {})),
            retry_policy=dict(data.get("retry_policy", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "db_path": self.db_path,
            "template_dir": self.template_dir,
            "work_root": self.work_root,
            "log_dir": self.log_dir,
            "poll_interval_sec": self.poll_interval_sec,
            "timeout_sec": self.timeout_sec,
            "stuck_timeout_sec": self.stuck_timeout_sec,
            "cleanup_policy": self.cleanup_policy,
            "keep_best_n": self.keep_best_n,
            "resume": self.resume,
            "use_all_logical_cores": self.use_all_logical_cores,
            "default_workers": self.default_workers,
            "goal": self.goal,
            "max_trials": self.max_trials,
            "random_seed": self.random_seed,
            "hash_float_precision": self.hash_float_precision,
            "search_method": self.search_method,
            "search_method_settings": self.search_method_settings,
            "exploration_fraction": self.exploration_fraction,
            "warmup_success_trials": self.warmup_success_trials,
            "elite_pool_size": self.elite_pool_size,
            "summary_interval_sec": self.summary_interval_sec,
            "diagnostics": self.diagnostics,
            "retry_policy": self.retry_policy,
        }


@dataclass(slots=True)
class BlackboxConfig:
    adapter_name: str
    executable_relpath: str
    command: list[str]
    working_directory_relpath: str
    main_input_file_relpath: str
    input_files: list[str]
    progress_file_relpath: str | None
    result_file_relpath: str | None
    success_exit_codes: list[int]
    failure_exit_codes: list[int]
    env: dict[str, str]
    parse_rules: dict[str, Any]
    injection_rules: dict[str, Any]
    artifacts_to_keep: list[dict[str, Any]]

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "BlackboxConfig":
        return BlackboxConfig(
            adapter_name=data["adapter_name"],
            executable_relpath=data["executable_relpath"],
            command=list(data["command"]),
            working_directory_relpath=data.get("working_directory_relpath", "."),
            main_input_file_relpath=data.get("main_input_file_relpath", "laser.in"),
            input_files=list(data.get("input_files", [])),
            progress_file_relpath=data.get("progress_file_relpath"),
            result_file_relpath=data.get("result_file_relpath"),
            success_exit_codes=list(data.get("success_exit_codes", [0])),
            failure_exit_codes=list(data.get("failure_exit_codes", [])),
            env=dict(data.get("env", {})),
            parse_rules=dict(data.get("parse_rules", {})),
            injection_rules=dict(data.get("injection_rules", {})),
            artifacts_to_keep=list(data.get("artifacts_to_keep", [])),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "adapter_name": self.adapter_name,
            "executable_relpath": self.executable_relpath,
            "command": self.command,
            "working_directory_relpath": self.working_directory_relpath,
            "main_input_file_relpath": self.main_input_file_relpath,
            "input_files": self.input_files,
            "progress_file_relpath": self.progress_file_relpath,
            "result_file_relpath": self.result_file_relpath,
            "success_exit_codes": self.success_exit_codes,
            "failure_exit_codes": self.failure_exit_codes,
            "env": self.env,
            "parse_rules": self.parse_rules,
            "injection_rules": self.injection_rules,
            "artifacts_to_keep": self.artifacts_to_keep,
        }


@dataclass(slots=True)
class ArtifactInfo:
    kind: str
    path: str
    note: str = ""


@dataclass(slots=True)
class WorkerRequest:
    trial_id: int
    worker_id: int
    candidate: dict[str, Any]
    params_hash: str
    goal: str
    retry_of_trial_id: int | None = None
    attempt_index: int = 0


@dataclass(slots=True)
class ProcessRunResult:
    status: str
    return_code: int | None
    runtime_sec: float
    progress_last: float | int | None
    failure_reason: str | None
    stdout_path: str
    stderr_path: str
    pid: int | None


@dataclass(slots=True)
class WorkerOutcome:
    trial_id: int
    worker_id: int
    status: Status
    goal: str
    target_value: float | None
    raw_result: dict[str, Any]
    params: dict[str, Any]
    params_hash: str
    runtime_sec: float
    progress_last: float | int | None
    stdout_path: str
    stderr_path: str
    failure_reason: str | None
    sandbox_path: str
    hostname: str
    pid: int | None
    blackbox_return_code: int | None
    artifacts: list[ArtifactInfo] = field(default_factory=list)


@dataclass(slots=True)
class TrialSummary:
    trial_id: int
    status: str
    target_value: float | None
    params: dict[str, Any]
    params_hash: str
    finished_at: str | None
