from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from ..blackbox_interface import BlackBoxAdapter
from ..models import BlackboxConfig, ProcessRunResult
from .mock_laser_injector import REQUIRED_PARAMS, inject_mock_laser_trial_inputs, validate_and_normalize_candidate


class MockLaserAdapter(BlackBoxAdapter):
    # Injection logic is delegated to `mock_laser_injector.py`.
    # Customize trial input file writing there.
    REQUIRED_PARAMS = REQUIRED_PARAMS

    def validate_config(self, blackbox_config: BlackboxConfig) -> None:
        if not blackbox_config.executable_relpath:
            raise ValueError("blackbox.executable_relpath is required")
        if not blackbox_config.command:
            raise ValueError("blackbox.command is required")
        rules = blackbox_config.injection_rules
        for key in ["laser_in_relpath", "block1_file_relpath", "block2_file_relpath"]:
            if key not in rules:
                raise ValueError(f"injection_rules.{key} is required")

    def build_parameter_dict(self, candidate: dict[str, Any]) -> dict[str, Any]:
        return validate_and_normalize_candidate(candidate)

    def inject_parameters(
        self,
        sandbox_dir: Path,
        candidate: dict[str, Any],
        blackbox_config: BlackboxConfig,
    ) -> None:
        inject_mock_laser_trial_inputs(sandbox_dir, candidate, blackbox_config)

    def build_command(self, sandbox_dir: Path, blackbox_config: BlackboxConfig) -> list[str]:
        executable = sandbox_dir / blackbox_config.executable_relpath
        if not executable.exists():
            raise FileNotFoundError(f"Executable not found: {executable}")

        mapping = {
            "executable": str(executable),
            "main_input_file": blackbox_config.main_input_file_relpath,
            "sandbox_dir": str(sandbox_dir),
        }
        return [token.format(**mapping) for token in blackbox_config.command]

    def read_progress(
        self,
        sandbox_dir: Path,
        blackbox_config: BlackboxConfig,
    ) -> float | int | None:
        rel = blackbox_config.progress_file_relpath
        if not rel:
            return None
        path = sandbox_dir / rel
        if not path.exists():
            return None
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            return None
        return int(text)

    def detect_success(
        self,
        sandbox_dir: Path,
        process_result: ProcessRunResult,
        blackbox_config: BlackboxConfig,
    ) -> bool:
        if process_result.return_code not in blackbox_config.success_exit_codes:
            return False
        if blackbox_config.result_file_relpath:
            return (sandbox_dir / blackbox_config.result_file_relpath).exists()
        return True

    def parse_result(self, sandbox_dir: Path, blackbox_config: BlackboxConfig) -> dict[str, Any]:
        if not blackbox_config.result_file_relpath:
            raise ValueError("result_file_relpath is required for mock adapter")
        result_path = sandbox_dir / blackbox_config.result_file_relpath
        if not result_path.exists():
            raise FileNotFoundError(f"Result file missing: {result_path}")
        text = result_path.read_text(encoding="utf-8").strip()
        value = float(text)
        return {"objective": value}

    def compute_target(self, parsed_result: dict[str, Any], blackbox_config: BlackboxConfig) -> float:
        objective = float(parsed_result["objective"])
        transform = str(blackbox_config.parse_rules.get("transform", "identity"))
        if transform == "identity":
            return objective
        if transform == "negate":
            return -objective
        raise ValueError(f"Unsupported parse_rules.transform: {transform}")

    def collect_artifacts(
        self,
        sandbox_dir: Path,
        blackbox_config: BlackboxConfig,
    ) -> list[dict[str, str]]:
        artifacts: list[dict[str, str]] = []
        for item in blackbox_config.artifacts_to_keep:
            rel = item.get("path")
            if not rel:
                continue
            path = sandbox_dir / rel
            if path.exists():
                artifacts.append(
                    {
                        "kind": item.get("kind", "file"),
                        "path": str(path),
                        "note": item.get("note", ""),
                    }
                )
        return artifacts

    def parameter_fingerprint(self, candidate: dict[str, Any]) -> str:
        normalized = {k: round(float(v), 12) for k, v in sorted(candidate.items())}
        blob = json.dumps(normalized, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()
