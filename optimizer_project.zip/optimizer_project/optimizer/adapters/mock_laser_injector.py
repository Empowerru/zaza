from __future__ import annotations

from pathlib import Path
from typing import Any

from ..models import BlackboxConfig

# EDIT THIS FILE FOR CUSTOM TRIAL INPUT INJECTION LOGIC.
# This module is intentionally separated so you can adapt it to your real
# legacy black box without changing the generic optimizer engine.

REQUIRED_PARAMS = [
    "laser1.integral",
    "block1.parameter_1",
    "block1.parameter_2",
    "block1.parameter_3",
    "block1.parameter_4",
    "laser2.integral",
    "block2.parameter_1",
    "block2.parameter_2",
    "block2.parameter_3",
    "block2.parameter_4",
]


def validate_and_normalize_candidate(candidate: dict[str, Any]) -> dict[str, float]:
    out: dict[str, float] = {}
    for key in REQUIRED_PARAMS:
        if key not in candidate:
            raise ValueError(f"Missing parameter: {key}")
        value = float(candidate[key])
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"{key} out of range [0,1]: {value}")
        out[key] = value
    return out


def inject_mock_laser_trial_inputs(
    sandbox_dir: Path,
    candidate: dict[str, Any],
    blackbox_config: BlackboxConfig,
) -> None:
    p = validate_and_normalize_candidate(candidate)
    rules = blackbox_config.injection_rules

    laser_in_rel = str(rules["laser_in_relpath"])
    block1_file_rel = str(rules["block1_file_relpath"])
    block2_file_rel = str(rules["block2_file_relpath"])

    laser_in_path = sandbox_dir / laser_in_rel
    file1_path = sandbox_dir / block1_file_rel
    file2_path = sandbox_dir / block2_file_rel

    file1_path.parent.mkdir(parents=True, exist_ok=True)
    file2_path.parent.mkdir(parents=True, exist_ok=True)

    # Flat profiles make trapezoidal integral exactly equal to y over [0,1].
    file1_path.write_text(f"0.0 {p['laser1.integral']:.12f}\n1.0 {p['laser1.integral']:.12f}\n", encoding="utf-8")
    file2_path.write_text(f"0.0 {p['laser2.integral']:.12f}\n1.0 {p['laser2.integral']:.12f}\n", encoding="utf-8")

    laser_in_path.parent.mkdir(parents=True, exist_ok=True)
    laser_in_path.write_text(
        "\n".join(
            [
                f"file_name: {_to_legacy_path(block1_file_rel)}",
                f"parameter_1: {p['block1.parameter_1']:.12f}",
                f"parameter_2: {p['block1.parameter_2']:.12f}",
                f"parameter_3: {p['block1.parameter_3']:.12f}",
                f"parameter_4: {p['block1.parameter_4']:.12f}",
                "",
                f"file_name: {_to_legacy_path(block2_file_rel)}",
                f"parameter_1: {p['block2.parameter_1']:.12f}",
                f"parameter_2: {p['block2.parameter_2']:.12f}",
                f"parameter_3: {p['block2.parameter_3']:.12f}",
                f"parameter_4: {p['block2.parameter_4']:.12f}",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _to_legacy_path(path: str) -> str:
    return path.replace("/", "\\")
