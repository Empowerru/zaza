from __future__ import annotations

from .mock_laser_adapter import MockLaserAdapter


def get_adapter(name: str):
    registry = {
        "mock_laser_adapter": MockLaserAdapter,
        "mock_laser": MockLaserAdapter,
    }
    if name not in registry:
        raise ValueError(f"Unknown adapter: {name}")
    return registry[name]()
