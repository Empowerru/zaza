from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from .models import BlackboxConfig, ProcessRunResult


class BlackBoxAdapter(ABC):
    @abstractmethod
    def validate_config(self, blackbox_config: BlackboxConfig) -> None:
        raise NotImplementedError

    @abstractmethod
    def build_parameter_dict(self, candidate: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def inject_parameters(
        self,
        sandbox_dir: Path,
        candidate: dict[str, Any],
        blackbox_config: BlackboxConfig,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def build_command(self, sandbox_dir: Path, blackbox_config: BlackboxConfig) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def read_progress(
        self,
        sandbox_dir: Path,
        blackbox_config: BlackboxConfig,
    ) -> float | int | None:
        raise NotImplementedError

    @abstractmethod
    def detect_success(
        self,
        sandbox_dir: Path,
        process_result: ProcessRunResult,
        blackbox_config: BlackboxConfig,
    ) -> bool:
        raise NotImplementedError

    @abstractmethod
    def parse_result(self, sandbox_dir: Path, blackbox_config: BlackboxConfig) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def compute_target(self, parsed_result: dict[str, Any], blackbox_config: BlackboxConfig) -> float:
        raise NotImplementedError

    @abstractmethod
    def collect_artifacts(
        self,
        sandbox_dir: Path,
        blackbox_config: BlackboxConfig,
    ) -> list[dict[str, str]]:
        raise NotImplementedError

    @abstractmethod
    def parameter_fingerprint(self, candidate: dict[str, Any]) -> str:
        raise NotImplementedError
