"""Generic black-box optimization framework."""

from .orchestrator import OptimizerOrchestrator

__all__ = ["OptimizerOrchestrator"]
