from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ProgressTracker:
    last_value: float | int | None = None
    last_change_ts: float = 0.0
    ever_seen: bool = False

    def observe(self, value: float | int | None, now_ts: float) -> None:
        if value is None:
            return
        if not self.ever_seen:
            self.ever_seen = True
            self.last_value = value
            self.last_change_ts = now_ts
            return
        if value != self.last_value:
            self.last_value = value
            self.last_change_ts = now_ts

    def is_stuck(self, now_ts: float, stuck_timeout_sec: float) -> bool:
        if not self.ever_seen:
            return False
        return (now_ts - self.last_change_ts) > stuck_timeout_sec
