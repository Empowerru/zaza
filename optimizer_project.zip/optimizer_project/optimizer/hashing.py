from __future__ import annotations

import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP
from typing import Any


def _normalize_float(value: float, precision: int) -> str:
    quant = Decimal("1").scaleb(-precision)
    return format(Decimal(str(value)).quantize(quant, rounding=ROUND_HALF_UP), "f")


def canonicalize_candidate(candidate: dict[str, Any], float_precision: int) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key in sorted(candidate):
        value = candidate[key]
        if isinstance(value, bool):
            normalized[key] = bool(value)
        elif isinstance(value, int):
            normalized[key] = int(value)
        elif isinstance(value, float):
            normalized[key] = _normalize_float(value, float_precision)
        else:
            normalized[key] = value
    return normalized


def parameter_hash(candidate: dict[str, Any], float_precision: int = 10) -> str:
    canonical = canonicalize_candidate(candidate, float_precision)
    blob = json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()
