from __future__ import annotations

import inspect
import math
import random
from abc import ABC, abstractmethod
from typing import Any

from .models import ParameterSpec

try:
    import optuna
    from optuna.distributions import CategoricalDistribution, FloatDistribution, IntDistribution
    from optuna.trial import TrialState, create_trial
except Exception:  # pragma: no cover - optional dependency.
    optuna = None  # type: ignore[assignment]
    CategoricalDistribution = None  # type: ignore[assignment]
    FloatDistribution = None  # type: ignore[assignment]
    IntDistribution = None  # type: ignore[assignment]
    TrialState = None  # type: ignore[assignment]
    create_trial = None  # type: ignore[assignment]


class SearchStrategy(ABC):
    @abstractmethod
    def propose(
        self,
        *,
        successful_trials: list[dict[str, Any]],
        hash_fn,
        existing_hashes: set[str],
        ) -> tuple[dict[str, Any], str]:
        raise NotImplementedError


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    return text in {"1", "true", "yes", "on", "y"}


class _SamplingMixin:
    def __init__(self, *, search_space: list[ParameterSpec], rng: random.Random) -> None:
        self.search_space = search_space
        self.rng = rng
        self._strata = 64
        self._lhs_bins: dict[str, list[int]] = {}

    def sample_exploration(self) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for spec in self.search_space:
            result[spec.name] = self.sample_param(spec)
        return result

    def sample_param(self, spec: ParameterSpec) -> Any:
        if spec.type == "float":
            if spec.lower is None or spec.upper is None:
                raise ValueError(f"Float param {spec.name} missing bounds")
            if spec.log_scale and spec.lower > 0:
                u = self._lhs_unit(spec.name)
                low = math.log(float(spec.lower))
                high = math.log(float(spec.upper))
                value = math.exp(low + u * (high - low))
            else:
                u = self._lhs_unit(spec.name)
                value = float(spec.lower) + u * (float(spec.upper) - float(spec.lower))
            if spec.step is not None:
                value = self._quantize(value, float(spec.lower), float(spec.step))
            return max(float(spec.lower), min(float(spec.upper), float(value)))

        if spec.type == "int":
            if spec.lower is None or spec.upper is None:
                raise ValueError(f"Int param {spec.name} missing bounds")
            value = self.rng.randint(int(spec.lower), int(spec.upper))
            if spec.step is not None:
                step = int(spec.step)
                value = int(spec.lower) + ((value - int(spec.lower)) // step) * step
            return int(value)

        if spec.type == "categorical":
            if not spec.choices:
                raise ValueError(f"Categorical param {spec.name} has no choices")
            return self.rng.choice(spec.choices)

        if spec.type == "bool":
            return bool(self.rng.getrandbits(1))

        raise ValueError(f"Unsupported parameter type: {spec.type}")

    def _lhs_unit(self, key: str) -> float:
        bins = self._lhs_bins.get(key)
        if not bins:
            bins = list(range(self._strata))
            self.rng.shuffle(bins)
            self._lhs_bins[key] = bins
        idx = bins.pop()
        low = idx / self._strata
        high = (idx + 1) / self._strata
        return self.rng.uniform(low, high)

    @staticmethod
    def _quantize(value: float, lower: float, step: float) -> float:
        if step <= 0:
            return value
        n = round((value - lower) / step)
        return lower + n * step


class AsyncEvolutionSearch(SearchStrategy, _SamplingMixin):
    def __init__(
        self,
        *,
        search_space: list[ParameterSpec],
        exploration_fraction: float,
        warmup_success_trials: int,
        elite_pool_size: int,
        random_seed: int,
    ) -> None:
        rng = random.Random(random_seed)
        _SamplingMixin.__init__(self, search_space=search_space, rng=rng)
        self.exploration_fraction = exploration_fraction
        self.warmup_success_trials = warmup_success_trials
        self.elite_pool_size = max(1, elite_pool_size)

    def propose(
        self,
        *,
        successful_trials: list[dict[str, Any]],
        hash_fn,
        existing_hashes: set[str],
    ) -> tuple[dict[str, Any], str]:
        for _ in range(500):
            if (
                len(successful_trials) < self.warmup_success_trials
                or self.rng.random() < self.exploration_fraction
            ):
                candidate = self.sample_exploration()
            else:
                candidate = self._sample_exploitation(successful_trials)
            p_hash = hash_fn(candidate)
            if p_hash not in existing_hashes:
                return candidate, p_hash
        raise RuntimeError("Failed to sample a non-duplicate candidate")

    def _sample_exploitation(self, successful_trials: list[dict[str, Any]]) -> dict[str, Any]:
        elite = successful_trials[: self.elite_pool_size]
        weights = [1.0 / (idx + 1) for idx in range(len(elite))]
        parent = self.rng.choices(elite, weights=weights, k=1)[0]["params"]

        result: dict[str, Any] = {}
        for spec in self.search_space:
            parent_val = parent.get(spec.name, spec.default)
            if parent_val is None:
                result[spec.name] = self.sample_param(spec)
                continue

            if spec.type == "float":
                lo = float(spec.lower)
                hi = float(spec.upper)
                span = max(1e-12, hi - lo)
                sigma = (spec.mutation_scale if spec.mutation_scale is not None else 0.08) * span
                if self.rng.random() < 0.1:
                    value = self.sample_param(spec)
                else:
                    value = float(parent_val) + self.rng.gauss(0.0, sigma)
                value = max(lo, min(hi, float(value)))
                if spec.step is not None:
                    value = self._quantize(value, lo, float(spec.step))
                result[spec.name] = value
            elif spec.type == "int":
                lo = int(spec.lower)
                hi = int(spec.upper)
                span = max(1, hi - lo)
                sigma = (spec.mutation_scale if spec.mutation_scale is not None else 0.08) * span
                if self.rng.random() < 0.1:
                    value = self.sample_param(spec)
                else:
                    value = int(round(int(parent_val) + self.rng.gauss(0.0, sigma)))
                value = max(lo, min(hi, value))
                if spec.step is not None:
                    step = int(spec.step)
                    value = lo + ((value - lo) // step) * step
                result[spec.name] = int(value)
            elif spec.type == "categorical":
                result[spec.name] = parent_val if self.rng.random() >= 0.2 else self.sample_param(spec)
            elif spec.type == "bool":
                result[spec.name] = (not bool(parent_val)) if self.rng.random() < 0.15 else bool(parent_val)
            else:
                raise ValueError(f"Unsupported parameter type: {spec.type}")
        return result


class TPESearch(SearchStrategy, _SamplingMixin):
    def __init__(
        self,
        *,
        search_space: list[ParameterSpec],
        exploration_fraction: float,
        warmup_success_trials: int,
        random_seed: int,
        settings: dict[str, Any] | None = None,
    ) -> None:
        rng = random.Random(random_seed)
        _SamplingMixin.__init__(self, search_space=search_space, rng=rng)
        settings = settings or {}
        self.exploration_fraction = exploration_fraction
        self.warmup_success_trials = warmup_success_trials
        self.gamma = float(settings.get("gamma", 0.20))
        self.candidates_per_step = int(settings.get("candidates_per_step", 64))
        self.min_good = int(settings.get("min_good", 8))

    def propose(
        self,
        *,
        successful_trials: list[dict[str, Any]],
        hash_fn,
        existing_hashes: set[str],
    ) -> tuple[dict[str, Any], str]:
        for _ in range(200):
            if (
                len(successful_trials) < self.warmup_success_trials
                or self.rng.random() < self.exploration_fraction
            ):
                candidate = self.sample_exploration()
                p_hash = hash_fn(candidate)
                if p_hash not in existing_hashes:
                    return candidate, p_hash
                continue

            candidate = self._sample_tpe(successful_trials, hash_fn, existing_hashes)
            p_hash = hash_fn(candidate)
            if p_hash not in existing_hashes:
                return candidate, p_hash

        raise RuntimeError("Failed to sample a non-duplicate candidate")

    def _sample_tpe(
        self,
        successful_trials: list[dict[str, Any]],
        hash_fn,
        existing_hashes: set[str],
    ) -> dict[str, Any]:
        n_total = len(successful_trials)
        if n_total < 2:
            return self.sample_exploration()

        n_good = max(self.min_good, int(self.gamma * n_total))
        n_good = min(n_total - 1, max(1, n_good))

        good_trials = successful_trials[:n_good]
        bad_trials = successful_trials[n_good:]
        if not bad_trials:
            return self.sample_exploration()

        good_values = self._extract_param_values(good_trials)
        bad_values = self._extract_param_values(bad_trials)

        best_candidate: dict[str, Any] | None = None
        best_score = float("-inf")

        for _ in range(max(8, self.candidates_per_step)):
            candidate = self._sample_from_good(good_values)
            p_hash = hash_fn(candidate)
            if p_hash in existing_hashes:
                continue
            score = self._score_ratio(candidate, good_values, bad_values)
            if score > best_score:
                best_score = score
                best_candidate = candidate

        if best_candidate is not None:
            return best_candidate
        return self.sample_exploration()

    def _extract_param_values(self, trials: list[dict[str, Any]]) -> dict[str, list[Any]]:
        values: dict[str, list[Any]] = {spec.name: [] for spec in self.search_space}
        for t in trials:
            params = t["params"]
            for spec in self.search_space:
                if spec.name in params:
                    values[spec.name].append(params[spec.name])
        return values

    def _sample_from_good(self, good_values: dict[str, list[Any]]) -> dict[str, Any]:
        candidate: dict[str, Any] = {}
        for spec in self.search_space:
            vals = good_values.get(spec.name, [])
            if not vals:
                candidate[spec.name] = self.sample_param(spec)
                continue

            if spec.type == "float":
                lo = float(spec.lower)
                hi = float(spec.upper)
                sigma = self._bandwidth(spec, vals, lo, hi)
                base = float(self.rng.choice(vals))
                value = base + self.rng.gauss(0.0, sigma)
                value = max(lo, min(hi, value))
                if spec.step is not None:
                    value = self._quantize(value, lo, float(spec.step))
                candidate[spec.name] = float(value)
            elif spec.type == "int":
                lo = int(spec.lower)
                hi = int(spec.upper)
                sigma = max(1.0, self._bandwidth(spec, vals, float(lo), float(hi)))
                base = int(self.rng.choice(vals))
                value = int(round(base + self.rng.gauss(0.0, sigma)))
                value = max(lo, min(hi, value))
                if spec.step is not None:
                    step = int(spec.step)
                    value = lo + ((value - lo) // step) * step
                candidate[spec.name] = int(value)
            elif spec.type == "categorical":
                candidate[spec.name] = self._sample_discrete(vals, spec.choices or [])
            elif spec.type == "bool":
                candidate[spec.name] = bool(self._sample_discrete(vals, [False, True]))
            else:
                raise ValueError(f"Unsupported parameter type: {spec.type}")
        return candidate

    def _score_ratio(
        self,
        candidate: dict[str, Any],
        good_values: dict[str, list[Any]],
        bad_values: dict[str, list[Any]],
    ) -> float:
        score = 0.0
        for spec in self.search_space:
            x = candidate[spec.name]
            gv = good_values.get(spec.name, [])
            bv = bad_values.get(spec.name, [])
            if spec.type in {"float", "int"}:
                lo = float(spec.lower)
                hi = float(spec.upper)
                sigma_g = self._bandwidth(spec, gv, lo, hi)
                sigma_b = self._bandwidth(spec, bv, lo, hi)
                log_l = self._log_gaussian_mixture(float(x), [float(v) for v in gv], sigma_g)
                log_g = self._log_gaussian_mixture(float(x), [float(v) for v in bv], sigma_b)
                score += log_l - log_g
            elif spec.type == "categorical":
                choices = spec.choices or []
                score += self._log_discrete_prob(x, gv, choices) - self._log_discrete_prob(x, bv, choices)
            elif spec.type == "bool":
                choices_bool = [False, True]
                score += self._log_discrete_prob(bool(x), [bool(v) for v in gv], choices_bool) - self._log_discrete_prob(
                    bool(x), [bool(v) for v in bv], choices_bool
                )
            else:
                raise ValueError(f"Unsupported parameter type: {spec.type}")
        return score

    def _bandwidth(self, spec: ParameterSpec, values: list[Any], lo: float, hi: float) -> float:
        span = max(1e-12, hi - lo)
        base = (spec.mutation_scale if spec.mutation_scale is not None else 0.08) * span
        vals = [float(v) for v in values]
        if len(vals) < 2:
            return max(base, 0.005 * span)
        mean = sum(vals) / len(vals)
        var = sum((v - mean) ** 2 for v in vals) / max(1, len(vals) - 1)
        std = math.sqrt(max(0.0, var))
        return max(base, 0.5 * std, 0.005 * span)

    @staticmethod
    def _log_gaussian_mixture(x: float, values: list[float], sigma: float) -> float:
        if not values:
            return -1e12
        sigma = max(1e-12, sigma)
        logs = []
        inv = 1.0 / sigma
        for m in values:
            z = (x - m) * inv
            logs.append(-0.5 * z * z)
        max_log = max(logs)
        sum_exp = sum(math.exp(v - max_log) for v in logs)
        return max_log + math.log(sum_exp) - math.log(len(values)) - math.log(sigma)

    def _sample_discrete(self, values: list[Any], choices: list[Any]) -> Any:
        if not choices:
            return self.rng.choice(values)
        alpha = 1.0
        counts = {c: alpha for c in choices}
        for v in values:
            if v in counts:
                counts[v] += 1.0
        total = sum(counts.values())
        r = self.rng.random() * total
        acc = 0.0
        for key, weight in counts.items():
            acc += weight
            if r <= acc:
                return key
        return choices[-1]

    @staticmethod
    def _log_discrete_prob(value: Any, values: list[Any], choices: list[Any]) -> float:
        if not choices:
            return -1e12
        alpha = 1.0
        k = len(choices)
        counts = {c: alpha for c in choices}
        for v in values:
            if v in counts:
                counts[v] += 1.0
        total = sum(counts.values())
        prob = counts.get(value, alpha) / max(1e-12, total)
        if prob <= 0.0:
            return -1e12
        return math.log(prob) - math.log(1.0 / k)


class OptunaTPESearch(SearchStrategy):
    def __init__(
        self,
        *,
        search_space: list[ParameterSpec],
        random_seed: int,
        goal: str,
        settings: dict[str, Any] | None = None,
    ) -> None:
        if optuna is None:
            raise RuntimeError(
                "search_method=optuna_tpe requires Optuna. Install with: "
                "python -m pip install -r requirements.txt"
            )
        settings = settings or {}
        self.search_space = search_space
        self.goal = goal
        self._pending: dict[str, tuple[int, dict[str, Any]]] = {}
        self._synced_hashes: set[str] = set()

        sampler_cls = optuna.samplers.TPESampler
        sig = inspect.signature(sampler_cls.__init__)

        seed = int(settings.get("optuna_seed", random_seed))
        startup = int(settings.get("optuna_n_startup_trials", settings.get("n_startup_trials", 20)))
        ei_candidates = int(settings.get("optuna_n_ei_candidates", settings.get("n_ei_candidates", 64)))
        multivariate = _as_bool(settings.get("optuna_multivariate", True), True)
        group = _as_bool(settings.get("optuna_group", False), False)
        constant_liar = _as_bool(settings.get("optuna_constant_liar", True), True)

        sampler_kwargs: dict[str, Any] = {}
        if "seed" in sig.parameters:
            sampler_kwargs["seed"] = seed
        if "n_startup_trials" in sig.parameters:
            sampler_kwargs["n_startup_trials"] = startup
        if "n_ei_candidates" in sig.parameters:
            sampler_kwargs["n_ei_candidates"] = ei_candidates
        if "multivariate" in sig.parameters:
            sampler_kwargs["multivariate"] = multivariate
        if "group" in sig.parameters:
            sampler_kwargs["group"] = group
        if "constant_liar" in sig.parameters:
            sampler_kwargs["constant_liar"] = constant_liar

        direction = "maximize" if goal == "maximize" else "minimize"
        self.study = optuna.create_study(
            direction=direction,
            sampler=sampler_cls(**sampler_kwargs),
        )

    def propose(
        self,
        *,
        successful_trials: list[dict[str, Any]],
        hash_fn,
        existing_hashes: set[str],
    ) -> tuple[dict[str, Any], str]:
        self._sync_success_history(successful_trials, hash_fn)

        for _ in range(500):
            trial = self.study.ask()
            candidate = self._suggest_candidate(trial)
            p_hash = hash_fn(candidate)
            if p_hash in existing_hashes or p_hash in self._pending:
                self.study.tell(trial, state=TrialState.PRUNED)
                continue
            self._pending[p_hash] = (int(trial.number), candidate)
            return candidate, p_hash

        raise RuntimeError("Failed to sample a non-duplicate candidate")

    def _sync_success_history(self, successful_trials: list[dict[str, Any]], hash_fn) -> None:
        for row in successful_trials:
            params_raw = row.get("params")
            target_raw = row.get("target_value")
            if not isinstance(params_raw, dict) or target_raw is None:
                continue
            params = {str(k): v for k, v in params_raw.items()}
            p_hash = hash_fn(params)
            if p_hash in self._synced_hashes:
                continue

            value = float(target_raw)
            pending = self._pending.pop(p_hash, None)
            if pending is not None:
                trial_number, pending_candidate = pending
                try:
                    self.study.tell(trial_number, value)
                except Exception:
                    self._add_completed_trial(pending_candidate, value)
            else:
                self._add_completed_trial(params, value)

            self._synced_hashes.add(p_hash)

    def _suggest_candidate(self, trial) -> dict[str, Any]:
        candidate: dict[str, Any] = {}
        for spec in self.search_space:
            if spec.type == "float":
                lo = float(spec.lower)
                hi = float(spec.upper)
                if spec.step is not None:
                    value = trial.suggest_float(spec.name, lo, hi, step=float(spec.step))
                else:
                    use_log = bool(spec.log_scale and lo > 0.0)
                    value = trial.suggest_float(spec.name, lo, hi, log=use_log)
                candidate[spec.name] = float(value)
                continue

            if spec.type == "int":
                lo = int(spec.lower)
                hi = int(spec.upper)
                step = int(spec.step) if spec.step is not None else 1
                use_log = bool(spec.log_scale and step == 1 and lo > 0)
                value = trial.suggest_int(spec.name, lo, hi, step=step, log=use_log)
                candidate[spec.name] = int(value)
                continue

            if spec.type == "categorical":
                if not spec.choices:
                    raise ValueError(f"Categorical param {spec.name} has no choices")
                candidate[spec.name] = trial.suggest_categorical(spec.name, list(spec.choices))
                continue

            if spec.type == "bool":
                candidate[spec.name] = bool(trial.suggest_categorical(spec.name, [False, True]))
                continue

            raise ValueError(f"Unsupported parameter type: {spec.type}")
        return candidate

    def _add_completed_trial(self, params_raw: dict[str, Any], value: float) -> None:
        params = self._normalize_params(params_raw)
        distributions = {
            spec.name: self._distribution_for_spec(spec)
            for spec in self.search_space
        }
        frozen = create_trial(
            params=params,
            distributions=distributions,
            value=float(value),
            state=TrialState.COMPLETE,
        )
        self.study.add_trial(frozen)

    def _normalize_params(self, params_raw: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for spec in self.search_space:
            if spec.name not in params_raw:
                raise ValueError(f"Missing parameter in completed trial: {spec.name}")
            val = params_raw[spec.name]
            if spec.type == "float":
                out[spec.name] = float(val)
            elif spec.type == "int":
                out[spec.name] = int(val)
            elif spec.type == "categorical":
                out[spec.name] = val
            elif spec.type == "bool":
                out[spec.name] = bool(val)
            else:
                raise ValueError(f"Unsupported parameter type: {spec.type}")
        return out

    @staticmethod
    def _distribution_for_spec(spec: ParameterSpec):
        if spec.type == "float":
            lo = float(spec.lower)
            hi = float(spec.upper)
            if spec.step is not None:
                return FloatDistribution(lo, hi, step=float(spec.step))
            use_log = bool(spec.log_scale and lo > 0.0)
            return FloatDistribution(lo, hi, log=use_log)

        if spec.type == "int":
            lo = int(spec.lower)
            hi = int(spec.upper)
            step = int(spec.step) if spec.step is not None else 1
            use_log = bool(spec.log_scale and step == 1 and lo > 0)
            return IntDistribution(lo, hi, step=step, log=use_log)

        if spec.type == "categorical":
            if not spec.choices:
                raise ValueError(f"Categorical param {spec.name} has no choices")
            return CategoricalDistribution(list(spec.choices))

        if spec.type == "bool":
            return CategoricalDistribution([False, True])

        raise ValueError(f"Unsupported parameter type: {spec.type}")


def create_search_strategy(
    *,
    method: str,
    search_space: list[ParameterSpec],
    exploration_fraction: float,
    warmup_success_trials: int,
    elite_pool_size: int,
    random_seed: int,
    goal: str = "minimize",
    method_settings: dict[str, Any] | None = None,
) -> SearchStrategy:
    m = method.strip().lower()
    if m in {"async_evolution", "evolution", "random_mutation"}:
        return AsyncEvolutionSearch(
            search_space=search_space,
            exploration_fraction=exploration_fraction,
            warmup_success_trials=warmup_success_trials,
            elite_pool_size=elite_pool_size,
            random_seed=random_seed,
        )
    if m in {"tpe", "async_tpe"}:
        return TPESearch(
            search_space=search_space,
            exploration_fraction=exploration_fraction,
            warmup_success_trials=warmup_success_trials,
            random_seed=random_seed,
            settings=method_settings,
        )
    if m in {"optuna_tpe", "optuna", "bayes_optuna"}:
        return OptunaTPESearch(
            search_space=search_space,
            random_seed=random_seed,
            goal=goal,
            settings=method_settings,
        )
    raise ValueError(f"Unknown search method: {method}")
