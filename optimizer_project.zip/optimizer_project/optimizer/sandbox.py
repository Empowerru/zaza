from __future__ import annotations

import re
import shutil
from pathlib import Path
from uuid import uuid4

from .utils import ensure_dir


TRIAL_DIR_RE = re.compile(r"^trial_(\d+)_")


def create_sandbox(template_dir: Path, work_root: Path, trial_id: int) -> Path:
    ensure_dir(work_root)
    sandbox_dir = work_root / f"trial_{trial_id}_{uuid4().hex[:8]}"
    shutil.copytree(template_dir, sandbox_dir)
    return sandbox_dir


def remove_sandbox(sandbox_dir: Path) -> None:
    if sandbox_dir.exists():
        shutil.rmtree(sandbox_dir, ignore_errors=True)


def prune_keep_best_n(work_root: Path, keep_trial_ids: set[int]) -> None:
    if not work_root.exists():
        return
    for child in work_root.iterdir():
        if not child.is_dir():
            continue
        m = TRIAL_DIR_RE.match(child.name)
        if not m:
            continue
        trial_id = int(m.group(1))
        if trial_id not in keep_trial_ids:
            shutil.rmtree(child, ignore_errors=True)
