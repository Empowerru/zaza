from __future__ import annotations

from datetime import datetime
from typing import Iterable


def compute_best_curve(values: list[float], goal: str) -> list[float]:
    best: list[float] = []
    current: float | None = None
    for value in values:
        if current is None:
            current = value
        else:
            if goal == "minimize":
                current = min(current, value)
            else:
                current = max(current, value)
        best.append(current)
    return best


def success_rate(total: int, success: int) -> float:
    if total <= 0:
        return 0.0
    return 100.0 * float(success) / float(total)


def trials_per_hour(total_launched: int, first_finished_at: str | None, last_finished_at: str | None) -> float:
    if total_launched <= 1:
        return 0.0
    if not first_finished_at or not last_finished_at:
        return 0.0
    try:
        t0 = _parse_iso(first_finished_at)
        t1 = _parse_iso(last_finished_at)
    except ValueError:
        return 0.0
    seconds = max(1.0, (t1 - t0).total_seconds())
    return total_launched / (seconds / 3600.0)


def downsample_xy(xs: list[float], ys: list[float], max_points: int) -> tuple[list[float], list[float]]:
    n = min(len(xs), len(ys))
    if n <= max_points or max_points <= 0:
        return xs[:n], ys[:n]

    step = n / float(max_points)
    out_x: list[float] = []
    out_y: list[float] = []
    i = 0.0
    while int(i) < n:
        idx = int(i)
        out_x.append(xs[idx])
        out_y.append(ys[idx])
        i += step
    if out_x[-1] != xs[n - 1]:
        out_x.append(xs[n - 1])
        out_y.append(ys[n - 1])
    return out_x, out_y


def compute_bounds(values: Iterable[float]) -> tuple[float, float]:
    vals = list(values)
    if not vals:
        return 0.0, 1.0
    y_min = min(vals)
    y_max = max(vals)
    if y_min == y_max:
        pad = 1.0 if y_min == 0 else abs(y_min) * 0.1
        return y_min - pad, y_max + pad
    pad = 0.08 * (y_max - y_min)
    return y_min - pad, y_max + pad


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
