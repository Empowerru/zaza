from __future__ import annotations

from pathlib import Path

from .models import BlackboxConfig, ParameterSpec, ProjectConfig
from .utils import load_json


def load_project_config(path: str | Path) -> ProjectConfig:
    return ProjectConfig.from_dict(load_json(Path(path)))


def load_blackbox_config(path: str | Path) -> BlackboxConfig:
    return BlackboxConfig.from_dict(load_json(Path(path)))


def load_search_space(path: str | Path) -> list[ParameterSpec]:
    data = load_json(Path(path))
    params = data.get("parameters", [])
    return [ParameterSpec.from_dict(item) for item in params]
