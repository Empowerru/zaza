from __future__ import annotations

import os

from .models import ProjectConfig


def resolve_worker_count(config: ProjectConfig, override_workers: int | None = None) -> int:
    if override_workers is not None:
        if override_workers == 0:
            return max(1, os.cpu_count() or 1)
        return max(1, override_workers)
    if config.use_all_logical_cores:
        return max(1, os.cpu_count() or 1)
    if config.default_workers <= 0:
        return max(1, os.cpu_count() or 1)
    return config.default_workers


def should_continue(*, launched: int, max_trials: int | None) -> bool:
    if max_trials is None:
        return True
    return launched < max_trials
