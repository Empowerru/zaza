from __future__ import annotations

import concurrent.futures
import logging
import time
from collections import deque
from dataclasses import replace
from pathlib import Path

from .adapters import get_adapter
from .config import load_blackbox_config, load_project_config, load_search_space
from .db import TrialDB
from .hashing import parameter_hash
from .models import WorkerOutcome, WorkerRequest
from .sandbox import prune_keep_best_n, remove_sandbox
from .scheduler import resolve_worker_count, should_continue
from .search import create_search_strategy
from .utils import ensure_dir
from .worker import run_trial


class OptimizerOrchestrator:
    def __init__(self, project_config_path: str, blackbox_config_path: str, search_space_path: str) -> None:
        self.project_config_path = str(Path(project_config_path))
        self.blackbox_config_path = str(Path(blackbox_config_path))
        self.search_space_path = str(Path(search_space_path))

        self.project_config = load_project_config(project_config_path)
        self.blackbox_config = load_blackbox_config(blackbox_config_path)
        self.search_space = load_search_space(search_space_path)

    def run(
        self,
        *,
        max_trials: int | None = None,
        workers: int | None = None,
        resume: bool | None = None,
        seed: int | None = None,
        goal: str | None = None,
        search_method: str | None = None,
        dry_run: bool = False,
    ) -> None:
        project_cfg = self.project_config
        if resume is not None:
            project_cfg = replace(project_cfg, resume=resume)
        if seed is not None:
            project_cfg = replace(project_cfg, random_seed=seed)
        if goal is not None:
            project_cfg = replace(project_cfg, goal=goal)
        if max_trials is not None:
            project_cfg = replace(project_cfg, max_trials=max_trials)
        if search_method is not None:
            project_cfg = replace(project_cfg, search_method=search_method)

        ensure_dir(Path(project_cfg.template_dir))
        ensure_dir(Path(project_cfg.work_root))
        ensure_dir(Path(project_cfg.log_dir))

        logger = self._build_logger(Path(project_cfg.log_dir), project_cfg.diagnostics)
        db = TrialDB(project_cfg.db_path)
        db.initialize(reset=not project_cfg.resume)

        adapter = get_adapter(self.blackbox_config.adapter_name)
        adapter.validate_config(self.blackbox_config)

        search = create_search_strategy(
            method=project_cfg.search_method,
            search_space=self.search_space,
            exploration_fraction=project_cfg.exploration_fraction,
            warmup_success_trials=project_cfg.warmup_success_trials,
            elite_pool_size=project_cfg.elite_pool_size,
            random_seed=project_cfg.random_seed,
            goal=project_cfg.goal,
            method_settings=project_cfg.search_method_settings,
        )

        existing_hashes = db.get_existing_hashes()
        retry_counts = db.get_retry_counts()
        success_pool_limit = int(project_cfg.search_method_settings.get("success_pool_limit", 50000))
        successful_pool = db.get_success_trials(project_cfg.goal, limit=max(100, success_pool_limit))

        workers_count = resolve_worker_count(project_cfg, workers)
        max_trials_cfg = project_cfg.max_trials

        diagnostics = project_cfg.diagnostics or {}
        summary_interval = float(diagnostics.get("summary_interval_sec", project_cfg.summary_interval_sec))
        print_trial_events = bool(diagnostics.get("print_trial_events", True))

        logger.info(
            "optimizer_start goal=%s method=%s workers=%s max_trials=%s resume=%s",
            project_cfg.goal,
            project_cfg.search_method,
            workers_count,
            max_trials_cfg,
            project_cfg.resume,
        )

        if dry_run:
            candidate, p_hash = search.propose(
                successful_trials=successful_pool,
                hash_fn=lambda c: parameter_hash(c, project_cfg.hash_float_precision),
                existing_hashes=existing_hashes,
            )
            logger.info("dry_run_candidate params_hash=%s params=%s", p_hash, candidate)
            print("Dry run candidate:")
            print(candidate)
            print(f"params_hash={p_hash}")
            db.close()
            return

        launched = 0
        start_ts = time.monotonic()
        last_summary = start_ts
        active: dict[concurrent.futures.Future[WorkerOutcome], WorkerRequest] = {}
        retry_queue: deque[WorkerRequest] = deque()
        stop_scheduling = False
        next_worker_id = 0

        retry_policy = project_cfg.retry_policy or {}
        retries_enabled = bool(retry_policy.get("enabled", False))
        max_retries = int(retry_policy.get("max_retries", 0))
        retry_statuses = set(retry_policy.get("retry_statuses", []))

        def next_worker() -> int:
            nonlocal next_worker_id
            wid = next_worker_id
            next_worker_id = (next_worker_id + 1) % max(1, workers_count)
            return wid

        def schedule_new_trial(
            executor: concurrent.futures.ProcessPoolExecutor,
            request: WorkerRequest | None = None,
        ) -> bool:
            nonlocal launched
            if not should_continue(launched=launched, max_trials=max_trials_cfg):
                return False

            if request is None:
                candidate, p_hash = search.propose(
                    successful_trials=successful_pool,
                    hash_fn=lambda c: parameter_hash(c, project_cfg.hash_float_precision),
                    existing_hashes=existing_hashes,
                )
                trial_id = db.insert_trial(
                    goal=project_cfg.goal,
                    candidate=candidate,
                    params_hash=p_hash,
                )
                request = WorkerRequest(
                    trial_id=trial_id,
                    worker_id=next_worker(),
                    candidate=candidate,
                    params_hash=p_hash,
                    goal=project_cfg.goal,
                    retry_of_trial_id=None,
                    attempt_index=retry_counts.get(p_hash, 0),
                )
            else:
                trial_id = db.insert_trial(
                    goal=project_cfg.goal,
                    candidate=request.candidate,
                    params_hash=request.params_hash,
                    retry_of_trial_id=request.retry_of_trial_id,
                )
                request = replace(request, trial_id=trial_id, worker_id=next_worker())

            existing_hashes.add(request.params_hash)
            retry_counts[request.params_hash] = retry_counts.get(request.params_hash, 0) + 1
            db.mark_running(request.trial_id, request.worker_id)

            future = executor.submit(
                run_trial,
                request,
                project_config_path=self.project_config_path,
                blackbox_config_path=self.blackbox_config_path,
            )
            active[future] = request
            launched += 1
            return True

        with concurrent.futures.ProcessPoolExecutor(max_workers=workers_count) as executor:
            try:
                while len(active) < workers_count and should_continue(launched=launched, max_trials=max_trials_cfg):
                    if not schedule_new_trial(executor):
                        break

                while active:
                    done, _ = concurrent.futures.wait(
                        active.keys(),
                        timeout=1.0,
                        return_when=concurrent.futures.FIRST_COMPLETED,
                    )

                    for fut in done:
                        req = active.pop(fut)
                        try:
                            outcome = fut.result()
                        except Exception as exc:
                            outcome = WorkerOutcome(
                                trial_id=req.trial_id,
                                worker_id=req.worker_id,
                                status="failed",
                                goal=req.goal,
                                target_value=None,
                                raw_result={},
                                params=req.candidate,
                                params_hash=req.params_hash,
                                runtime_sec=0.0,
                                progress_last=None,
                                stdout_path="",
                                stderr_path="",
                                failure_reason=f"worker_exception: {exc}",
                                sandbox_path="",
                                hostname="",
                                pid=None,
                                blackbox_return_code=None,
                                artifacts=[],
                            )

                        db.finish_trial(outcome)
                        if outcome.status == "success" and outcome.target_value is not None:
                            db.maybe_record_best(outcome.trial_id, project_cfg.goal, outcome.target_value)
                            successful_pool.append(
                                {
                                    "trial_id": outcome.trial_id,
                                    "target_value": float(outcome.target_value),
                                    "params": outcome.params,
                                }
                            )
                            successful_pool.sort(
                                key=lambda row: float(row["target_value"]),
                                reverse=(project_cfg.goal == "maximize"),
                            )
                            if len(successful_pool) > success_pool_limit:
                                successful_pool = successful_pool[:success_pool_limit]

                        self._apply_cleanup_policy(project_cfg.cleanup_policy, db, project_cfg.goal, project_cfg.keep_best_n, outcome)

                        if print_trial_events:
                            self._log_trial_event(logger, db, project_cfg.goal, outcome, len(active), workers_count)

                        if retries_enabled and outcome.status in retry_statuses:
                            already = retry_counts.get(req.params_hash, 0)
                            if already <= max_retries:
                                retry_queue.append(
                                    WorkerRequest(
                                        trial_id=0,
                                        worker_id=0,
                                        candidate=req.candidate,
                                        params_hash=req.params_hash,
                                        goal=req.goal,
                                        retry_of_trial_id=req.retry_of_trial_id or req.trial_id,
                                        attempt_index=already,
                                    )
                                )

                    while (
                        not stop_scheduling
                        and len(active) < workers_count
                        and should_continue(launched=launched, max_trials=max_trials_cfg)
                    ):
                        if retry_queue:
                            schedule_new_trial(executor, retry_queue.popleft())
                        else:
                            schedule_new_trial(executor)

                    now = time.monotonic()
                    if now - last_summary >= summary_interval:
                        logger.info(self._build_summary_line(db, project_cfg.goal, launched, workers_count, start_ts, len(active)))
                        last_summary = now

                    if not active and not should_continue(launched=launched, max_trials=max_trials_cfg):
                        break

            except KeyboardInterrupt:
                stop_scheduling = True
                logger.warning("Interrupted: stopping new scheduling, draining running workers")
                while active:
                    done, _ = concurrent.futures.wait(
                        active.keys(),
                        timeout=1.0,
                        return_when=concurrent.futures.FIRST_COMPLETED,
                    )
                    for fut in done:
                        req = active.pop(fut)
                        try:
                            outcome = fut.result()
                        except Exception as exc:
                            outcome = WorkerOutcome(
                                trial_id=req.trial_id,
                                worker_id=req.worker_id,
                                status="failed",
                                goal=req.goal,
                                target_value=None,
                                raw_result={},
                                params=req.candidate,
                                params_hash=req.params_hash,
                                runtime_sec=0.0,
                                progress_last=None,
                                stdout_path="",
                                stderr_path="",
                                failure_reason=f"worker_exception: {exc}",
                                sandbox_path="",
                                hostname="",
                                pid=None,
                                blackbox_return_code=None,
                                artifacts=[],
                            )
                        db.finish_trial(outcome)
                        self._apply_cleanup_policy(project_cfg.cleanup_policy, db, project_cfg.goal, project_cfg.keep_best_n, outcome)
                logger.info("Stopped cleanly")

        logger.info(self._build_summary_line(db, project_cfg.goal, launched, workers_count, start_ts, 0))
        db.close()

    @staticmethod
    def _build_logger(log_dir: Path, diagnostics: dict[str, object]) -> logging.Logger:
        logger = logging.getLogger("optimizer.engine")
        logger.setLevel(logging.INFO)
        logger.propagate = False

        for handler in list(logger.handlers):
            logger.removeHandler(handler)

        formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        file_name = str(diagnostics.get("engine_log_file", "engine.log"))
        file_path = Path(file_name)
        if not file_path.is_absolute():
            file_path = log_dir / file_path
        file_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(file_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        return logger

    @staticmethod
    def _build_summary_line(
        db: TrialDB,
        goal: str,
        launched_this_run: int,
        workers: int,
        start_ts: float,
        active_workers: int,
    ) -> str:
        counts = db.count_by_status(goal)
        total = db.count_launched(goal)
        queued = counts.get("queued", 0)
        running = counts.get("running", 0)
        success = counts.get("success", 0)
        terminal_fail_statuses = {
            "failed",
            "timeout",
            "stuck",
            "parse_error",
            "injection_error",
            "launch_error",
        }
        failed = sum(int(v) for k, v in counts.items() if k in terminal_fail_statuses)
        finished = success + failed
        success_rate = (100.0 * success / finished) if finished else 0.0
        best = db.get_best_trial(goal)
        best_target = best["target_value"] if best is not None else None
        best_trial_id = best["trial_id"] if best is not None else None
        stats = db.get_success_target_stats(goal)

        elapsed_h = max((time.monotonic() - start_ts) / 3600.0, 1e-9)
        tph = launched_this_run / elapsed_h

        return (
            "summary "
            f"total={total} run_launched={launched_this_run} "
            f"queued={queued} running={running} success={success} fail={failed} "
            f"success_rate={success_rate:.1f}% "
            f"best_target={best_target} best_trial_id={best_trial_id} goal={goal} "
            f"min_target={stats['min_target']} max_target={stats['max_target']} avg_target={stats['avg_target']} "
            f"tph={tph:.2f} active_workers={active_workers}/{workers}"
        )

    @staticmethod
    def _apply_cleanup_policy(
        cleanup_policy: str,
        db: TrialDB,
        goal: str,
        keep_best_n: int,
        outcome: WorkerOutcome,
    ) -> None:
        if not outcome.sandbox_path:
            return
        sandbox_path = Path(outcome.sandbox_path)
        if cleanup_policy == "keep_all":
            return
        if cleanup_policy == "always_delete":
            remove_sandbox(sandbox_path)
            return
        if cleanup_policy == "delete_success_keep_failure":
            if outcome.status == "success":
                remove_sandbox(sandbox_path)
            return
        if cleanup_policy == "keep_best_n":
            keep_ids = set(db.get_best_trial_ids(goal, keep_best_n))
            prune_keep_best_n(sandbox_path.parent, keep_ids)
            return
        # Safe fallback for unknown policy.
        remove_sandbox(sandbox_path)

    @staticmethod
    def _log_trial_event(
        logger: logging.Logger,
        db: TrialDB,
        goal: str,
        outcome: WorkerOutcome,
        active_workers: int,
        workers: int,
    ) -> None:
        best = db.get_best_trial(goal)
        best_target = best["target_value"] if best is not None else None
        best_trial_id = best["trial_id"] if best is not None else None
        logger.info(
            "trial_done trial_id=%s status=%s target=%s runtime_sec=%.2f progress_last=%s rc=%s best_target=%s best_trial_id=%s active_workers=%s/%s reason=%s",
            outcome.trial_id,
            outcome.status,
            outcome.target_value,
            outcome.runtime_sec,
            outcome.progress_last,
            outcome.blackbox_return_code,
            best_target,
            best_trial_id,
            active_workers,
            workers,
            outcome.failure_reason,
        )
