@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3.11 live_dashboard.py %*
  if %ERRORLEVEL%==0 exit /b 0
  py live_dashboard.py %*
  exit /b %ERRORLEVEL%
)

where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python live_dashboard.py %*
  exit /b %ERRORLEVEL%
)

echo Error: Python launcher not found. Install Python 3.11+.
exit /b 1
