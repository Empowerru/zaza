#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from optimizer.db import TrialDB
from optimizer.orchestrator import OptimizerOrchestrator


@dataclass(slots=True)
class AutoSettings:
    global_method: str = "optuna_tpe"
    local_method: str = "async_evolution"
    global_chunk_trials: int = 300
    local_chunk_trials: int = 120
    stagnation_rounds: int = 3
    min_improvement: float = 1e-9
    max_total_trials: int | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Automatic best-practice black-box optimization controller")
    parser.add_argument("--project-config", default="config/project_config.json")
    parser.add_argument("--blackbox-config", default="config/blackbox_config.json")
    parser.add_argument("--search-space", default="config/search_space.json")
    parser.add_argument("--workers", type=int, default=0, help="0 means all logical cores")
    parser.add_argument("--goal", choices=["maximize", "minimize"], default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--max-total-trials", type=int, default=None)
    parser.add_argument("--global-method", default=None)
    parser.add_argument("--local-method", default=None)
    parser.add_argument("--global-chunk-trials", type=int, default=None)
    parser.add_argument("--local-chunk-trials", type=int, default=None)
    parser.add_argument("--stagnation-rounds", type=int, default=None)
    parser.add_argument("--min-improvement", type=float, default=None)
    return parser.parse_args()


def load_auto_settings(path: Path) -> AutoSettings:
    if not path.exists():
        return AutoSettings()
    data = json.loads(path.read_text(encoding="utf-8"))
    section = data.get("auto_mode", {})
    if not isinstance(section, dict):
        section = {}
    return AutoSettings(
        global_method=str(section.get("global_method", "optuna_tpe")),
        local_method=str(section.get("local_method", "async_evolution")),
        global_chunk_trials=int(section.get("global_chunk_trials", 300)),
        local_chunk_trials=int(section.get("local_chunk_trials", 120)),
        stagnation_rounds=int(section.get("stagnation_rounds", 3)),
        min_improvement=float(section.get("min_improvement", 1e-9)),
        max_total_trials=(
            int(section["max_total_trials"])
            if section.get("max_total_trials") is not None
            else None
        ),
    )


def is_improved(before: float | None, after: float | None, goal: str, min_improvement: float) -> bool:
    if after is None:
        return False
    if before is None:
        return True
    if goal == "minimize":
        return (before - after) > min_improvement
    return (after - before) > min_improvement


def best_value_for_goal(db: TrialDB, goal: str) -> float | None:
    row = db.get_best_trial(goal)
    if row is None:
        return None
    value = row["target_value"]
    return float(value) if value is not None else None


def configure_logging() -> logging.Logger:
    logger = logging.getLogger("optimizer.auto")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for h in list(logger.handlers):
        logger.removeHandler(h)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    return logger


def main() -> None:
    args = parse_args()
    logger = configure_logging()

    project_config_path = Path(args.project_config)
    blackbox_config_path = Path(args.blackbox_config)
    search_space_path = Path(args.search_space)

    auto = load_auto_settings(project_config_path)
    if args.global_method:
        auto.global_method = args.global_method
    if args.local_method:
        auto.local_method = args.local_method
    if args.global_chunk_trials is not None:
        auto.global_chunk_trials = max(1, int(args.global_chunk_trials))
    if args.local_chunk_trials is not None:
        auto.local_chunk_trials = max(1, int(args.local_chunk_trials))
    if args.stagnation_rounds is not None:
        auto.stagnation_rounds = max(1, int(args.stagnation_rounds))
    if args.min_improvement is not None:
        auto.min_improvement = float(args.min_improvement)
    if args.max_total_trials is not None:
        auto.max_total_trials = int(args.max_total_trials)

    orch = OptimizerOrchestrator(
        project_config_path=str(project_config_path),
        blackbox_config_path=str(blackbox_config_path),
        search_space_path=str(search_space_path),
    )

    goal = args.goal or orch.project_config.goal
    workers = args.workers
    resume_override = None
    if args.resume:
        resume_override = True
    if args.no_resume:
        resume_override = False
    if resume_override is None:
        resume_override = True

    resume_for_runs = True
    db = TrialDB(orch.project_config.db_path)
    if resume_override:
        db.initialize(reset=False)
    else:
        # Reset once for a fresh research and then keep resuming across chunks.
        db.initialize(reset=True)

    launched_before = db.count_launched(goal)
    total_this_session = 0
    round_index = 0
    stagnation_counter = 0
    stage = "global"
    local_round_budget = 1
    local_rounds_done = 0
    base_seed = args.seed

    logger.info(
        "auto_start goal=%s workers=%s resume=%s global=%s local=%s",
        goal,
        workers,
        bool(resume_override),
        auto.global_method,
        auto.local_method,
    )

    try:
        while True:
            if auto.max_total_trials is not None and total_this_session >= auto.max_total_trials:
                break

            round_index += 1
            method = auto.global_method if stage == "global" else auto.local_method
            chunk = auto.global_chunk_trials if stage == "global" else auto.local_chunk_trials
            if auto.max_total_trials is not None:
                chunk = min(chunk, auto.max_total_trials - total_this_session)
            if chunk <= 0:
                break

            before_best = best_value_for_goal(db, goal)
            before_total = db.count_launched(goal)
            seed = (base_seed + round_index) if base_seed is not None else None

            logger.info(
                "auto_round=%s stage=%s method=%s chunk_trials=%s before_best=%s",
                round_index,
                stage,
                method,
                chunk,
                before_best,
            )

            orch.run(
                max_trials=chunk,
                workers=workers,
                resume=resume_for_runs,
                seed=seed,
                goal=goal,
                search_method=method,
                dry_run=False,
            )

            db.close()
            db = TrialDB(orch.project_config.db_path)
            db.initialize(reset=False)

            after_best = best_value_for_goal(db, goal)
            after_total = db.count_launched(goal)
            launched_delta = max(0, after_total - before_total)
            total_this_session = max(0, after_total - launched_before)
            improved = is_improved(before_best, after_best, goal, auto.min_improvement)

            logger.info(
                "auto_round_done=%s stage=%s method=%s launched_delta=%s total_session=%s best=%s improved=%s",
                round_index,
                stage,
                method,
                launched_delta,
                total_this_session,
                after_best,
                improved,
            )

            if improved:
                stagnation_counter = 0
                if stage == "local":
                    stage = "global"
                    local_rounds_done = 0
            else:
                if stage == "global":
                    stagnation_counter += 1
                    if stagnation_counter >= auto.stagnation_rounds:
                        stage = "local"
                        local_rounds_done = 0
                        stagnation_counter = 0
                        logger.info("auto_stage_switch from=global to=local reason=stagnation")
                else:
                    local_rounds_done += 1
                    if local_rounds_done >= local_round_budget:
                        stage = "global"
                        local_rounds_done = 0
                        logger.info("auto_stage_switch from=local to=global reason=local_budget_done")

    except KeyboardInterrupt:
        logger.warning("auto_interrupted stopping gracefully")
    except RuntimeError as exc:
        logger.error("auto_error %s", exc)
        raise SystemExit(1)
    finally:
        db.close()

    best = TrialDB(orch.project_config.db_path)
    best.initialize(reset=False)
    best_row = best.get_best_trial(goal)
    best_value = float(best_row["target_value"]) if best_row is not None and best_row["target_value"] is not None else None
    best_trial = int(best_row["trial_id"]) if best_row is not None else None
    best.close()
    logger.info(
        "auto_finished total_session=%s best_trial_id=%s best_target=%s goal=%s",
        total_this_session,
        best_trial,
        best_value,
        goal,
    )


if __name__ == "__main__":
    main()
