from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from optimizer.db import TrialDB
from optimizer.models import WorkerOutcome


class DBTests(unittest.TestCase):
    def test_insert_and_finish_trial(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "trials.sqlite"
            db = TrialDB(db_path)
            db.initialize(reset=True)

            trial_id = db.insert_trial(
                goal="minimize",
                candidate={"a": 1.0},
                params_hash="hash_a",
            )
            db.mark_running(trial_id, worker_id=2)
            outcome = WorkerOutcome(
                trial_id=trial_id,
                worker_id=2,
                status="success",
                goal="minimize",
                target_value=0.5,
                raw_result={"objective": 0.5},
                params={"a": 1.0},
                params_hash="hash_a",
                runtime_sec=1.2,
                progress_last=100,
                stdout_path="stdout.log",
                stderr_path="stderr.log",
                failure_reason=None,
                sandbox_path="/tmp/sandbox",
                hostname="host",
                pid=123,
                blackbox_return_code=0,
                artifacts=[],
            )
            db.finish_trial(outcome)
            counts = db.count_by_status()
            self.assertEqual(counts.get("success"), 1)
            self.assertIn("hash_a", db.get_existing_hashes())
            series = db.get_success_series(limit=10)
            self.assertEqual(len(series), 1)
            self.assertEqual(series[0]["trial_id"], trial_id)
            last = db.get_last_trial()
            self.assertIsNotNone(last)
            assert last is not None
            self.assertEqual(last["trial_id"], trial_id)
            db.close()

    def test_goal_scoped_queries(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "trials.sqlite"
            db = TrialDB(db_path)
            db.initialize(reset=True)

            t_min = db.insert_trial(goal="minimize", candidate={"x": 0.1}, params_hash="h_min")
            db.mark_running(t_min, worker_id=1)
            db.finish_trial(
                WorkerOutcome(
                    trial_id=t_min,
                    worker_id=1,
                    status="success",
                    goal="minimize",
                    target_value=1.0,
                    raw_result={"objective": 1.0},
                    params={"x": 0.1},
                    params_hash="h_min",
                    runtime_sec=1.0,
                    progress_last=100,
                    stdout_path="",
                    stderr_path="",
                    failure_reason=None,
                    sandbox_path="",
                    hostname="",
                    pid=None,
                    blackbox_return_code=0,
                    artifacts=[],
                )
            )

            t_max = db.insert_trial(goal="maximize", candidate={"x": 0.9}, params_hash="h_max")
            db.mark_running(t_max, worker_id=2)
            db.finish_trial(
                WorkerOutcome(
                    trial_id=t_max,
                    worker_id=2,
                    status="success",
                    goal="maximize",
                    target_value=100.0,
                    raw_result={"objective": 100.0},
                    params={"x": 0.9},
                    params_hash="h_max",
                    runtime_sec=1.0,
                    progress_last=100,
                    stdout_path="",
                    stderr_path="",
                    failure_reason=None,
                    sandbox_path="",
                    hostname="",
                    pid=None,
                    blackbox_return_code=0,
                    artifacts=[],
                )
            )

            self.assertEqual(db.count_launched("minimize"), 1)
            self.assertEqual(db.count_launched("maximize"), 1)
            self.assertEqual(db.count_by_status("minimize").get("success"), 1)
            self.assertEqual(db.count_by_status("maximize").get("success"), 1)

            best_min = db.get_best_trial("minimize")
            best_max = db.get_best_trial("maximize")
            assert best_min is not None
            assert best_max is not None
            self.assertEqual(int(best_min["trial_id"]), t_min)
            self.assertEqual(int(best_max["trial_id"]), t_max)

            self.assertEqual(len(db.get_success_trials("minimize", limit=10)), 1)
            self.assertEqual(len(db.get_success_trials("maximize", limit=10)), 1)
            self.assertEqual(len(db.get_success_series(limit=10, goal="minimize")), 1)
            self.assertEqual(len(db.get_success_series(limit=10, goal="maximize")), 1)

            stats_min = db.get_success_target_stats("minimize")
            stats_max = db.get_success_target_stats("maximize")
            self.assertEqual(stats_min["min_target"], 1.0)
            self.assertEqual(stats_max["max_target"], 100.0)

            last_min = db.get_last_trial("minimize")
            last_max = db.get_last_trial("maximize")
            assert last_min is not None
            assert last_max is not None
            self.assertEqual(last_min["trial_id"], t_min)
            self.assertEqual(last_max["trial_id"], t_max)

            self.assertEqual(len(db.top_trials("minimize", n=5)), 1)
            self.assertEqual(len(db.top_trials("maximize", n=5)), 1)
            db.close()


if __name__ == "__main__":
    unittest.main()
