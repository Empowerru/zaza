from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from optimizer.db import TrialDB
from optimizer.models import WorkerOutcome
from optimizer.orchestrator import OptimizerOrchestrator


class OrchestratorCleanupTests(unittest.TestCase):
    def _make_outcome(self, sandbox_path: Path, status: str) -> WorkerOutcome:
        return WorkerOutcome(
            trial_id=1,
            worker_id=0,
            status=status,  # type: ignore[arg-type]
            goal="minimize",
            target_value=1.0 if status == "success" else None,
            raw_result={},
            params={"x": 1.0},
            params_hash="h",
            runtime_sec=1.0,
            progress_last=100,
            stdout_path="stdout.log",
            stderr_path="stderr.log",
            failure_reason=None,
            sandbox_path=str(sandbox_path),
            hostname="host",
            pid=1,
            blackbox_return_code=0,
            artifacts=[],
        )

    def test_always_delete(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = TrialDB(root / "trials.sqlite")
            db.initialize(reset=True)
            sandbox = root / "work" / "trial_1_x"
            sandbox.mkdir(parents=True)

            OptimizerOrchestrator._apply_cleanup_policy(
                "always_delete",
                db,
                "minimize",
                10,
                self._make_outcome(sandbox, "failed"),
            )
            self.assertFalse(sandbox.exists())
            db.close()

    def test_delete_success_keep_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = TrialDB(root / "trials.sqlite")
            db.initialize(reset=True)

            sandbox_success = root / "work" / "trial_2_x"
            sandbox_success.mkdir(parents=True)
            OptimizerOrchestrator._apply_cleanup_policy(
                "delete_success_keep_failure",
                db,
                "minimize",
                10,
                self._make_outcome(sandbox_success, "success"),
            )
            self.assertFalse(sandbox_success.exists())

            sandbox_failure = root / "work" / "trial_3_x"
            sandbox_failure.mkdir(parents=True)
            OptimizerOrchestrator._apply_cleanup_policy(
                "delete_success_keep_failure",
                db,
                "minimize",
                10,
                self._make_outcome(sandbox_failure, "failed"),
            )
            self.assertTrue(sandbox_failure.exists())
            db.close()


if __name__ == "__main__":
    unittest.main()
