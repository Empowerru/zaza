from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from optimizer.db import TrialDB
from optimizer.models import ParameterSpec
from optimizer.search import AsyncEvolutionSearch, TPESearch, create_search_strategy


class SearchAndResumeTests(unittest.TestCase):
    def test_search_skips_duplicate_hashes(self) -> None:
        strategy = AsyncEvolutionSearch(
            search_space=[ParameterSpec(name="x", type="float", lower=0.0, upper=1.0)],
            exploration_fraction=1.0,
            warmup_success_trials=10,
            elite_pool_size=2,
            random_seed=1,
        )

        calls = {"n": 0}

        def fake_hash(_: dict[str, float]) -> str:
            calls["n"] += 1
            return "dup" if calls["n"] < 3 else "fresh"

        _, h = strategy.propose(
            successful_trials=[],
            hash_fn=fake_hash,
            existing_hashes={"dup"},
        )
        self.assertEqual(h, "fresh")

    def test_tpe_generates_candidate(self) -> None:
        strategy = TPESearch(
            search_space=[ParameterSpec(name="x", type="float", lower=0.0, upper=1.0)],
            exploration_fraction=0.0,
            warmup_success_trials=2,
            random_seed=2,
            settings={"gamma": 0.5, "min_good": 1, "candidates_per_step": 16},
        )
        successful = [
            {"trial_id": 1, "target_value": 0.1, "params": {"x": 0.2}},
            {"trial_id": 2, "target_value": 0.2, "params": {"x": 0.4}},
            {"trial_id": 3, "target_value": 0.9, "params": {"x": 0.9}},
        ]
        candidate, h = strategy.propose(
            successful_trials=successful,
            hash_fn=lambda c: f"h_{round(float(c['x']), 6)}",
            existing_hashes=set(),
        )
        self.assertTrue(0.0 <= candidate["x"] <= 1.0)
        self.assertTrue(h.startswith("h_"))

    def test_resume_reads_existing_hashes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "trials.sqlite"
            db = TrialDB(db_path)
            db.initialize(reset=True)
            db.insert_trial(goal="minimize", candidate={"x": 0.5}, params_hash="abc")
            db.close()

            db2 = TrialDB(db_path)
            db2.initialize(reset=False)
            hashes = db2.get_existing_hashes()
            self.assertIn("abc", hashes)
            db2.close()

    def test_search_factory(self) -> None:
        strategy = create_search_strategy(
            method="tpe",
            search_space=[ParameterSpec(name="x", type="float", lower=0.0, upper=1.0)],
            exploration_fraction=0.3,
            warmup_success_trials=3,
            elite_pool_size=5,
            random_seed=123,
            method_settings={},
        )
        self.assertIsInstance(strategy, TPESearch)

    def test_optuna_factory_or_clear_error(self) -> None:
        try:
            strategy = create_search_strategy(
                method="optuna_tpe",
                search_space=[ParameterSpec(name="x", type="float", lower=0.0, upper=1.0)],
                exploration_fraction=0.3,
                warmup_success_trials=3,
                elite_pool_size=5,
                random_seed=123,
                goal="minimize",
                method_settings={"optuna_n_startup_trials": 5, "optuna_n_ei_candidates": 16},
            )
        except RuntimeError as exc:
            self.assertIn("Optuna", str(exc))
            return
        self.assertIsNotNone(strategy)


if __name__ == "__main__":
    unittest.main()
