from __future__ import annotations

import unittest

from optimizer.hashing import parameter_hash


class HashingTests(unittest.TestCase):
    def test_hash_stable_order_and_float_noise(self) -> None:
        a = {"x": 0.12345678904, "y": 7, "z": True}
        b = {"z": True, "y": 7, "x": 0.12345678905}
        h1 = parameter_hash(a, float_precision=8)
        h2 = parameter_hash(b, float_precision=8)
        self.assertEqual(h1, h2)

    def test_hash_changes_for_material_difference(self) -> None:
        a = {"x": 0.1}
        b = {"x": 0.2}
        self.assertNotEqual(parameter_hash(a), parameter_hash(b))


if __name__ == "__main__":
    unittest.main()
