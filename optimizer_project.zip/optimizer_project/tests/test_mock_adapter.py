from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from optimizer.adapters.mock_laser_adapter import MockLaserAdapter
from optimizer.models import BlackboxConfig, ProcessRunResult


class MockAdapterTests(unittest.TestCase):
    def _cfg(self) -> BlackboxConfig:
        return BlackboxConfig.from_dict(
            {
                "adapter_name": "mock_laser_adapter",
                "executable_relpath": "godunov.exe",
                "command": ["{executable}", "{main_input_file}"],
                "working_directory_relpath": ".",
                "main_input_file_relpath": "laser.in",
                "input_files": [],
                "progress_file_relpath": "out/progress.txt",
                "result_file_relpath": "out/result.txt",
                "success_exit_codes": [0],
                "failure_exit_codes": [1, 2],
                "env": {},
                "parse_rules": {"transform": "identity"},
                "injection_rules": {
                    "laser_in_relpath": "laser.in",
                    "block1_file_relpath": "tempprof/laser_1.dat",
                    "block2_file_relpath": "tempprof/laser_2.dat",
                },
                "artifacts_to_keep": [{"kind": "result", "path": "out/result.txt"}],
            }
        )

    def _candidate(self) -> dict[str, float]:
        return {
            "laser1.integral": 0.23,
            "block1.parameter_1": 0.63,
            "block1.parameter_2": 0.21,
            "block1.parameter_3": 0.78,
            "block1.parameter_4": 0.34,
            "laser2.integral": 0.57,
            "block2.parameter_1": 0.17,
            "block2.parameter_2": 0.88,
            "block2.parameter_3": 0.42,
            "block2.parameter_4": 0.55,
        }

    def test_inject_and_parse(self) -> None:
        adapter = MockLaserAdapter()
        cfg = self._cfg()
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            (d / "tempprof").mkdir()
            (d / "out").mkdir()
            (d / "godunov.exe").write_text("stub", encoding="utf-8")
            adapter.inject_parameters(d, self._candidate(), cfg)
            self.assertTrue((d / "laser.in").exists())
            self.assertTrue((d / "tempprof/laser_1.dat").exists())

            (d / "out/progress.txt").write_text("35\n", encoding="utf-8")
            self.assertEqual(adapter.read_progress(d, cfg), 35)

            (d / "out/result.txt").write_text("12.5\n", encoding="utf-8")
            parsed = adapter.parse_result(d, cfg)
            self.assertEqual(parsed["objective"], 12.5)
            self.assertEqual(adapter.compute_target(parsed, cfg), 12.5)

            pr = ProcessRunResult(
                status="finished",
                return_code=0,
                runtime_sec=1.0,
                progress_last=100,
                failure_reason=None,
                stdout_path="a",
                stderr_path="b",
                pid=1,
            )
            self.assertTrue(adapter.detect_success(d, pr, cfg))


if __name__ == "__main__":
    unittest.main()
