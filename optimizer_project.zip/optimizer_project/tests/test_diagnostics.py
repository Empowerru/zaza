from __future__ import annotations

import unittest

from optimizer.diagnostics import compute_best_curve, compute_bounds, downsample_xy, success_rate


class DiagnosticsTests(unittest.TestCase):
    def test_best_curve_minimize(self) -> None:
        vals = [5.0, 3.0, 4.0, 2.0]
        self.assertEqual(compute_best_curve(vals, "minimize"), [5.0, 3.0, 3.0, 2.0])

    def test_best_curve_maximize(self) -> None:
        vals = [1.0, 2.0, 1.5, 3.0]
        self.assertEqual(compute_best_curve(vals, "maximize"), [1.0, 2.0, 2.0, 3.0])

    def test_success_rate(self) -> None:
        self.assertEqual(success_rate(0, 0), 0.0)
        self.assertAlmostEqual(success_rate(10, 7), 70.0)

    def test_downsample(self) -> None:
        xs = list(range(100))
        ys = [float(x) for x in xs]
        out_x, out_y = downsample_xy(xs, ys, max_points=10)
        self.assertGreaterEqual(len(out_x), 10)
        self.assertEqual(out_x[-1], 99)
        self.assertEqual(out_y[-1], 99.0)

    def test_bounds(self) -> None:
        lo, hi = compute_bounds([2.0, 2.0])
        self.assertLess(lo, hi)


if __name__ == "__main__":
    unittest.main()
