from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from optimizer.sandbox import create_sandbox


class SandboxTests(unittest.TestCase):
    def test_create_sandbox_copies_template(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            template = root / "template"
            work = root / "work"
            template.mkdir()
            (template / "a.txt").write_text("hello", encoding="utf-8")

            sandbox = create_sandbox(template, work, trial_id=42)
            self.assertTrue((sandbox / "a.txt").exists())


if __name__ == "__main__":
    unittest.main()
