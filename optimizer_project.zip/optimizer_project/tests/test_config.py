from __future__ import annotations

from pathlib import Path
import unittest

from optimizer.config import load_blackbox_config, load_project_config, load_search_space


class ConfigLoadTests(unittest.TestCase):
    def test_load_default_configs(self) -> None:
        root = Path(__file__).resolve().parents[1]
        project = load_project_config(root / "config/project_config.json")
        blackbox = load_blackbox_config(root / "config/blackbox_config.json")
        space = load_search_space(root / "config/search_space.json")

        self.assertEqual(project.goal, "minimize")
        self.assertEqual(project.search_method, "optuna_tpe")
        self.assertEqual(blackbox.adapter_name, "mock_laser_adapter")
        self.assertEqual(len(space), 10)


if __name__ == "__main__":
    unittest.main()
