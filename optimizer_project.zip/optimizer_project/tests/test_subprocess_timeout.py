from __future__ import annotations

from pathlib import Path
import sys
import tempfile
import unittest

from optimizer.subprocess_runner import run_subprocess


class SubprocessTimeoutTests(unittest.TestCase):
    def test_timeout(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            result = run_subprocess(
                command=[sys.executable, "-c", "import time; time.sleep(2)"],
                cwd=root,
                env={},
                stdout_path=root / "stdout.log",
                stderr_path=root / "stderr.log",
                timeout_sec=0.5,
                poll_interval_sec=0.1,
                stuck_timeout_sec=0.0,
                progress_reader=None,
            )
            self.assertEqual(result.status, "timeout")


if __name__ == "__main__":
    unittest.main()
