#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from optimizer.db import TrialDB
from optimizer.orchestrator import OptimizerOrchestrator


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run generic black-box optimizer")
    parser.add_argument("--project-config", default="config/project_config.json")
    parser.add_argument("--blackbox-config", default="config/blackbox_config.json")
    parser.add_argument("--search-space", default="config/search_space.json")
    parser.add_argument("--max-trials", type=int, default=None)
    parser.add_argument("--workers", type=int, default=None, help="0 means all logical cores")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--goal", choices=["maximize", "minimize"], default=None)
    parser.add_argument(
        "--search-method",
        choices=[
            "tpe",
            "async_tpe",
            "async_evolution",
            "evolution",
            "random_mutation",
            "optuna_tpe",
            "optuna",
            "bayes_optuna",
        ],
        default=None,
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--keep-failures", action="store_true")
    parser.add_argument("--analyze-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_cfg = Path(args.project_config)
    blackbox_cfg = Path(args.blackbox_config)
    search_space = Path(args.search_space)

    orch = OptimizerOrchestrator(
        project_config_path=str(project_cfg),
        blackbox_config_path=str(blackbox_cfg),
        search_space_path=str(search_space),
    )

    resume_override = None
    if args.resume:
        resume_override = True
    if args.no_resume:
        resume_override = False

    if args.keep_failures:
        orch.project_config.cleanup_policy = "delete_success_keep_failure"

    if args.analyze_only:
        db = TrialDB(orch.project_config.db_path)
        db.initialize(reset=False)
        top = db.top_trials(goal=args.goal or orch.project_config.goal, n=10)
        if not top:
            print("No successful trials found.")
        for row in top:
            print(f"trial_id={row['trial_id']} target={row['target_value']} status={row['status']}")
        db.close()
        return

    try:
        orch.run(
            max_trials=args.max_trials,
            workers=args.workers,
            resume=resume_override,
            seed=args.seed,
            goal=args.goal,
            search_method=args.search_method,
            dry_run=args.dry_run,
        )
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
