@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM Unattended supervisor for week-long optimization on Windows.
REM Stop behavior:
REM   1) Press Ctrl+C in this window, OR
REM   2) create file "stop_autopilot.flag" in project root.

cd /d "%~dp0"

set "PY=py -3.11"
set "PROJECT_CONFIG=config\project_config.json"
set "BLACKBOX_CONFIG=config\blackbox_config.json"
set "SEARCH_SPACE=config\search_space.json"
set "WORKERS=0"
set "GOAL=minimize"
set "METHOD=optuna_tpe"
set "RESTART_DELAY_SEC=15"
set "LOG_FILE=logs\autopilot.log"

if not exist logs mkdir logs

echo ==================================================>> "%LOG_FILE%"
echo [%date% %time%] AUTOPILOT START>> "%LOG_FILE%"
echo Config: workers=%WORKERS% goal=%GOAL% method=%METHOD%>> "%LOG_FILE%"

:loop
if exist stop_autopilot.flag (
  echo [%date% %time%] stop_autopilot.flag detected, exiting.>> "%LOG_FILE%"
  del /q stop_autopilot.flag >nul 2>nul
  exit /b 0
)

echo [%date% %time%] launching optimizer...>> "%LOG_FILE%"
%PY% run_optimizer.py ^
  --project-config "%PROJECT_CONFIG%" ^
  --blackbox-config "%BLACKBOX_CONFIG%" ^
  --search-space "%SEARCH_SPACE%" ^
  --workers %WORKERS% ^
  --goal %GOAL% ^
  --search-method %METHOD% ^
  --resume >> "%LOG_FILE%" 2>&1

set "RC=%ERRORLEVEL%"
echo [%date% %time%] optimizer exited rc=%RC%, restart in %RESTART_DELAY_SEC%s>> "%LOG_FILE%"

timeout /t %RESTART_DELAY_SEC% /nobreak >nul
goto loop

