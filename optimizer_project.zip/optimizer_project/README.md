# Black-Box Optimizer Project

Generic, reusable optimization framework for slow external executables.

## Retargeting model (critical)

Retarget by editing:
1. JSON configs under `config/`
2. one adapter module under `optimizer/adapters/`

Do **not** rewrite engine modules (`orchestrator`, `worker`, `db`, `search`, `scheduler`).

## Structure

```
optimizer_project/
  run_optimizer.py
  run_auto_optimize.py
  analyze_db.py
  optimizer/
    orchestrator.py
    worker.py
    subprocess_runner.py
    db.py
    search.py
    sandbox.py
    blackbox_interface.py
    adapters/
      mock_laser_adapter.py
      mock_laser_injector.py
  config/
    project_config.json
    blackbox_config.json
    search_space.json
  data/
    trials.sqlite
  runs/
    template/
    work/
  logs/
  tests/
```

## Quick start

1. Put black-box template files in `runs/template/` (already prefilled for the mock case).
2. Install deps:

```bash
python3.11 -m pip install -r requirements.txt
```

3. Edit `config/search_space.json` to define tunable parameters.
4. Run optimizer:

```bash
python3.11 run_optimizer.py \
  --project-config config/project_config.json \
  --blackbox-config config/blackbox_config.json \
  --search-space config/search_space.json \
  --workers 0 \
  --goal minimize \
  --search-method optuna_tpe
```

`--workers 0` means all logical cores.

## Optimization methods

Configured in `config/project_config.json` (`search_method`) or CLI (`--search-method`):

- `optuna_tpe` (recommended): Bayesian TPE sampler from Optuna.
- `tpe`: built-in lightweight asynchronous TPE-like search.
- `async_evolution`: asynchronous random+elite mutation search.

For very expensive black-box runs (10 minutes to 1 day), `optuna_tpe` is the recommended baseline in this project.

Important TPE settings in `project_config.json -> search_method_settings`:
- `success_pool_limit`: how many successful historical trials are used by the search model (default `50000`).
- `gamma`, `min_good`, `candidates_per_step`: model/exploration behavior.
- `optuna_n_startup_trials`, `optuna_n_ei_candidates`, `optuna_multivariate`, `optuna_group`, `optuna_constant_liar`: Optuna TPE controls.

## Finite vs indefinite runs

- Finite: `--max-trials 10000`
- Indefinite: omit `--max-trials`, stop with `Ctrl+C`

On `Ctrl+C`, new scheduling stops and current workers are drained cleanly.

## Resume

Set `"resume": true` in `project_config.json` or pass `--resume`.

Resume reuses `data/trials.sqlite`, keeps all history, avoids forgetting prior runs, and continues search using existing successful trials.

## Goal direction

Set via config or CLI:
- `goal = "minimize"`
- `goal = "maximize"`

Engine logic is direction-agnostic.

## Live diagnostics during optimization

The engine prints live progress to console and writes the same messages to `logs/engine.log`.

Diagnostics include:
- completed trial events (status, target, runtime, best-so-far)
- periodic summary (total launched, success/failure, success rate, best trial, min/max/avg target, active workers, trials/hour)

Control via `project_config.json`:
- `diagnostics.print_trial_events`
- `diagnostics.summary_interval_sec`
- `diagnostics.engine_log_file`
- `cleanup_policy` (`always_delete` is recommended for long runs to avoid huge `runs/work`)

## Database

SQLite file: `data/trials.sqlite`.

Main table: `trials` with statuses, params, hashes, target values, runtime, output logs, failure reasons.

Also includes:
- `artifacts`
- `best_history`

## Analyze results

```bash
python3.11 analyze_db.py --db data/trials.sqlite --goal minimize --top 20
```

Export best parameters:

```bash
python3.11 analyze_db.py --db data/trials.sqlite --export-best best_params.json
```

## Live dashboard (Windows-friendly)

There is a real-time GUI dashboard that reads SQLite and redraws automatically.

Features:
- target trajectory over successful trials
- best-so-far curve
- total/success/failure counts
- success rate, min/max/avg target, best trial id
- running/timeout/stuck counters
- run controls: start/stop optimizer, workers, max-trials, goal, method
- resume existing research or start a new DB-backed research
- method-specific hyperparameters that switch dynamically when method changes (no mixed controls confusion)
- `Auto Best` button: one-click automatic strategy controller (global Bayesian search + local refinement on stagnation)

Run on Windows (one-click):

```bat
run_live_dashboard.bat --goal minimize --refresh-sec 2
```

Run directly with Python:

```bash
python3.11 live_dashboard.py --db data/trials.sqlite --goal minimize --refresh-sec 2
```

When started from dashboard, runs are launched through `run_optimizer.py` with a generated runtime config:
- `config/_dashboard_runtime_project_config.json`

## One-click automatic best-practice mode

You can run a fully automatic strategy:

- Click `Auto Best` in dashboard
- It uses `run_auto_optimize.py` controller
- Strategy:
  - global phase: `optuna_tpe`
  - if stagnation detected: short local phase `async_evolution`
  - then back to global phase
- Repeat until max trials (if set) or until stopped

Controller settings are in `config/project_config.json -> auto_mode`.

## Unattended week-long run (Windows)

Use supervisor script:

```bat
run_week_autopilot.bat
```

It will:
- run optimizer with `--resume`
- write logs to `logs/autopilot.log`
- auto-restart optimizer after unexpected exit

Stop unattended run:
- press `Ctrl+C` in that console, or
- create file `stop_autopilot.flag` in project root

## Current mock adapter

`optimizer/adapters/mock_laser_adapter.py` supports the mock black box by:
- injecting values into `laser.in`
- generating profile `.dat` files from integral parameters
- monitoring progress file
- parsing result file
- converting parsed objective into optimization target (`identity` or `negate`)

All path semantics are controlled by `blackbox_config.json`; the engine remains generic.

## Main file to edit for new trial input injection

If you need to customize how new trial parameters are written into black-box input files, edit:

- `optimizer/adapters/mock_laser_injector.py`

This file is intentionally isolated and marked with:

- `EDIT THIS FILE FOR CUSTOM TRIAL INPUT INJECTION LOGIC.`

So you can change injection behavior without touching the generic scheduler/DB/search engine.
