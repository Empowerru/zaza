# Remote DB Plots

This folder contains a minimal dashboard that:

1. Connects to remote host over SSH/SFTP.
2. Supports multiple remote campaign folders (1..N), each with own login/password/path.
3. Copies all files from each configured remote DB folder every 30 seconds (default).
4. Stores mirrored DB files locally in `mirrored_dbs/`.
4. Draws live target/best-so-far plots for selected DB.

## Files

- `remote_db_dashboard.py`: main script
- `config.json`: connection and refresh settings
- `requirements.txt`: Python dependencies

## Setup

```bash
python -m pip install -r requirements.txt
```

Edit `config.json`.

Preferred format is `sources` list (multiple campaigns):

- `sources`: array of objects:
  - `name`: source/campaign name (used as local subfolder)
  - `remote_login`: `user@host`
  - `remote_password`: SSH password
  - `remote_port`: SSH port (usually `22`)
  - `remote_db_dir`: remote folder with DB files
- `local_mirror_dir`: local cache folder
- `sync_interval_sec`: copy interval (default `30`)
- `refresh_sec`: UI refresh interval
- `goal`: `minimize` or `maximize`

Legacy single-source keys (`remote_login`, `remote_password`, `remote_db_dir`) are still supported.

## Run

```bash
python remote_db_dashboard.py
```

Optional custom config:

```bash
python remote_db_dashboard.py --config path/to/config.json
```
